/**
 * اختبار تطبيق المساح
 * Test Surveyor App
 */

const { execSync } = require('child_process');
const fs = require('fs');

console.log('🧪 بدء اختبار تطبيق المساح...\n');

// فحص الملفات الأساسية
const requiredFiles = [
  'App.tsx',
  'src/screens/LoginScreen.tsx',
  'src/screens/DashboardScreen.tsx',
  'src/screens/MapScreen.tsx',
  'src/services/LocationService.ts',
  'src/services/ApiService.ts',
  'src/components/MapComponent.tsx'
];

console.log('📁 فحص الملفات الأساسية:');
requiredFiles.forEach(file => {
  if (fs.existsSync(file)) {
    console.log(`✅ ${file}`);
  } else {
    console.log(`❌ ${file} - مفقود`);
  }
});

// فحص package.json
console.log('\n📦 فحص التبعيات:');
const packageJson = JSON.parse(fs.readFileSync('package.json', 'utf8'));
const requiredDeps = [
  'react-native-maps',
  '@react-native-community/geolocation',
  '@react-native-async-storage/async-storage',
  'react-native-permissions'
];

requiredDeps.forEach(dep => {
  if (packageJson.dependencies[dep] || packageJson.devDependencies?.[dep]) {
    console.log(`✅ ${dep}`);
  } else {
    console.log(`❌ ${dep} - غير مثبت`);
  }
});

// فحص بناء التطبيق
console.log('\n🔨 فحص بناء التطبيق:');
try {
  execSync('npx tsc --noEmit --skipLibCheck', { stdio: 'pipe' });
  console.log('✅ TypeScript - لا توجد أخطاء');
} catch (error) {
  console.log('⚠️ TypeScript - توجد تحذيرات أو أخطاء');
}

console.log('\n✨ اكتمل الاختبار!');
console.log('\n📱 لتشغيل التطبيق:');
console.log('1. تأكد من تشغيل محاكي Android أو iOS');
console.log('2. شغل: npx react-native run-android أو npx react-native run-ios');
console.log('3. أو استخدم Expo: npx expo start');
