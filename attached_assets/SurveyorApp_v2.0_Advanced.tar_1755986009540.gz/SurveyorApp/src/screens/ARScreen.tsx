import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Alert,
  Modal,
  ScrollView,
  Switch,
} from 'react-native';
import ARView from '../components/ARView';
import { ARPoint } from '../services/ARService';
import LocationService from '../services/LocationService';

interface ARScreenProps {
  onNavigate?: (screen: string) => void;
}

const ARScreen: React.FC<ARScreenProps> = ({ onNavigate }) => {
  const [isARActive, setIsARActive] = useState(false);
  const [surveyPoints, setSurveyPoints] = useState<ARPoint[]>([]);
  const [selectedPoint, setSelectedPoint] = useState<ARPoint | null>(null);
  const [showSettings, setShowSettings] = useState(false);
  const [arSettings, setARSettings] = useState({
    showDistance: true,
    showLabels: true,
    maxVisibleDistance: 1000,
    pointSize: 1.0,
    showCompass: true,
    showOrientation: true,
  });

  useEffect(() => {
    loadSurveyPoints();
    startLocationTracking();

    return () => {
      LocationService.stopTracking();
    };
  }, []);

  /**
   * تحميل نقاط المسح من البيانات المحفوظة
   */
  const loadSurveyPoints = async () => {
    try {
      // محاكاة تحميل نقاط المسح من قاعدة البيانات أو التخزين المحلي
      const mockPoints: ARPoint[] = [
        {
          id: '1',
          latitude: 15.3694,
          longitude: 44.1910,
          altitude: 2200,
          label: 'نقطة مرجعية 1',
          type: 'reference',
          color: '#FF5722',
          size: 1.0,
          visible: false,
        },
        {
          id: '2',
          latitude: 15.3695,
          longitude: 44.1912,
          altitude: 2205,
          label: 'حد شمالي',
          type: 'boundary',
          color: '#2196F3',
          size: 1.0,
          visible: false,
        },
        {
          id: '3',
          latitude: 15.3692,
          longitude: 44.1908,
          altitude: 2198,
          label: 'زاوية جنوبية',
          type: 'survey_point',
          color: '#4CAF50',
          size: 1.0,
          visible: false,
        },
        {
          id: '4',
          latitude: 15.3696,
          longitude: 44.1915,
          altitude: 2210,
          label: 'مبنى إداري',
          type: 'building',
          color: '#9C27B0',
          size: 1.2,
          visible: false,
        },
      ];

      setSurveyPoints(mockPoints);
    } catch (error) {
      Alert.alert('خطأ', 'فشل في تحميل نقاط المسح');
    }
  };

  /**
   * بدء تتبع الموقع
   */
  const startLocationTracking = () => {
    LocationService.startTracking((location) => {
      // تحديث موقع الجهاز في خدمة AR
      // ARService.updateDeviceLocation(location);
    });
  };

  /**
   * تفعيل/إلغاء تفعيل الواقع المعزز
   */
  const toggleAR = () => {
    if (isARActive) {
      setIsARActive(false);
    } else {
      Alert.alert(
        'تفعيل الواقع المعزز',
        'سيتم استخدام الكاميرا وأجهزة الاستشعار لعرض نقاط المسح في الواقع المعزز',
        [
          { text: 'إلغاء', style: 'cancel' },
          {
            text: 'تفعيل',
            onPress: () => setIsARActive(true),
          },
        ]
      );
    }
  };

  /**
   * معالج النقر على نقطة AR
   */
  const handlePointTap = (point: ARPoint) => {
    setSelectedPoint(point);
  };

  /**
   * معالج معايرة البوصلة
   */
  const handleCalibration = () => {
    Alert.alert(
      'معايرة البوصلة',
      'تم بدء عملية المعايرة. قم بتحريك الجهاز في شكل رقم 8 ببطء.',
      [{ text: 'موافق' }]
    );
  };

  /**
   * تحديث إعدادات AR
   */
  const updateARSettings = (key: string, value: any) => {
    setARSettings(prev => ({
      ...prev,
      [key]: value,
    }));
  };

  /**
   * إضافة نقطة جديدة في الموقع الحالي
   */
  const addPointAtCurrentLocation = () => {
    LocationService.getCurrentLocation((location) => {
      const newPoint: ARPoint = {
        id: Date.now().toString(),
        latitude: location.latitude,
        longitude: location.longitude,
        altitude: location.altitude || 0,
        label: `نقطة ${surveyPoints.length + 1}`,
        type: 'survey_point',
        color: '#4CAF50',
        size: 1.0,
        visible: false,
      };

      setSurveyPoints(prev => [...prev, newPoint]);
      Alert.alert('تم الإضافة', 'تم إضافة نقطة جديدة في موقعك الحالي');
    });
  };

  /**
   * عرض تفاصيل النقطة المحددة
   */
  const renderPointDetails = () => {
    if (!selectedPoint) return null;

    return (
      <Modal
        visible={selectedPoint !== null}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setSelectedPoint(null)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.pointDetailsModal}>
            <Text style={styles.pointDetailsTitle}>تفاصيل النقطة</Text>
            
            <View style={styles.pointDetailsContent}>
              <View style={styles.detailRow}>
                <Text style={styles.detailLabel}>التسمية:</Text>
                <Text style={styles.detailValue}>{selectedPoint.label}</Text>
              </View>
              
              <View style={styles.detailRow}>
                <Text style={styles.detailLabel}>النوع:</Text>
                <Text style={styles.detailValue}>
                  {selectedPoint.type === 'survey_point' ? 'نقطة مسح' :
                   selectedPoint.type === 'boundary' ? 'نقطة حدود' :
                   selectedPoint.type === 'reference' ? 'نقطة مرجعية' : 'مبنى'}
                </Text>
              </View>
              
              <View style={styles.detailRow}>
                <Text style={styles.detailLabel}>خط العرض:</Text>
                <Text style={styles.detailValue}>{selectedPoint.latitude.toFixed(6)}°</Text>
              </View>
              
              <View style={styles.detailRow}>
                <Text style={styles.detailLabel}>خط الطول:</Text>
                <Text style={styles.detailValue}>{selectedPoint.longitude.toFixed(6)}°</Text>
              </View>
              
              <View style={styles.detailRow}>
                <Text style={styles.detailLabel}>الارتفاع:</Text>
                <Text style={styles.detailValue}>{selectedPoint.altitude.toFixed(2)} م</Text>
              </View>
              
              {selectedPoint.distance && (
                <View style={styles.detailRow}>
                  <Text style={styles.detailLabel}>المسافة:</Text>
                  <Text style={styles.detailValue}>{Math.round(selectedPoint.distance)} م</Text>
                </View>
              )}
              
              {selectedPoint.bearing !== undefined && (
                <View style={styles.detailRow}>
                  <Text style={styles.detailLabel}>الاتجاه:</Text>
                  <Text style={styles.detailValue}>{Math.round(selectedPoint.bearing)}°</Text>
                </View>
              )}
            </View>
            
            <View style={styles.pointDetailsActions}>
              <TouchableOpacity
                style={styles.navigateButton}
                onPress={() => {
                  setSelectedPoint(null);
                  // يمكن إضافة وظيفة التنقل إلى النقطة هنا
                  Alert.alert('التنقل', 'سيتم فتح تطبيق الخرائط للتنقل إلى هذه النقطة');
                }}
              >
                <Text style={styles.navigateButtonText}>التنقل إلى النقطة</Text>
              </TouchableOpacity>
              
              <TouchableOpacity
                style={styles.closeButton}
                onPress={() => setSelectedPoint(null)}
              >
                <Text style={styles.closeButtonText}>إغلاق</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    );
  };

  /**
   * عرض إعدادات AR
   */
  const renderARSettings = () => (
    <Modal
      visible={showSettings}
      animationType="slide"
      transparent={true}
      onRequestClose={() => setShowSettings(false)}
    >
      <View style={styles.modalOverlay}>
        <View style={styles.settingsModal}>
          <Text style={styles.settingsTitle}>إعدادات الواقع المعزز</Text>
          
          <ScrollView style={styles.settingsContent}>
            <View style={styles.settingRow}>
              <Text style={styles.settingLabel}>عرض المسافات</Text>
              <Switch
                value={arSettings.showDistance}
                onValueChange={(value) => updateARSettings('showDistance', value)}
              />
            </View>
            
            <View style={styles.settingRow}>
              <Text style={styles.settingLabel}>عرض التسميات</Text>
              <Switch
                value={arSettings.showLabels}
                onValueChange={(value) => updateARSettings('showLabels', value)}
              />
            </View>
            
            <View style={styles.settingRow}>
              <Text style={styles.settingLabel}>عرض البوصلة</Text>
              <Switch
                value={arSettings.showCompass}
                onValueChange={(value) => updateARSettings('showCompass', value)}
              />
            </View>
            
            <View style={styles.settingRow}>
              <Text style={styles.settingLabel}>عرض معلومات الاتجاه</Text>
              <Switch
                value={arSettings.showOrientation}
                onValueChange={(value) => updateARSettings('showOrientation', value)}
              />
            </View>
            
            <View style={styles.settingRow}>
              <Text style={styles.settingLabel}>أقصى مسافة للعرض</Text>
              <Text style={styles.settingValue}>{arSettings.maxVisibleDistance} م</Text>
            </View>
            
            <View style={styles.settingRow}>
              <Text style={styles.settingLabel}>حجم النقاط</Text>
              <Text style={styles.settingValue}>{arSettings.pointSize}x</Text>
            </View>
          </ScrollView>
          
          <TouchableOpacity
            style={styles.closeSettingsButton}
            onPress={() => setShowSettings(false)}
          >
            <Text style={styles.closeSettingsButtonText}>إغلاق</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );

  if (isARActive) {
    return (
      <View style={styles.container}>
        <ARView
          surveyPoints={surveyPoints}
          onPointTap={handlePointTap}
          onCalibrate={handleCalibration}
          showCalibrationButton={true}
        />
        
        {/* أزرار التحكم العلوية */}
        <View style={styles.topControls}>
          <TouchableOpacity
            style={styles.exitARButton}
            onPress={toggleAR}
          >
            <Text style={styles.exitARButtonText}>إنهاء AR</Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={styles.settingsButton}
            onPress={() => setShowSettings(true)}
          >
            <Text style={styles.settingsButtonText}>⚙️</Text>
          </TouchableOpacity>
        </View>
        
        {renderPointDetails()}
        {renderARSettings()}
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <ScrollView style={styles.content}>
        {/* مقدمة الواقع المعزز */}
        <View style={styles.introSection}>
          <Text style={styles.introTitle}>الواقع المعزز للمسح</Text>
          <Text style={styles.introText}>
            استخدم الواقع المعزز لرؤية نقاط المسح والحدود مباشرة في البيئة الحقيقية 
            عبر كاميرا جهازك. هذه الميزة تساعدك في:
          </Text>
          
          <View style={styles.featuresList}>
            <Text style={styles.featureItem}>• رؤية النقاط المرجعية في الموقع</Text>
            <Text style={styles.featureItem}>• تحديد الحدود والزوايا بدقة</Text>
            <Text style={styles.featureItem}>• قياس المسافات والاتجاهات</Text>
            <Text style={styles.featureItem}>• التنقل بين النقاط بسهولة</Text>
          </View>
        </View>

        {/* إحصائيات النقاط */}
        <View style={styles.statsSection}>
          <Text style={styles.statsTitle}>نقاط المسح المتاحة</Text>
          
          <View style={styles.statsGrid}>
            <View style={styles.statCard}>
              <Text style={styles.statValue}>{surveyPoints.length}</Text>
              <Text style={styles.statLabel}>إجمالي النقاط</Text>
            </View>
            
            <View style={styles.statCard}>
              <Text style={styles.statValue}>
                {surveyPoints.filter(p => p.type === 'reference').length}
              </Text>
              <Text style={styles.statLabel}>نقاط مرجعية</Text>
            </View>
            
            <View style={styles.statCard}>
              <Text style={styles.statValue}>
                {surveyPoints.filter(p => p.type === 'boundary').length}
              </Text>
              <Text style={styles.statLabel}>نقاط حدود</Text>
            </View>
            
            <View style={styles.statCard}>
              <Text style={styles.statValue}>
                {surveyPoints.filter(p => p.type === 'survey_point').length}
              </Text>
              <Text style={styles.statLabel}>نقاط مسح</Text>
            </View>
          </View>
        </View>

        {/* قائمة النقاط */}
        <View style={styles.pointsSection}>
          <Text style={styles.pointsTitle}>قائمة النقاط</Text>
          
          {surveyPoints.map(point => (
            <View key={point.id} style={styles.pointCard}>
              <View style={styles.pointInfo}>
                <Text style={styles.pointLabel}>{point.label}</Text>
                <Text style={styles.pointCoords}>
                  {point.latitude.toFixed(4)}°, {point.longitude.toFixed(4)}°
                </Text>
                <Text style={styles.pointType}>
                  {point.type === 'survey_point' ? 'نقطة مسح' :
                   point.type === 'boundary' ? 'نقطة حدود' :
                   point.type === 'reference' ? 'نقطة مرجعية' : 'مبنى'}
                </Text>
              </View>
              
              <View style={[styles.pointIndicator, { backgroundColor: point.color }]} />
            </View>
          ))}
        </View>
      </ScrollView>

      {/* أزرار التحكم السفلية */}
      <View style={styles.bottomControls}>
        <TouchableOpacity
          style={styles.addPointButton}
          onPress={addPointAtCurrentLocation}
        >
          <Text style={styles.addPointButtonText}>إضافة نقطة هنا</Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={styles.startARButton}
          onPress={toggleAR}
        >
          <Text style={styles.startARButtonText}>بدء الواقع المعزز</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  content: {
    flex: 1,
  },
  topControls: {
    position: 'absolute',
    top: 50,
    left: 16,
    right: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
    zIndex: 1000,
  },
  exitARButton: {
    backgroundColor: 'rgba(244, 67, 54, 0.8)',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
  },
  exitARButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: 'bold',
  },
  settingsButton: {
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  settingsButtonText: {
    fontSize: 20,
  },
  introSection: {
    padding: 16,
    backgroundColor: '#FFFFFF',
    margin: 16,
    borderRadius: 12,
    elevation: 2,
  },
  introTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#212121',
    marginBottom: 8,
  },
  introText: {
    fontSize: 14,
    color: '#424242',
    lineHeight: 20,
    marginBottom: 12,
  },
  featuresList: {
    marginTop: 8,
  },
  featureItem: {
    fontSize: 14,
    color: '#424242',
    marginBottom: 4,
  },
  statsSection: {
    padding: 16,
    backgroundColor: '#FFFFFF',
    marginHorizontal: 16,
    marginBottom: 16,
    borderRadius: 12,
    elevation: 2,
  },
  statsTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#212121',
    marginBottom: 16,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  statCard: {
    width: '48%',
    backgroundColor: '#f8f9fa',
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
    marginBottom: 8,
  },
  statValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#2196F3',
  },
  statLabel: {
    fontSize: 12,
    color: '#757575',
    marginTop: 4,
    textAlign: 'center',
  },
  pointsSection: {
    padding: 16,
    backgroundColor: '#FFFFFF',
    marginHorizontal: 16,
    marginBottom: 16,
    borderRadius: 12,
    elevation: 2,
  },
  pointsTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#212121',
    marginBottom: 16,
  },
  pointCard: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    backgroundColor: '#f8f9fa',
    borderRadius: 8,
    marginBottom: 8,
  },
  pointInfo: {
    flex: 1,
  },
  pointLabel: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#212121',
  },
  pointCoords: {
    fontSize: 12,
    color: '#757575',
    fontFamily: 'monospace',
    marginTop: 2,
  },
  pointType: {
    fontSize: 12,
    color: '#2196F3',
    marginTop: 2,
  },
  pointIndicator: {
    width: 16,
    height: 16,
    borderRadius: 8,
    marginLeft: 12,
  },
  bottomControls: {
    flexDirection: 'row',
    padding: 16,
    backgroundColor: '#FFFFFF',
    borderTopWidth: 1,
    borderTopColor: '#E0E0E0',
  },
  addPointButton: {
    flex: 1,
    backgroundColor: '#4CAF50',
    paddingVertical: 12,
    borderRadius: 8,
    marginRight: 8,
    alignItems: 'center',
  },
  addPointButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  startARButton: {
    flex: 1,
    backgroundColor: '#2196F3',
    paddingVertical: 12,
    borderRadius: 8,
    marginLeft: 8,
    alignItems: 'center',
  },
  startARButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  pointDetailsModal: {
    backgroundColor: '#FFFFFF',
    width: '90%',
    borderRadius: 12,
    padding: 20,
  },
  pointDetailsTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#212121',
    textAlign: 'center',
    marginBottom: 16,
  },
  pointDetailsContent: {
    marginBottom: 20,
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },
  detailLabel: {
    fontSize: 14,
    color: '#424242',
    fontWeight: '500',
  },
  detailValue: {
    fontSize: 14,
    color: '#212121',
    fontWeight: 'bold',
    fontFamily: 'monospace',
  },
  pointDetailsActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  navigateButton: {
    flex: 1,
    backgroundColor: '#4CAF50',
    paddingVertical: 12,
    borderRadius: 8,
    marginRight: 8,
    alignItems: 'center',
  },
  navigateButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: 'bold',
  },
  closeButton: {
    flex: 1,
    backgroundColor: '#757575',
    paddingVertical: 12,
    borderRadius: 8,
    marginLeft: 8,
    alignItems: 'center',
  },
  closeButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: 'bold',
  },
  settingsModal: {
    backgroundColor: '#FFFFFF',
    width: '90%',
    maxHeight: '80%',
    borderRadius: 12,
    padding: 20,
  },
  settingsTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#212121',
    textAlign: 'center',
    marginBottom: 16,
  },
  settingsContent: {
    maxHeight: 400,
  },
  settingRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },
  settingLabel: {
    fontSize: 16,
    color: '#212121',
  },
  settingValue: {
    fontSize: 14,
    color: '#757575',
    fontWeight: 'bold',
  },
  closeSettingsButton: {
    backgroundColor: '#2196F3',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 16,
  },
  closeSettingsButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default ARScreen;

