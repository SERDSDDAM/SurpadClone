import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Alert,
  Modal,
  FlatList,
  Switch,
  TextInput,
} from 'react-native';
import CADGISService, {
  CADDrawing,
  GISDataset,
  ExportOptions,
  ImportResult,
} from '../services/CADGISService';

interface CADGISScreenProps {
  onNavigate?: (screen: string) => void;
}

const CADGISScreen: React.FC<CADGISScreenProps> = ({ onNavigate }) => {
  const [importedData, setImportedData] = useState<(CADDrawing | GISDataset)[]>([]);
  const [selectedData, setSelectedData] = useState<CADDrawing | GISDataset | null>(null);
  const [showExportModal, setShowExportModal] = useState(false);
  const [showImportHistory, setShowImportHistory] = useState(false);
  const [exportOptions, setExportOptions] = useState<ExportOptions>({
    format: 'GeoJSON',
    includeAttributes: true,
    precision: 6,
  });
  const [isImporting, setIsImporting] = useState(false);
  const [importHistory, setImportHistory] = useState<ImportResult[]>([]);

  useEffect(() => {
    loadImportHistory();
  }, []);

  /**
   * تحميل تاريخ الاستيراد
   */
  const loadImportHistory = () => {
    // محاكاة تحميل تاريخ الاستيراد من التخزين المحلي
    const mockHistory: ImportResult[] = [
      {
        success: true,
        data: {
          id: 'sample_1',
          name: 'مسح أراضي المنطقة الشمالية',
          description: 'بيانات مسح شاملة للمنطقة الشمالية',
          units: 'meters',
          coordinateSystem: 'WGS84',
          points: [],
          lines: [],
          polygons: [],
          layers: ['SURVEY_POINTS', 'BOUNDARIES'],
          bounds: { minX: 44.1900, minY: 15.3690, maxX: 44.1920, maxY: 15.3710 },
          metadata: {
            source: 'DXF Import',
            imported: '2024-01-15T10:30:00Z',
            pointCount: 25,
          },
        } as CADDrawing,
      },
      {
        success: true,
        data: {
          id: 'sample_2',
          name: 'نقاط GPS المرجعية',
          crs: 'WGS84',
          features: [],
          bounds: [44.1850, 15.3650, 44.1950, 15.3750],
          metadata: {
            source: 'GeoJSON Import',
            imported: '2024-01-10T14:20:00Z',
            featureCount: 15,
          },
        } as GISDataset,
      },
    ];
    
    setImportHistory(mockHistory);
    setImportedData(mockHistory.filter(h => h.success && h.data).map(h => h.data!));
  };

  /**
   * استيراد ملف جديد
   */
  const handleImport = async () => {
    setIsImporting(true);
    
    try {
      const result = await CADGISService.importFile();
      
      if (result.success && result.data) {
        setImportedData(prev => [...prev, result.data!]);
        setImportHistory(prev => [result, ...prev]);
        
        Alert.alert(
          'نجح الاستيراد',
          `تم استيراد الملف بنجاح!\n\nالاسم: ${result.data.name}\nالنوع: ${'points' in result.data ? 'CAD' : 'GIS'}`,
          [
            { text: 'موافق' },
            {
              text: 'عرض البيانات',
              onPress: () => setSelectedData(result.data!),
            },
          ]
        );
        
        if (result.warnings && result.warnings.length > 0) {
          setTimeout(() => {
            Alert.alert('تحذيرات', result.warnings!.join('\n'));
          }, 1000);
        }
      } else {
        Alert.alert(
          'فشل الاستيراد',
          result.errors?.join('\n') || 'حدث خطأ غير معروف'
        );
      }
    } catch (error) {
      Alert.alert('خطأ', 'حدث خطأ أثناء استيراد الملف');
    } finally {
      setIsImporting(false);
    }
  };

  /**
   * تصدير البيانات المحددة
   */
  const handleExport = async () => {
    if (!selectedData) {
      Alert.alert('خطأ', 'يرجى اختيار البيانات المراد تصديرها');
      return;
    }

    try {
      const success = await CADGISService.exportData(selectedData, exportOptions);
      
      if (success) {
        setShowExportModal(false);
        Alert.alert('نجح التصدير', 'تم تصدير البيانات بنجاح');
      }
    } catch (error) {
      Alert.alert('خطأ في التصدير', error.message);
    }
  };

  /**
   * تحويل نقاط المسح الحالية إلى CAD
   */
  const convertCurrentSurveyPoints = () => {
    // محاكاة نقاط المسح الحالية
    const mockSurveyPoints = [
      {
        id: 'sp1',
        latitude: 15.3695,
        longitude: 44.1910,
        altitude: 2200,
        label: 'نقطة مرجعية 1',
        type: 'reference',
        accuracy: 0.5,
        timestamp: new Date().toISOString(),
      },
      {
        id: 'sp2',
        latitude: 15.3700,
        longitude: 44.1915,
        altitude: 2205,
        label: 'زاوية شمالية',
        type: 'boundary',
        accuracy: 0.3,
        timestamp: new Date().toISOString(),
      },
      {
        id: 'sp3',
        latitude: 15.3690,
        longitude: 44.1905,
        altitude: 2195,
        label: 'زاوية جنوبية',
        type: 'boundary',
        accuracy: 0.4,
        timestamp: new Date().toISOString(),
      },
    ];

    const cadDrawing = CADGISService.convertSurveyPointsToCAD(
      mockSurveyPoints,
      'نقاط المسح الحالية'
    );

    setImportedData(prev => [...prev, cadDrawing]);
    setSelectedData(cadDrawing);
    
    Alert.alert(
      'تم التحويل',
      `تم تحويل ${mockSurveyPoints.length} نقطة مسح إلى تنسيق CAD`,
      [
        { text: 'موافق' },
        {
          text: 'عرض البيانات',
          onPress: () => setSelectedData(cadDrawing),
        },
      ]
    );
  };

  /**
   * حذف البيانات المحددة
   */
  const deleteSelectedData = () => {
    if (!selectedData) return;

    Alert.alert(
      'تأكيد الحذف',
      `هل أنت متأكد من حذف "${selectedData.name}"؟`,
      [
        { text: 'إلغاء', style: 'cancel' },
        {
          text: 'حذف',
          style: 'destructive',
          onPress: () => {
            setImportedData(prev => prev.filter(data => data.id !== selectedData.id));
            setSelectedData(null);
            Alert.alert('تم الحذف', 'تم حذف البيانات بنجاح');
          },
        },
      ]
    );
  };

  /**
   * تنسيق التاريخ
   */
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString('ar-SA');
  };

  /**
   * الحصول على نوع البيانات
   */
  const getDataType = (data: CADDrawing | GISDataset): string => {
    return 'points' in data ? 'CAD' : 'GIS';
  };

  /**
   * الحصول على عدد العناصر
   */
  const getItemCount = (data: CADDrawing | GISDataset): number => {
    return 'points' in data ? data.points.length : data.features.length;
  };

  /**
   * عرض نافذة التصدير
   */
  const renderExportModal = () => (
    <Modal
      visible={showExportModal}
      animationType="slide"
      transparent={true}
      onRequestClose={() => setShowExportModal(false)}
    >
      <View style={styles.modalOverlay}>
        <View style={styles.exportModal}>
          <Text style={styles.modalTitle}>خيارات التصدير</Text>
          
          <ScrollView style={styles.exportOptions}>
            <View style={styles.optionGroup}>
              <Text style={styles.optionLabel}>تنسيق التصدير:</Text>
              <View style={styles.formatSelector}>
                {CADGISService.getSupportedExportFormats().map(format => (
                  <TouchableOpacity
                    key={format}
                    style={[
                      styles.formatOption,
                      exportOptions.format === format && styles.selectedFormat
                    ]}
                    onPress={() => setExportOptions(prev => ({ ...prev, format: format as any }))}
                  >
                    <Text style={[
                      styles.formatText,
                      exportOptions.format === format && styles.selectedFormatText
                    ]}>
                      {format}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>

            <View style={styles.optionGroup}>
              <View style={styles.switchOption}>
                <Text style={styles.optionLabel}>تضمين الخصائص:</Text>
                <Switch
                  value={exportOptions.includeAttributes}
                  onValueChange={(value) => 
                    setExportOptions(prev => ({ ...prev, includeAttributes: value }))
                  }
                />
              </View>
            </View>

            <View style={styles.optionGroup}>
              <Text style={styles.optionLabel}>دقة الإحداثيات:</Text>
              <TextInput
                style={styles.precisionInput}
                value={exportOptions.precision?.toString() || '6'}
                onChangeText={(text) => {
                  const precision = parseInt(text) || 6;
                  setExportOptions(prev => ({ ...prev, precision }));
                }}
                keyboardType="numeric"
                placeholder="6"
              />
              <Text style={styles.precisionHint}>عدد الأرقام العشرية</Text>
            </View>

            {selectedData && 'layers' in selectedData && selectedData.layers.length > 0 && (
              <View style={styles.optionGroup}>
                <Text style={styles.optionLabel}>الطبقات المحددة:</Text>
                {selectedData.layers.map(layer => (
                  <View key={layer} style={styles.layerOption}>
                    <Switch
                      value={!exportOptions.layers || exportOptions.layers.includes(layer)}
                      onValueChange={(value) => {
                        setExportOptions(prev => {
                          const layers = prev.layers || selectedData.layers;
                          return {
                            ...prev,
                            layers: value 
                              ? [...(layers.filter(l => l !== layer)), layer]
                              : layers.filter(l => l !== layer)
                          };
                        });
                      }}
                    />
                    <Text style={styles.layerText}>{layer}</Text>
                  </View>
                ))}
              </View>
            )}
          </ScrollView>

          <View style={styles.exportActions}>
            <TouchableOpacity
              style={styles.exportButton}
              onPress={handleExport}
            >
              <Text style={styles.exportButtonText}>تصدير</Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={styles.cancelButton}
              onPress={() => setShowExportModal(false)}
            >
              <Text style={styles.cancelButtonText}>إلغاء</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );

  /**
   * عرض نافذة تاريخ الاستيراد
   */
  const renderImportHistoryModal = () => (
    <Modal
      visible={showImportHistory}
      animationType="slide"
      transparent={true}
      onRequestClose={() => setShowImportHistory(false)}
    >
      <View style={styles.modalOverlay}>
        <View style={styles.historyModal}>
          <Text style={styles.modalTitle}>تاريخ الاستيراد</Text>
          
          <FlatList
            data={importHistory}
            keyExtractor={(item, index) => index.toString()}
            renderItem={({ item, index }) => (
              <View style={styles.historyItem}>
                <View style={styles.historyStatus}>
                  <Text style={[
                    styles.statusText,
                    { color: item.success ? '#4CAF50' : '#F44336' }
                  ]}>
                    {item.success ? '✅ نجح' : '❌ فشل'}
                  </Text>
                </View>
                
                {item.data && (
                  <View style={styles.historyDetails}>
                    <Text style={styles.historyName}>{item.data.name}</Text>
                    <Text style={styles.historyType}>
                      النوع: {getDataType(item.data)} | العناصر: {getItemCount(item.data)}
                    </Text>
                    <Text style={styles.historyDate}>
                      {formatDate(item.data.metadata.imported)}
                    </Text>
                  </View>
                )}
                
                {item.errors && item.errors.length > 0 && (
                  <Text style={styles.historyErrors}>
                    الأخطاء: {item.errors.join(', ')}
                  </Text>
                )}
                
                {item.warnings && item.warnings.length > 0 && (
                  <Text style={styles.historyWarnings}>
                    تحذيرات: {item.warnings.join(', ')}
                  </Text>
                )}
              </View>
            )}
            ListEmptyComponent={
              <Text style={styles.emptyText}>لا يوجد تاريخ استيراد</Text>
            }
          />
          
          <TouchableOpacity
            style={styles.closeButton}
            onPress={() => setShowImportHistory(false)}
          >
            <Text style={styles.closeButtonText}>إغلاق</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );

  return (
    <View style={styles.container}>
      <ScrollView style={styles.content}>
        {/* قسم الاستيراد */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>استيراد البيانات</Text>
          
          <View style={styles.importSection}>
            <Text style={styles.supportedFormats}>
              التنسيقات المدعومة: {CADGISService.getSupportedImportFormats().join(', ')}
            </Text>
            
            <View style={styles.importActions}>
              <TouchableOpacity
                style={[styles.actionButton, isImporting && styles.disabledButton]}
                onPress={handleImport}
                disabled={isImporting}
              >
                <Text style={styles.actionButtonText}>
                  {isImporting ? 'جاري الاستيراد...' : 'استيراد ملف'}
                </Text>
              </TouchableOpacity>
              
              <TouchableOpacity
                style={styles.secondaryButton}
                onPress={convertCurrentSurveyPoints}
              >
                <Text style={styles.secondaryButtonText}>تحويل نقاط المسح</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>

        {/* قسم البيانات المستوردة */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>البيانات المستوردة ({importedData.length})</Text>
            
            <TouchableOpacity
              style={styles.historyButton}
              onPress={() => setShowImportHistory(true)}
            >
              <Text style={styles.historyButtonText}>التاريخ</Text>
            </TouchableOpacity>
          </View>
          
          {importedData.length === 0 ? (
            <View style={styles.emptyState}>
              <Text style={styles.emptyText}>لا توجد بيانات مستوردة</Text>
              <Text style={styles.emptyHint}>
                استخدم زر "استيراد ملف" لإضافة بيانات CAD أو GIS
              </Text>
            </View>
          ) : (
            <FlatList
              data={importedData}
              keyExtractor={(item) => item.id}
              renderItem={({ item }) => (
                <TouchableOpacity
                  style={[
                    styles.dataItem,
                    selectedData?.id === item.id && styles.selectedDataItem
                  ]}
                  onPress={() => setSelectedData(item)}
                >
                  <View style={styles.dataInfo}>
                    <Text style={styles.dataName}>{item.name}</Text>
                    <Text style={styles.dataType}>
                      النوع: {getDataType(item)} | العناصر: {getItemCount(item)}
                    </Text>
                    {item.description && (
                      <Text style={styles.dataDescription}>{item.description}</Text>
                    )}
                    <Text style={styles.dataDate}>
                      مستورد: {formatDate(item.metadata.imported)}
                    </Text>
                  </View>
                  
                  <View style={styles.dataActions}>
                    {selectedData?.id === item.id && (
                      <View style={styles.selectedIndicator}>
                        <Text style={styles.selectedText}>محدد</Text>
                      </View>
                    )}
                  </View>
                </TouchableOpacity>
              )}
              scrollEnabled={false}
            />
          )}
        </View>

        {/* قسم الإجراءات */}
        {selectedData && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>إجراءات البيانات المحددة</Text>
            
            <View style={styles.selectedDataInfo}>
              <Text style={styles.selectedDataName}>{selectedData.name}</Text>
              <Text style={styles.selectedDataDetails}>
                النوع: {getDataType(selectedData)} | العناصر: {getItemCount(selectedData)}
              </Text>
              
              {'bounds' in selectedData && (
                <Text style={styles.boundsInfo}>
                  الحدود: {selectedData.bounds.minX.toFixed(4)}, {selectedData.bounds.minY.toFixed(4)} إلى {selectedData.bounds.maxX.toFixed(4)}, {selectedData.bounds.maxY.toFixed(4)}
                </Text>
              )}
              
              {'layers' in selectedData && selectedData.layers.length > 0 && (
                <Text style={styles.layersInfo}>
                  الطبقات: {selectedData.layers.join(', ')}
                </Text>
              )}
            </View>
            
            <View style={styles.dataActions}>
              <TouchableOpacity
                style={styles.actionButton}
                onPress={() => setShowExportModal(true)}
              >
                <Text style={styles.actionButtonText}>تصدير</Text>
              </TouchableOpacity>
              
              <TouchableOpacity
                style={styles.secondaryButton}
                onPress={() => {
                  // عرض البيانات على الخريطة
                  Alert.alert(
                    'عرض على الخريطة',
                    'سيتم عرض البيانات على الخريطة',
                    [
                      { text: 'إلغاء' },
                      { text: 'عرض', onPress: () => onNavigate?.('map') },
                    ]
                  );
                }}
              >
                <Text style={styles.secondaryButtonText}>عرض على الخريطة</Text>
              </TouchableOpacity>
              
              <TouchableOpacity
                style={[styles.actionButton, styles.dangerButton]}
                onPress={deleteSelectedData}
              >
                <Text style={[styles.actionButtonText, styles.dangerButtonText]}>حذف</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}

        {/* معلومات إضافية */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>معلومات</Text>
          
          <Text style={styles.infoText}>
            تكامل CAD/GIS يتيح لك استيراد وتصدير بيانات المسح بتنسيقات مختلفة:
          </Text>
          
          <View style={styles.featuresList}>
            <Text style={styles.featureItem}>• استيراد ملفات DXF من برامج CAD</Text>
            <Text style={styles.featureItem}>• تصدير البيانات إلى GeoJSON للـ GIS</Text>
            <Text style={styles.featureItem}>• دعم ملفات KML لـ Google Earth</Text>
            <Text style={styles.featureItem}>• تحويل نقاط المسح إلى تنسيقات مختلفة</Text>
            <Text style={styles.featureItem}>• حفظ الطبقات والخصائص</Text>
          </View>
          
          <Text style={styles.infoText}>
            يمكنك استخدام هذه الميزة لتبادل البيانات مع برامج CAD مثل AutoCAD أو 
            أنظمة GIS مثل QGIS و ArcGIS.
          </Text>
        </View>
      </ScrollView>

      {renderExportModal()}
      {renderImportHistoryModal()}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  content: {
    flex: 1,
  },
  section: {
    backgroundColor: '#FFFFFF',
    margin: 16,
    borderRadius: 12,
    padding: 16,
    elevation: 2,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#212121',
    marginBottom: 12,
  },
  importSection: {
    gap: 12,
  },
  supportedFormats: {
    fontSize: 12,
    color: '#757575',
    fontStyle: 'italic',
  },
  importActions: {
    gap: 8,
  },
  actionButton: {
    backgroundColor: '#2196F3',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
    alignItems: 'center',
  },
  actionButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  secondaryButton: {
    backgroundColor: '#4CAF50',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
    alignItems: 'center',
  },
  secondaryButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  disabledButton: {
    backgroundColor: '#BDBDBD',
  },
  dangerButton: {
    backgroundColor: '#F44336',
  },
  dangerButtonText: {
    color: '#FFFFFF',
  },
  historyButton: {
    backgroundColor: '#FF9800',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 6,
  },
  historyButtonText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: 'bold',
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 32,
  },
  emptyText: {
    fontSize: 16,
    color: '#757575',
    textAlign: 'center',
    marginBottom: 8,
  },
  emptyHint: {
    fontSize: 14,
    color: '#9E9E9E',
    textAlign: 'center',
  },
  dataItem: {
    backgroundColor: '#f8f9fa',
    padding: 12,
    borderRadius: 8,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: '#E0E0E0',
  },
  selectedDataItem: {
    borderColor: '#2196F3',
    backgroundColor: '#E3F2FD',
  },
  dataInfo: {
    flex: 1,
  },
  dataName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#212121',
  },
  dataType: {
    fontSize: 12,
    color: '#757575',
    marginTop: 2,
  },
  dataDescription: {
    fontSize: 14,
    color: '#424242',
    marginTop: 4,
  },
  dataDate: {
    fontSize: 10,
    color: '#9E9E9E',
    marginTop: 4,
  },
  dataActions: {
    alignItems: 'flex-end',
  },
  selectedIndicator: {
    backgroundColor: '#2196F3',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 4,
  },
  selectedText: {
    color: '#FFFFFF',
    fontSize: 10,
    fontWeight: 'bold',
  },
  selectedDataInfo: {
    backgroundColor: '#E3F2FD',
    padding: 12,
    borderRadius: 8,
    marginBottom: 16,
  },
  selectedDataName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1976D2',
  },
  selectedDataDetails: {
    fontSize: 14,
    color: '#424242',
    marginTop: 4,
  },
  boundsInfo: {
    fontSize: 12,
    color: '#757575',
    marginTop: 4,
    fontFamily: 'monospace',
  },
  layersInfo: {
    fontSize: 12,
    color: '#757575',
    marginTop: 4,
  },
  infoText: {
    fontSize: 14,
    color: '#424242',
    lineHeight: 20,
    marginBottom: 12,
  },
  featuresList: {
    marginVertical: 8,
  },
  featureItem: {
    fontSize: 14,
    color: '#424242',
    marginBottom: 4,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  exportModal: {
    backgroundColor: '#FFFFFF',
    width: '90%',
    maxHeight: '80%',
    borderRadius: 12,
    padding: 20,
  },
  historyModal: {
    backgroundColor: '#FFFFFF',
    width: '90%',
    maxHeight: '80%',
    borderRadius: 12,
    padding: 20,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#212121',
    textAlign: 'center',
    marginBottom: 16,
  },
  exportOptions: {
    maxHeight: 400,
  },
  optionGroup: {
    marginBottom: 16,
  },
  optionLabel: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#212121',
    marginBottom: 8,
  },
  formatSelector: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  formatOption: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderWidth: 1,
    borderColor: '#E0E0E0',
    borderRadius: 6,
    backgroundColor: '#f8f9fa',
  },
  selectedFormat: {
    backgroundColor: '#2196F3',
    borderColor: '#2196F3',
  },
  formatText: {
    fontSize: 14,
    color: '#424242',
  },
  selectedFormatText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
  },
  switchOption: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  precisionInput: {
    borderWidth: 1,
    borderColor: '#E0E0E0',
    borderRadius: 6,
    paddingHorizontal: 12,
    paddingVertical: 8,
    fontSize: 16,
    width: 80,
  },
  precisionHint: {
    fontSize: 12,
    color: '#757575',
    marginTop: 4,
  },
  layerOption: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 4,
  },
  layerText: {
    fontSize: 14,
    color: '#424242',
    marginLeft: 8,
  },
  exportActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 16,
  },
  exportButton: {
    flex: 1,
    backgroundColor: '#4CAF50',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
    marginRight: 8,
  },
  exportButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  cancelButton: {
    flex: 1,
    backgroundColor: '#757575',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
    marginLeft: 8,
  },
  cancelButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  historyItem: {
    backgroundColor: '#f8f9fa',
    padding: 12,
    borderRadius: 8,
    marginBottom: 8,
  },
  historyStatus: {
    marginBottom: 8,
  },
  statusText: {
    fontSize: 14,
    fontWeight: 'bold',
  },
  historyDetails: {
    marginBottom: 8,
  },
  historyName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#212121',
  },
  historyType: {
    fontSize: 12,
    color: '#757575',
    marginTop: 2,
  },
  historyDate: {
    fontSize: 10,
    color: '#9E9E9E',
    marginTop: 2,
  },
  historyErrors: {
    fontSize: 12,
    color: '#F44336',
    marginTop: 4,
  },
  historyWarnings: {
    fontSize: 12,
    color: '#FF9800',
    marginTop: 4,
  },
  closeButton: {
    backgroundColor: '#2196F3',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 16,
  },
  closeButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default CADGISScreen;

