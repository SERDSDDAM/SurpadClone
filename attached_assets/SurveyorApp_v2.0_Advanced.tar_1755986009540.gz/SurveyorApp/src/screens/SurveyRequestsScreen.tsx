/**
 * شاشة طلبات المسح المساحي
 * Survey Requests Screen
 */

import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  Alert,
  Modal,
  TextInput,
} from 'react-native';

interface SurveyRequestsScreenProps {
  onNavigate: (screen: string) => void;
}

interface SurveyRequest {
  id: string;
  title: string;
  location: string;
  status: 'pending' | 'in_progress' | 'completed' | 'rejected';
  date: string;
  priority: 'high' | 'medium' | 'low';
  description: string;
}

const SurveyRequestsScreen: React.FC<SurveyRequestsScreenProps> = ({ onNavigate }) => {
  const [showNewRequestModal, setShowNewRequestModal] = useState(false);
  const [newRequest, setNewRequest] = useState({
    title: '',
    location: '',
    description: '',
  });

  // بيانات وهمية للطلبات
  const [requests, setRequests] = useState<SurveyRequest[]>([
    {
      id: '1',
      title: 'مسح أرض سكنية - صنعاء',
      location: 'حي الحصبة، صنعاء',
      status: 'in_progress',
      date: '2024-01-15',
      priority: 'high',
      description: 'مسح مساحي لأرض سكنية بمساحة 400 متر مربع',
    },
    {
      id: '2',
      title: 'مسح مبنى تجاري - عدن',
      location: 'كريتر، عدن',
      status: 'pending',
      date: '2024-01-14',
      priority: 'medium',
      description: 'مسح مساحي لمبنى تجاري من 3 طوابق',
    },
    {
      id: '3',
      title: 'مسح مجمع سكني - تعز',
      location: 'الحوبان، تعز',
      status: 'completed',
      date: '2024-01-10',
      priority: 'low',
      description: 'مسح مساحي لمجمع سكني يحتوي على 20 وحدة',
    },
  ]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return '#FF9800';
      case 'in_progress':
        return '#2196F3';
      case 'completed':
        return '#4CAF50';
      case 'rejected':
        return '#F44336';
      default:
        return '#666';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'pending':
        return 'قيد الانتظار';
      case 'in_progress':
        return 'قيد التنفيذ';
      case 'completed':
        return 'مكتمل';
      case 'rejected':
        return 'مرفوض';
      default:
        return 'غير محدد';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high':
        return '#F44336';
      case 'medium':
        return '#FF9800';
      case 'low':
        return '#4CAF50';
      default:
        return '#666';
    }
  };

  const getPriorityText = (priority: string) => {
    switch (priority) {
      case 'high':
        return 'عالية';
      case 'medium':
        return 'متوسطة';
      case 'low':
        return 'منخفضة';
      default:
        return 'غير محدد';
    }
  };

  const handleCreateRequest = () => {
    if (!newRequest.title.trim() || !newRequest.location.trim()) {
      Alert.alert('خطأ', 'يرجى إدخال العنوان والموقع على الأقل');
      return;
    }

    const request: SurveyRequest = {
      id: Date.now().toString(),
      title: newRequest.title,
      location: newRequest.location,
      description: newRequest.description,
      status: 'pending',
      date: new Date().toISOString().split('T')[0],
      priority: 'medium',
    };

    setRequests([request, ...requests]);
    setNewRequest({ title: '', location: '', description: '' });
    setShowNewRequestModal(false);
    Alert.alert('نجح', 'تم إنشاء الطلب بنجاح');
  };

  const handleRequestPress = (request: SurveyRequest) => {
    Alert.alert(
      request.title,
      `الموقع: ${request.location}\nالحالة: ${getStatusText(request.status)}\nالأولوية: ${getPriorityText(request.priority)}\nالتاريخ: ${request.date}\n\nالوصف: ${request.description}`,
      [
        { text: 'إغلاق', style: 'cancel' },
        { text: 'عرض على الخريطة', onPress: () => onNavigate('map') },
      ]
    );
  };

  return (
    <View style={styles.container}>
      {/* رأس الشاشة */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>طلبات المسح المساحي</Text>
        <TouchableOpacity
          style={styles.newRequestButton}
          onPress={() => setShowNewRequestModal(true)}
        >
          <Text style={styles.newRequestButtonText}>+ طلب جديد</Text>
        </TouchableOpacity>
      </View>

      {/* قائمة الطلبات */}
      <ScrollView style={styles.requestsList} showsVerticalScrollIndicator={false}>
        {requests.map((request) => (
          <TouchableOpacity
            key={request.id}
            style={styles.requestCard}
            onPress={() => handleRequestPress(request)}
          >
            <View style={styles.requestHeader}>
              <View style={styles.requestInfo}>
                <Text style={styles.requestTitle}>{request.title}</Text>
                <Text style={styles.requestLocation}>📍 {request.location}</Text>
              </View>
              <View style={styles.requestBadges}>
                <View style={[styles.statusBadge, { backgroundColor: getStatusColor(request.status) }]}>
                  <Text style={styles.statusText}>{getStatusText(request.status)}</Text>
                </View>
                <View style={[styles.priorityBadge, { borderColor: getPriorityColor(request.priority) }]}>
                  <Text style={[styles.priorityText, { color: getPriorityColor(request.priority) }]}>
                    {getPriorityText(request.priority)}
                  </Text>
                </View>
              </View>
            </View>
            
            <Text style={styles.requestDescription} numberOfLines={2}>
              {request.description}
            </Text>
            
            <View style={styles.requestFooter}>
              <Text style={styles.requestDate}>📅 {request.date}</Text>
              <Text style={styles.requestId}>#{request.id}</Text>
            </View>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* نافذة إنشاء طلب جديد */}
      <Modal
        visible={showNewRequestModal}
        animationType="slide"
        presentationStyle="pageSheet"
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <TouchableOpacity
              onPress={() => setShowNewRequestModal(false)}
              style={styles.modalCloseButton}
            >
              <Text style={styles.modalCloseText}>إلغاء</Text>
            </TouchableOpacity>
            <Text style={styles.modalTitle}>طلب مسح جديد</Text>
            <TouchableOpacity
              onPress={handleCreateRequest}
              style={styles.modalSaveButton}
            >
              <Text style={styles.modalSaveText}>حفظ</Text>
            </TouchableOpacity>
          </View>

          <ScrollView style={styles.modalContent}>
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>عنوان الطلب *</Text>
              <TextInput
                style={styles.textInput}
                value={newRequest.title}
                onChangeText={(text) => setNewRequest({ ...newRequest, title: text })}
                placeholder="مثال: مسح أرض سكنية"
                placeholderTextColor="#999"
                textAlign="right"
              />
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>الموقع *</Text>
              <TextInput
                style={styles.textInput}
                value={newRequest.location}
                onChangeText={(text) => setNewRequest({ ...newRequest, location: text })}
                placeholder="مثال: حي الحصبة، صنعاء"
                placeholderTextColor="#999"
                textAlign="right"
              />
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>وصف الطلب</Text>
              <TextInput
                style={[styles.textInput, styles.textArea]}
                value={newRequest.description}
                onChangeText={(text) => setNewRequest({ ...newRequest, description: text })}
                placeholder="تفاصيل إضافية عن المسح المطلوب..."
                placeholderTextColor="#999"
                multiline
                numberOfLines={4}
                textAlign="right"
                textAlignVertical="top"
              />
            </View>

            <View style={styles.noteContainer}>
              <Text style={styles.noteText}>
                ملاحظة: سيتم مراجعة الطلب من قبل الفريق المختص وسيتم التواصل معك خلال 24 ساعة.
              </Text>
            </View>
          </ScrollView>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F9FA',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    backgroundColor: 'white',
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  newRequestButton: {
    backgroundColor: '#2E7D32',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
  },
  newRequestButtonText: {
    color: 'white',
    fontSize: 14,
    fontWeight: 'bold',
  },
  requestsList: {
    flex: 1,
    padding: 16,
  },
  requestCard: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  requestHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 8,
  },
  requestInfo: {
    flex: 1,
  },
  requestTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'right',
    marginBottom: 4,
  },
  requestLocation: {
    fontSize: 14,
    color: '#666',
    textAlign: 'right',
  },
  requestBadges: {
    alignItems: 'flex-end',
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    marginBottom: 4,
  },
  statusText: {
    color: 'white',
    fontSize: 12,
    fontWeight: 'bold',
  },
  priorityBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    borderWidth: 1,
  },
  priorityText: {
    fontSize: 12,
    fontWeight: 'bold',
  },
  requestDescription: {
    fontSize: 14,
    color: '#666',
    textAlign: 'right',
    marginBottom: 12,
    lineHeight: 20,
  },
  requestFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderTopWidth: 1,
    borderTopColor: '#F0F0F0',
    paddingTop: 8,
  },
  requestDate: {
    fontSize: 12,
    color: '#666',
  },
  requestId: {
    fontSize: 12,
    color: '#999',
  },
  modalContainer: {
    flex: 1,
    backgroundColor: 'white',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
  },
  modalCloseButton: {
    padding: 8,
  },
  modalCloseText: {
    color: '#666',
    fontSize: 16,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  modalSaveButton: {
    padding: 8,
  },
  modalSaveText: {
    color: '#2E7D32',
    fontSize: 16,
    fontWeight: 'bold',
  },
  modalContent: {
    flex: 1,
    padding: 20,
  },
  inputGroup: {
    marginBottom: 20,
  },
  inputLabel: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 8,
    textAlign: 'right',
  },
  textInput: {
    borderWidth: 1,
    borderColor: '#DDD',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    backgroundColor: '#F9F9F9',
    textAlign: 'right',
  },
  textArea: {
    height: 100,
  },
  noteContainer: {
    backgroundColor: '#E3F2FD',
    padding: 16,
    borderRadius: 8,
    marginTop: 20,
  },
  noteText: {
    fontSize: 14,
    color: '#1976D2',
    textAlign: 'right',
    lineHeight: 20,
  },
});

export default SurveyRequestsScreen;

