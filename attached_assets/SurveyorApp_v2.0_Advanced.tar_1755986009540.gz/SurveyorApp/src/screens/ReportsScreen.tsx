import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Alert,
  Modal,
  TextInput,
  FlatList,
  Switch,
} from 'react-native';
import ReportService, {
  ReportData,
  ReportTemplate,
  ReportOptions,
  SurveyPoint,
  Measurement,
  ReportImage,
} from '../services/ReportService';

interface ReportsScreenProps {
  onNavigate?: (screen: string) => void;
}

const ReportsScreen: React.FC<ReportsScreenProps> = ({ onNavigate }) => {
  const [templates, setTemplates] = useState<ReportTemplate[]>([]);
  const [savedReports, setSavedReports] = useState<string[]>([]);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showTemplateModal, setShowTemplateModal] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);

  // خيارات إنشاء التقرير
  const [reportOptions, setReportOptions] = useState<ReportOptions>({
    format: 'PDF',
    template: 'basic_survey',
    includeImages: true,
    includeMap: true,
    includeCoordinates: true,
    coordinateFormat: 'decimal',
    language: 'ar',
  });

  // بيانات التقرير
  const [reportData, setReportData] = useState<Partial<ReportData>>({
    title: '',
    subtitle: '',
    author: 'المساح',
    organization: '',
    notes: [],
  });

  useEffect(() => {
    loadData();
  }, []);

  /**
   * تحميل البيانات
   */
  const loadData = async () => {
    try {
      const [templatesData, reportsData] = await Promise.all([
        ReportService.getAvailableTemplates(),
        ReportService.getSavedReports(),
      ]);
      
      setTemplates(templatesData);
      setSavedReports(reportsData);
    } catch (error) {
      Alert.alert('خطأ', 'فشل في تحميل البيانات');
    }
  };

  /**
   * إنشاء تقرير جديد
   */
  const generateReport = async () => {
    if (!reportData.title?.trim()) {
      Alert.alert('خطأ', 'يرجى إدخال عنوان التقرير');
      return;
    }

    setIsGenerating(true);

    try {
      // إنشاء بيانات تجريبية للتقرير
      const mockData: ReportData = {
        id: `report_${Date.now()}`,
        title: reportData.title.trim(),
        subtitle: reportData.subtitle?.trim(),
        date: new Date(),
        author: reportData.author || 'المساح',
        organization: reportData.organization?.trim(),
        surveyPoints: generateMockSurveyPoints(),
        measurements: generateMockMeasurements(),
        images: generateMockImages(),
        notes: reportData.notes || [],
        metadata: {
          generatedBy: 'Surveyor App',
          version: '2.0',
        },
      };

      // إنشاء التقرير
      const filePath = await ReportService.generateReport(mockData, reportOptions);
      
      // تحديث قائمة التقارير المحفوظة
      await loadData();
      
      setShowCreateModal(false);
      
      Alert.alert(
        'تم إنشاء التقرير',
        `تم إنشاء التقرير بنجاح بتنسيق ${reportOptions.format}`,
        [
          { text: 'موافق' },
          {
            text: 'مشاركة',
            onPress: () => shareReport(filePath, mockData.title),
          },
        ]
      );
    } catch (error) {
      Alert.alert('خطأ', error.message);
    } finally {
      setIsGenerating(false);
    }
  };

  /**
   * مشاركة تقرير
   */
  const shareReport = async (filePath: string, title: string) => {
    try {
      await ReportService.shareReport(filePath, title);
    } catch (error) {
      Alert.alert('خطأ', 'فشل في مشاركة التقرير');
    }
  };

  /**
   * حذف تقرير
   */
  const deleteReport = (filePath: string) => {
    const fileName = filePath.split('/').pop() || 'التقرير';
    
    Alert.alert(
      'تأكيد الحذف',
      `هل أنت متأكد من حذف "${fileName}"؟`,
      [
        { text: 'إلغاء', style: 'cancel' },
        {
          text: 'حذف',
          style: 'destructive',
          onPress: async () => {
            try {
              await ReportService.deleteReport(filePath);
              await loadData();
              Alert.alert('تم الحذف', 'تم حذف التقرير بنجاح');
            } catch (error) {
              Alert.alert('خطأ', 'فشل في حذف التقرير');
            }
          },
        },
      ]
    );
  };

  /**
   * إنشاء نقاط مسح تجريبية
   */
  const generateMockSurveyPoints = (): SurveyPoint[] => {
    return [
      {
        id: 'sp1',
        name: 'نقطة مرجعية 1',
        latitude: 15.3695,
        longitude: 44.1910,
        altitude: 2200,
        accuracy: 0.5,
        type: 'reference',
        description: 'نقطة مرجعية رئيسية',
        timestamp: new Date(),
        attributes: { code: 'REF001', importance: 'high' },
      },
      {
        id: 'sp2',
        name: 'زاوية شمالية شرقية',
        latitude: 15.3700,
        longitude: 44.1915,
        altitude: 2205,
        accuracy: 0.3,
        type: 'boundary',
        description: 'زاوية الحد الشمالي الشرقي',
        timestamp: new Date(),
        attributes: { code: 'BND001', corner: 'NE' },
      },
      {
        id: 'sp3',
        name: 'زاوية جنوبية غربية',
        latitude: 15.3690,
        longitude: 44.1905,
        altitude: 2195,
        accuracy: 0.4,
        type: 'boundary',
        description: 'زاوية الحد الجنوبي الغربي',
        timestamp: new Date(),
        attributes: { code: 'BND002', corner: 'SW' },
      },
      {
        id: 'sp4',
        name: 'نقطة وسطية',
        latitude: 15.3697,
        longitude: 44.1912,
        altitude: 2202,
        accuracy: 0.6,
        type: 'detail',
        description: 'نقطة تفصيلية في وسط المنطقة',
        timestamp: new Date(),
        attributes: { code: 'DTL001', feature: 'center' },
      },
    ];
  };

  /**
   * إنشاء قياسات تجريبية
   */
  const generateMockMeasurements = (): Measurement[] => {
    return [
      {
        id: 'm1',
        type: 'distance',
        value: 125.75,
        unit: 'متر',
        points: ['sp1', 'sp2'],
        description: 'المسافة بين النقطة المرجعية والزاوية الشمالية',
        accuracy: 0.02,
        timestamp: new Date(),
      },
      {
        id: 'm2',
        type: 'area',
        value: 15420.5,
        unit: 'متر مربع',
        points: ['sp1', 'sp2', 'sp3', 'sp4'],
        description: 'المساحة الإجمالية للمنطقة المسحية',
        accuracy: 2.1,
        timestamp: new Date(),
      },
      {
        id: 'm3',
        type: 'angle',
        value: 89.75,
        unit: 'درجة',
        points: ['sp1', 'sp2', 'sp3'],
        description: 'الزاوية بين الحدود الشمالية والشرقية',
        accuracy: 0.01,
        timestamp: new Date(),
      },
    ];
  };

  /**
   * إنشاء صور تجريبية
   */
  const generateMockImages = (): ReportImage[] => {
    return [
      {
        id: 'img1',
        path: '/path/to/site_overview.jpg',
        caption: 'نظرة عامة على موقع المسح',
        location: { latitude: 15.3695, longitude: 44.1910 },
        timestamp: new Date(),
        size: { width: 1920, height: 1080 },
      },
      {
        id: 'img2',
        path: '/path/to/reference_point.jpg',
        caption: 'النقطة المرجعية الرئيسية',
        location: { latitude: 15.3695, longitude: 44.1910 },
        timestamp: new Date(),
        size: { width: 1920, height: 1080 },
      },
    ];
  };

  /**
   * تنسيق اسم الملف للعرض
   */
  const formatFileName = (filePath: string): string => {
    const fileName = filePath.split('/').pop() || '';
    return fileName.replace(/\.[^/.]+$/, ''); // إزالة الامتداد
  };

  /**
   * تنسيق تاريخ الملف
   */
  const formatFileDate = (filePath: string): string => {
    // استخراج التاريخ من اسم الملف
    const fileName = filePath.split('/').pop() || '';
    const dateMatch = fileName.match(/(\d{4}-\d{2}-\d{2}T\d{2}-\d{2}-\d{2})/);
    
    if (dateMatch) {
      const dateStr = dateMatch[1].replace(/T/, ' ').replace(/-/g, ':');
      return new Date(dateStr).toLocaleString('ar-SA');
    }
    
    return 'غير محدد';
  };

  /**
   * عرض نافذة إنشاء تقرير جديد
   */
  const renderCreateModal = () => (
    <Modal
      visible={showCreateModal}
      animationType="slide"
      transparent={true}
      onRequestClose={() => setShowCreateModal(false)}
    >
      <View style={styles.modalOverlay}>
        <View style={styles.createModal}>
          <Text style={styles.modalTitle}>إنشاء تقرير جديد</Text>
          
          <ScrollView style={styles.createForm}>
            {/* معلومات أساسية */}
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>عنوان التقرير *</Text>
              <TextInput
                style={styles.textInput}
                value={reportData.title}
                onChangeText={(text) => setReportData(prev => ({ ...prev, title: text }))}
                placeholder="مثل: تقرير مسح الأراضي - المنطقة الشمالية"
              />
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>العنوان الفرعي</Text>
              <TextInput
                style={styles.textInput}
                value={reportData.subtitle}
                onChangeText={(text) => setReportData(prev => ({ ...prev, subtitle: text }))}
                placeholder="عنوان فرعي اختياري"
              />
            </View>

            <View style={styles.inputRow}>
              <View style={styles.inputHalf}>
                <Text style={styles.inputLabel}>المساح</Text>
                <TextInput
                  style={styles.textInput}
                  value={reportData.author}
                  onChangeText={(text) => setReportData(prev => ({ ...prev, author: text }))}
                  placeholder="اسم المساح"
                />
              </View>

              <View style={styles.inputHalf}>
                <Text style={styles.inputLabel}>المؤسسة</Text>
                <TextInput
                  style={styles.textInput}
                  value={reportData.organization}
                  onChangeText={(text) => setReportData(prev => ({ ...prev, organization: text }))}
                  placeholder="اسم المؤسسة"
                />
              </View>
            </View>

            {/* خيارات التقرير */}
            <View style={styles.optionsSection}>
              <Text style={styles.sectionTitle}>خيارات التقرير</Text>
              
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>تنسيق التصدير</Text>
                <View style={styles.formatSelector}>
                  {['PDF', 'HTML', 'DOCX', 'CSV'].map(format => (
                    <TouchableOpacity
                      key={format}
                      style={[
                        styles.formatOption,
                        reportOptions.format === format && styles.selectedFormat
                      ]}
                      onPress={() => setReportOptions(prev => ({ ...prev, format: format as any }))}
                    >
                      <Text style={[
                        styles.formatText,
                        reportOptions.format === format && styles.selectedFormatText
                      ]}>
                        {format}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>قالب التقرير</Text>
                <View style={styles.templateSelector}>
                  {templates.map(template => (
                    <TouchableOpacity
                      key={template.id}
                      style={[
                        styles.templateOption,
                        reportOptions.template === template.id && styles.selectedTemplate
                      ]}
                      onPress={() => setReportOptions(prev => ({ ...prev, template: template.id }))}
                    >
                      <Text style={[
                        styles.templateText,
                        reportOptions.template === template.id && styles.selectedTemplateText
                      ]}>
                        {template.name}
                      </Text>
                      {template.description && (
                        <Text style={styles.templateDescription}>
                          {template.description}
                        </Text>
                      )}
                    </TouchableOpacity>
                  ))}
                </View>
              </View>

              <View style={styles.switchGroup}>
                <View style={styles.switchOption}>
                  <Text style={styles.switchLabel}>تضمين الصور</Text>
                  <Switch
                    value={reportOptions.includeImages}
                    onValueChange={(value) => 
                      setReportOptions(prev => ({ ...prev, includeImages: value }))
                    }
                  />
                </View>

                <View style={styles.switchOption}>
                  <Text style={styles.switchLabel}>تضمين الخريطة</Text>
                  <Switch
                    value={reportOptions.includeMap}
                    onValueChange={(value) => 
                      setReportOptions(prev => ({ ...prev, includeMap: value }))
                    }
                  />
                </View>

                <View style={styles.switchOption}>
                  <Text style={styles.switchLabel}>تضمين الإحداثيات</Text>
                  <Switch
                    value={reportOptions.includeCoordinates}
                    onValueChange={(value) => 
                      setReportOptions(prev => ({ ...prev, includeCoordinates: value }))
                    }
                  />
                </View>
              </View>

              {reportOptions.includeCoordinates && (
                <View style={styles.inputGroup}>
                  <Text style={styles.inputLabel}>تنسيق الإحداثيات</Text>
                  <View style={styles.coordinateSelector}>
                    <TouchableOpacity
                      style={[
                        styles.coordinateOption,
                        reportOptions.coordinateFormat === 'decimal' && styles.selectedCoordinate
                      ]}
                      onPress={() => setReportOptions(prev => ({ ...prev, coordinateFormat: 'decimal' }))}
                    >
                      <Text style={[
                        styles.coordinateText,
                        reportOptions.coordinateFormat === 'decimal' && styles.selectedCoordinateText
                      ]}>
                        عشري (15.3695)
                      </Text>
                    </TouchableOpacity>

                    <TouchableOpacity
                      style={[
                        styles.coordinateOption,
                        reportOptions.coordinateFormat === 'dms' && styles.selectedCoordinate
                      ]}
                      onPress={() => setReportOptions(prev => ({ ...prev, coordinateFormat: 'dms' }))}
                    >
                      <Text style={[
                        styles.coordinateText,
                        reportOptions.coordinateFormat === 'dms' && styles.selectedCoordinateText
                      ]}>
                        درجات ودقائق وثوان
                      </Text>
                    </TouchableOpacity>
                  </View>
                </View>
              )}
            </View>
          </ScrollView>

          <View style={styles.modalActions}>
            <TouchableOpacity
              style={[styles.generateButton, isGenerating && styles.disabledButton]}
              onPress={generateReport}
              disabled={isGenerating}
            >
              <Text style={styles.generateButtonText}>
                {isGenerating ? 'جاري الإنشاء...' : 'إنشاء التقرير'}
              </Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={styles.cancelButton}
              onPress={() => setShowCreateModal(false)}
            >
              <Text style={styles.cancelButtonText}>إلغاء</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );

  /**
   * عرض نافذة القوالب
   */
  const renderTemplateModal = () => (
    <Modal
      visible={showTemplateModal}
      animationType="slide"
      transparent={true}
      onRequestClose={() => setShowTemplateModal(false)}
    >
      <View style={styles.modalOverlay}>
        <View style={styles.templateModal}>
          <Text style={styles.modalTitle}>قوالب التقارير</Text>
          
          <FlatList
            data={templates}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => (
              <View style={styles.templateCard}>
                <Text style={styles.templateName}>{item.name}</Text>
                {item.description && (
                  <Text style={styles.templateCardDescription}>{item.description}</Text>
                )}
                
                <View style={styles.templateSections}>
                  <Text style={styles.sectionsLabel}>الأقسام المتضمنة:</Text>
                  {item.sections.map(section => (
                    <Text key={section.id} style={styles.sectionItem}>
                      • {section.title}
                    </Text>
                  ))}
                </View>
                
                {item.isDefault && (
                  <View style={styles.defaultBadge}>
                    <Text style={styles.defaultText}>افتراضي</Text>
                  </View>
                )}
              </View>
            )}
          />
          
          <TouchableOpacity
            style={styles.closeButton}
            onPress={() => setShowTemplateModal(false)}
          >
            <Text style={styles.closeButtonText}>إغلاق</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );

  return (
    <View style={styles.container}>
      <ScrollView style={styles.content}>
        {/* قسم الإجراءات */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>إنشاء التقارير</Text>
          
          <View style={styles.actionButtons}>
            <TouchableOpacity
              style={styles.createButton}
              onPress={() => setShowCreateModal(true)}
            >
              <Text style={styles.createButtonText}>إنشاء تقرير جديد</Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={styles.templatesButton}
              onPress={() => setShowTemplateModal(true)}
            >
              <Text style={styles.templatesButtonText}>عرض القوالب</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* قسم التقارير المحفوظة */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>التقارير المحفوظة ({savedReports.length})</Text>
          
          {savedReports.length === 0 ? (
            <View style={styles.emptyState}>
              <Text style={styles.emptyText}>لا توجد تقارير محفوظة</Text>
              <Text style={styles.emptyHint}>
                اضغط على "إنشاء تقرير جديد" لإنشاء أول تقرير
              </Text>
            </View>
          ) : (
            <FlatList
              data={savedReports}
              keyExtractor={(item) => item}
              renderItem={({ item }) => (
                <View style={styles.reportCard}>
                  <View style={styles.reportInfo}>
                    <Text style={styles.reportName}>{formatFileName(item)}</Text>
                    <Text style={styles.reportDate}>{formatFileDate(item)}</Text>
                    <Text style={styles.reportPath}>{item}</Text>
                  </View>
                  
                  <View style={styles.reportActions}>
                    <TouchableOpacity
                      style={styles.shareButton}
                      onPress={() => shareReport(item, formatFileName(item))}
                    >
                      <Text style={styles.shareButtonText}>مشاركة</Text>
                    </TouchableOpacity>
                    
                    <TouchableOpacity
                      style={styles.deleteButton}
                      onPress={() => deleteReport(item)}
                    >
                      <Text style={styles.deleteButtonText}>حذف</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              )}
              scrollEnabled={false}
            />
          )}
        </View>

        {/* معلومات إضافية */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>معلومات التقارير</Text>
          
          <Text style={styles.infoText}>
            تتيح لك ميزة التقارير المخصصة إنشاء تقارير مهنية شاملة:
          </Text>
          
          <View style={styles.featuresList}>
            <Text style={styles.featureItem}>• قوالب متعددة للاستخدامات المختلفة</Text>
            <Text style={styles.featureItem}>• تنسيقات متنوعة (PDF, HTML, DOCX, CSV)</Text>
            <Text style={styles.featureItem">• تضمين الصور والخرائط والقياسات</Text>
            <Text style={styles.featureItem">• تخصيص المحتوى والتنسيق</Text>
            <Text style={styles.featureItem">• مشاركة مباشرة عبر التطبيقات</Text>
          </View>
          
          <Text style={styles.infoText">
            يمكنك استخدام التقارير لتوثيق أعمال المسح ومشاركتها مع العملاء والجهات المختصة.
          </Text>
        </View>
      </ScrollView>

      {renderCreateModal()}
      {renderTemplateModal()}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  content: {
    flex: 1,
  },
  section: {
    backgroundColor: '#FFFFFF',
    margin: 16,
    borderRadius: 12,
    padding: 16,
    elevation: 2,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#212121',
    marginBottom: 16,
  },
  actionButtons: {
    gap: 12,
  },
  createButton: {
    backgroundColor: '#4CAF50',
    paddingVertical: 16,
    paddingHorizontal: 20,
    borderRadius: 8,
    alignItems: 'center',
  },
  createButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  templatesButton: {
    backgroundColor: '#2196F3',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 8,
    alignItems: 'center',
  },
  templatesButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: 'bold',
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 32,
  },
  emptyText: {
    fontSize: 16,
    color: '#757575',
    textAlign: 'center',
    marginBottom: 8,
  },
  emptyHint: {
    fontSize: 14,
    color: '#9E9E9E',
    textAlign: 'center',
  },
  reportCard: {
    backgroundColor: '#f8f9fa',
    padding: 16,
    borderRadius: 8,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#E0E0E0',
  },
  reportInfo: {
    marginBottom: 12,
  },
  reportName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#212121',
    marginBottom: 4,
  },
  reportDate: {
    fontSize: 12,
    color: '#757575',
    marginBottom: 2,
  },
  reportPath: {
    fontSize: 10,
    color: '#9E9E9E',
    fontFamily: 'monospace',
  },
  reportActions: {
    flexDirection: 'row',
    gap: 8,
  },
  shareButton: {
    backgroundColor: '#2196F3',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 4,
    flex: 1,
    alignItems: 'center',
  },
  shareButtonText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: 'bold',
  },
  deleteButton: {
    backgroundColor: '#F44336',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 4,
    flex: 1,
    alignItems: 'center',
  },
  deleteButtonText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: 'bold',
  },
  infoText: {
    fontSize: 14,
    color: '#424242',
    lineHeight: 20,
    marginBottom: 12,
  },
  featuresList: {
    marginVertical: 8,
  },
  featureItem: {
    fontSize: 14,
    color: '#424242',
    marginBottom: 4,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  createModal: {
    backgroundColor: '#FFFFFF',
    width: '95%',
    maxHeight: '90%',
    borderRadius: 12,
    padding: 20,
  },
  templateModal: {
    backgroundColor: '#FFFFFF',
    width: '90%',
    maxHeight: '80%',
    borderRadius: 12,
    padding: 20,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#212121',
    textAlign: 'center',
    marginBottom: 20,
  },
  createForm: {
    maxHeight: 500,
  },
  inputGroup: {
    marginBottom: 16,
  },
  inputRow: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 16,
  },
  inputHalf: {
    flex: 1,
  },
  inputLabel: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#212121',
    marginBottom: 8,
  },
  textInput: {
    borderWidth: 1,
    borderColor: '#E0E0E0',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 14,
  },
  optionsSection: {
    marginTop: 20,
    paddingTop: 20,
    borderTopWidth: 1,
    borderTopColor: '#E0E0E0',
  },
  formatSelector: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  formatOption: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderWidth: 1,
    borderColor: '#E0E0E0',
    borderRadius: 6,
    backgroundColor: '#f8f9fa',
  },
  selectedFormat: {
    backgroundColor: '#4CAF50',
    borderColor: '#4CAF50',
  },
  formatText: {
    fontSize: 12,
    color: '#424242',
    fontWeight: 'bold',
  },
  selectedFormatText: {
    color: '#FFFFFF',
  },
  templateSelector: {
    gap: 8,
  },
  templateOption: {
    padding: 12,
    borderWidth: 1,
    borderColor: '#E0E0E0',
    borderRadius: 8,
    backgroundColor: '#f8f9fa',
  },
  selectedTemplate: {
    backgroundColor: '#E3F2FD',
    borderColor: '#2196F3',
  },
  templateText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#212121',
  },
  selectedTemplateText: {
    color: '#1976D2',
  },
  templateDescription: {
    fontSize: 12,
    color: '#757575',
    marginTop: 4,
  },
  switchGroup: {
    gap: 12,
    marginTop: 16,
  },
  switchOption: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 4,
  },
  switchLabel: {
    fontSize: 14,
    color: '#212121',
  },
  coordinateSelector: {
    gap: 8,
  },
  coordinateOption: {
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderWidth: 1,
    borderColor: '#E0E0E0',
    borderRadius: 6,
    backgroundColor: '#f8f9fa',
  },
  selectedCoordinate: {
    backgroundColor: '#E8F5E8',
    borderColor: '#4CAF50',
  },
  coordinateText: {
    fontSize: 12,
    color: '#424242',
  },
  selectedCoordinateText: {
    color: '#2E7D32',
    fontWeight: 'bold',
  },
  modalActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 20,
    gap: 12,
  },
  generateButton: {
    flex: 1,
    backgroundColor: '#4CAF50',
    paddingVertical: 14,
    borderRadius: 8,
    alignItems: 'center',
  },
  generateButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  disabledButton: {
    backgroundColor: '#BDBDBD',
  },
  cancelButton: {
    flex: 1,
    backgroundColor: '#757575',
    paddingVertical: 14,
    borderRadius: 8,
    alignItems: 'center',
  },
  cancelButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  templateCard: {
    backgroundColor: '#f8f9fa',
    padding: 16,
    borderRadius: 8,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#E0E0E0',
  },
  templateName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#212121',
    marginBottom: 8,
  },
  templateCardDescription: {
    fontSize: 14,
    color: '#424242',
    marginBottom: 12,
  },
  templateSections: {
    marginBottom: 12,
  },
  sectionsLabel: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#757575',
    marginBottom: 4,
  },
  sectionItem: {
    fontSize: 12,
    color: '#424242',
    marginBottom: 2,
  },
  defaultBadge: {
    alignSelf: 'flex-start',
    backgroundColor: '#4CAF50',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 4,
  },
  defaultText: {
    color: '#FFFFFF',
    fontSize: 10,
    fontWeight: 'bold',
  },
  closeButton: {
    backgroundColor: '#2196F3',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 16,
  },
  closeButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default ReportsScreen;

