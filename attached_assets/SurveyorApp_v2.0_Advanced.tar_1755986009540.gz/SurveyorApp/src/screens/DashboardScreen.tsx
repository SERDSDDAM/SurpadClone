/**
 * شاشة لوحة التحكم الرئيسية
 * Dashboard Screen
 */

import React from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  Dimensions,
} from 'react-native';

interface DashboardScreenProps {
  onNavigate: (screen: string) => void;
}

const { width } = Dimensions.get('window');

const DashboardScreen: React.FC<DashboardScreenProps> = ({ onNavigate }) => {
  // بيانات وهمية للإحصائيات
  const stats = {
    totalRequests: 45,
    pendingRequests: 12,
    completedRequests: 28,
    rejectedRequests: 5,
  };

  const quickActions = [
    {
      id: 'new-survey',
      title: 'طلب مسح جديد',
      subtitle: 'إنشاء طلب مسح مساحي',
      icon: '📋',
      color: '#4CAF50',
      action: () => onNavigate('surveys'),
    },
    {
      id: 'view-map',
      title: 'عرض الخريطة',
      subtitle: 'استعراض المواقع والحدود',
      icon: '🗺️',
      color: '#2196F3',
      action: () => onNavigate('map'),
    },
    {
      id: 'my-requests',
      title: 'طلباتي',
      subtitle: 'متابعة حالة الطلبات',
      icon: '📊',
      color: '#FF9800',
      action: () => onNavigate('surveys'),
    },
    {
      id: 'settings',
      title: 'الإعدادات',
      subtitle: 'إعدادات التطبيق والحساب',
      icon: '⚙️',
      color: '#9C27B0',
      action: () => onNavigate('settings'),
    },
  ];

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      {/* ترحيب */}
      <View style={styles.welcomeSection}>
        <Text style={styles.welcomeTitle}>مرحباً بك</Text>
        <Text style={styles.welcomeSubtitle}>
          {new Date().toLocaleDateString('ar-SA', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
          })}
        </Text>
      </View>

      {/* الإحصائيات */}
      <View style={styles.statsSection}>
        <Text style={styles.sectionTitle}>الإحصائيات</Text>
        <View style={styles.statsGrid}>
          <View style={[styles.statCard, { backgroundColor: '#E3F2FD' }]}>
            <Text style={styles.statNumber}>{stats.totalRequests}</Text>
            <Text style={styles.statLabel}>إجمالي الطلبات</Text>
          </View>
          <View style={[styles.statCard, { backgroundColor: '#FFF3E0' }]}>
            <Text style={styles.statNumber}>{stats.pendingRequests}</Text>
            <Text style={styles.statLabel}>قيد المراجعة</Text>
          </View>
          <View style={[styles.statCard, { backgroundColor: '#E8F5E8' }]}>
            <Text style={styles.statNumber}>{stats.completedRequests}</Text>
            <Text style={styles.statLabel}>مكتملة</Text>
          </View>
          <View style={[styles.statCard, { backgroundColor: '#FFEBEE' }]}>
            <Text style={styles.statNumber}>{stats.rejectedRequests}</Text>
            <Text style={styles.statLabel}>مرفوضة</Text>
          </View>
        </View>
      </View>

      {/* الإجراءات السريعة */}
      <View style={styles.actionsSection}>
        <Text style={styles.sectionTitle}>الإجراءات السريعة</Text>
        <View style={styles.actionsGrid}>
          {quickActions.map((action) => (
            <TouchableOpacity
              key={action.id}
              style={styles.actionCard}
              onPress={action.action}
            >
              <View style={[styles.actionIcon, { backgroundColor: action.color }]}>
                <Text style={styles.actionIconText}>{action.icon}</Text>
              </View>
              <Text style={styles.actionTitle}>{action.title}</Text>
              <Text style={styles.actionSubtitle}>{action.subtitle}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      {/* الأنشطة الأخيرة */}
      <View style={styles.activitySection}>
        <Text style={styles.sectionTitle}>الأنشطة الأخيرة</Text>
        <View style={styles.activityList}>
          <View style={styles.activityItem}>
            <View style={styles.activityIcon}>
              <Text style={styles.activityIconText}>📋</Text>
            </View>
            <View style={styles.activityContent}>
              <Text style={styles.activityTitle}>تم إنشاء طلب مسح جديد</Text>
              <Text style={styles.activityTime}>منذ ساعتين</Text>
            </View>
          </View>
          
          <View style={styles.activityItem}>
            <View style={styles.activityIcon}>
              <Text style={styles.activityIconText}>✅</Text>
            </View>
            <View style={styles.activityContent}>
              <Text style={styles.activityTitle}>تم الموافقة على طلب #1234</Text>
              <Text style={styles.activityTime}>أمس</Text>
            </View>
          </View>
          
          <View style={styles.activityItem}>
            <View style={styles.activityIcon}>
              <Text style={styles.activityIconText}>📍</Text>
            </View>
            <View style={styles.activityContent}>
              <Text style={styles.activityTitle}>تم تحديث موقع المسح</Text>
              <Text style={styles.activityTime}>منذ 3 أيام</Text>
            </View>
          </View>
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F9FA',
  },
  welcomeSection: {
    padding: 20,
    backgroundColor: 'white',
    marginBottom: 16,
  },
  welcomeTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'right',
  },
  welcomeSubtitle: {
    fontSize: 14,
    color: '#666',
    marginTop: 4,
    textAlign: 'right',
  },
  statsSection: {
    padding: 20,
    backgroundColor: 'white',
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 16,
    textAlign: 'right',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  statCard: {
    width: (width - 60) / 2,
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    marginBottom: 12,
  },
  statNumber: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
  },
  statLabel: {
    fontSize: 12,
    color: '#666',
    marginTop: 4,
    textAlign: 'center',
  },
  actionsSection: {
    padding: 20,
    backgroundColor: 'white',
    marginBottom: 16,
  },
  actionsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  actionCard: {
    width: (width - 60) / 2,
    padding: 16,
    backgroundColor: '#F8F9FA',
    borderRadius: 12,
    alignItems: 'center',
    marginBottom: 12,
  },
  actionIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  actionIconText: {
    fontSize: 24,
  },
  actionTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'center',
    marginBottom: 4,
  },
  actionSubtitle: {
    fontSize: 12,
    color: '#666',
    textAlign: 'center',
  },
  activitySection: {
    padding: 20,
    backgroundColor: 'white',
    marginBottom: 16,
  },
  activityList: {
    marginTop: 8,
  },
  activityItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },
  activityIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#F0F0F0',
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 12,
  },
  activityIconText: {
    fontSize: 16,
  },
  activityContent: {
    flex: 1,
  },
  activityTitle: {
    fontSize: 14,
    color: '#333',
    textAlign: 'right',
  },
  activityTime: {
    fontSize: 12,
    color: '#666',
    marginTop: 2,
    textAlign: 'right',
  },
});

export default DashboardScreen;

