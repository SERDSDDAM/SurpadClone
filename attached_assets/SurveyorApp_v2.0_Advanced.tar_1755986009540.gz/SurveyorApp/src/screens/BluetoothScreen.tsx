import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Alert,
  TouchableOpacity,
} from 'react-native';
import BluetoothDeviceManager from '../components/BluetoothDeviceManager';
import { BluetoothDevice, GNSSData, LaserMeasurement } from '../services/BluetoothService';

const BluetoothScreen: React.FC = () => {
  const [connectedDevices, setConnectedDevices] = useState<BluetoothDevice[]>([]);
  const [latestGNSSData, setLatestGNSSData] = useState<GNSSData | null>(null);
  const [latestLaserData, setLatestLaserData] = useState<LaserMeasurement | null>(null);
  const [dataHistory, setDataHistory] = useState<{
    gnss: GNSSData[];
    laser: LaserMeasurement[];
  }>({
    gnss: [],
    laser: [],
  });

  /**
   * معالج اتصال الجهاز
   */
  const handleDeviceConnected = (device: BluetoothDevice) => {
    setConnectedDevices(prev => {
      const exists = prev.find(d => d.id === device.id);
      if (exists) {
        return prev.map(d => d.id === device.id ? device : d);
      }
      return [...prev, device];
    });

    Alert.alert(
      'جهاز متصل',
      `تم الاتصال بـ ${device.name} بنجاح.\nالنوع: ${device.type}`,
      [{ text: 'موافق' }]
    );
  };

  /**
   * معالج قطع اتصال الجهاز
   */
  const handleDeviceDisconnected = (device: BluetoothDevice) => {
    setConnectedDevices(prev => prev.filter(d => d.id !== device.id));
    
    Alert.alert(
      'تم قطع الاتصال',
      `تم قطع الاتصال مع ${device.name}`,
      [{ text: 'موافق' }]
    );
  };

  /**
   * معالج استقبال بيانات GNSS
   */
  const handleGNSSDataReceived = (data: GNSSData) => {
    setLatestGNSSData(data);
    setDataHistory(prev => ({
      ...prev,
      gnss: [...prev.gnss.slice(-99), data], // الاحتفاظ بآخر 100 قراءة
    }));
  };

  /**
   * معالج استقبال بيانات الليزر
   */
  const handleLaserDataReceived = (data: LaserMeasurement) => {
    setLatestLaserData(data);
    setDataHistory(prev => ({
      ...prev,
      laser: [...prev.laser.slice(-99), data], // الاحتفاظ بآخر 100 قراءة
    }));
  };

  /**
   * تنسيق الوقت
   */
  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('ar-SA', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });
  };

  /**
   * تنسيق الإحداثيات
   */
  const formatCoordinate = (value: number, decimals: number = 6) => {
    return value.toFixed(decimals);
  };

  /**
   * مسح سجل البيانات
   */
  const clearDataHistory = () => {
    Alert.alert(
      'مسح السجل',
      'هل أنت متأكد من مسح جميع البيانات المحفوظة؟',
      [
        { text: 'إلغاء', style: 'cancel' },
        {
          text: 'مسح',
          style: 'destructive',
          onPress: () => {
            setDataHistory({ gnss: [], laser: [] });
            setLatestGNSSData(null);
            setLatestLaserData(null);
          },
        },
      ]
    );
  };

  return (
    <View style={styles.container}>
      {/* مدير أجهزة البلوتوث */}
      <BluetoothDeviceManager
        onDeviceConnected={handleDeviceConnected}
        onDeviceDisconnected={handleDeviceDisconnected}
        onGNSSDataReceived={handleGNSSDataReceived}
        onLaserDataReceived={handleLaserDataReceived}
      />

      <ScrollView style={styles.content}>
        {/* قسم البيانات المباشرة */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>البيانات المباشرة</Text>
          
          {/* بيانات GNSS */}
          {latestGNSSData && (
            <View style={styles.dataCard}>
              <Text style={styles.dataCardTitle}>🛰️ بيانات GNSS</Text>
              <View style={styles.dataRow}>
                <Text style={styles.dataLabel}>خط العرض:</Text>
                <Text style={styles.dataValue}>
                  {formatCoordinate(latestGNSSData.latitude)}°
                </Text>
              </View>
              <View style={styles.dataRow}>
                <Text style={styles.dataLabel}>خط الطول:</Text>
                <Text style={styles.dataValue}>
                  {formatCoordinate(latestGNSSData.longitude)}°
                </Text>
              </View>
              <View style={styles.dataRow}>
                <Text style={styles.dataLabel}>الارتفاع:</Text>
                <Text style={styles.dataValue}>
                  {formatCoordinate(latestGNSSData.altitude, 2)} م
                </Text>
              </View>
              <View style={styles.dataRow}>
                <Text style={styles.dataLabel}>الدقة:</Text>
                <Text style={styles.dataValue}>
                  ±{formatCoordinate(latestGNSSData.accuracy, 2)} م
                </Text>
              </View>
              <View style={styles.dataRow}>
                <Text style={styles.dataLabel}>الأقمار:</Text>
                <Text style={styles.dataValue}>
                  {latestGNSSData.satellites}
                </Text>
              </View>
              <View style={styles.dataRow}>
                <Text style={styles.dataLabel}>HDOP:</Text>
                <Text style={styles.dataValue}>
                  {formatCoordinate(latestGNSSData.hdop, 2)}
                </Text>
              </View>
              <View style={styles.dataRow}>
                <Text style={styles.dataLabel}>الوقت:</Text>
                <Text style={styles.dataValue}>
                  {formatTime(latestGNSSData.timestamp)}
                </Text>
              </View>
            </View>
          )}

          {/* بيانات الليزر */}
          {latestLaserData && (
            <View style={styles.dataCard}>
              <Text style={styles.dataCardTitle}>📏 بيانات الليزر</Text>
              <View style={styles.dataRow}>
                <Text style={styles.dataLabel}>المسافة:</Text>
                <Text style={styles.dataValue}>
                  {formatCoordinate(latestLaserData.distance, 3)} {latestLaserData.unit === 'meters' ? 'م' : 'قدم'}
                </Text>
              </View>
              {latestLaserData.angle && (
                <View style={styles.dataRow}>
                  <Text style={styles.dataLabel}>الزاوية:</Text>
                  <Text style={styles.dataValue}>
                    {formatCoordinate(latestLaserData.angle, 2)}°
                  </Text>
                </View>
              )}
              <View style={styles.dataRow}>
                <Text style={styles.dataLabel}>الدقة:</Text>
                <Text style={styles.dataValue}>
                  ±{formatCoordinate(latestLaserData.accuracy * 1000, 1)} مم
                </Text>
              </View>
              <View style={styles.dataRow}>
                <Text style={styles.dataLabel}>الوقت:</Text>
                <Text style={styles.dataValue}>
                  {formatTime(latestLaserData.timestamp)}
                </Text>
              </View>
            </View>
          )}

          {/* رسالة عدم وجود بيانات */}
          {!latestGNSSData && !latestLaserData && (
            <View style={styles.noDataCard}>
              <Text style={styles.noDataText}>
                لا توجد بيانات متاحة. قم بتوصيل جهاز GNSS أو ليزر لبدء استقبال البيانات.
              </Text>
            </View>
          )}
        </View>

        {/* قسم الإحصائيات */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>الإحصائيات</Text>
            <TouchableOpacity
              style={styles.clearButton}
              onPress={clearDataHistory}
            >
              <Text style={styles.clearButtonText}>مسح السجل</Text>
            </TouchableOpacity>
          </View>

          <View style={styles.statsGrid}>
            <View style={styles.statCard}>
              <Text style={styles.statValue}>{connectedDevices.length}</Text>
              <Text style={styles.statLabel}>أجهزة متصلة</Text>
            </View>
            
            <View style={styles.statCard}>
              <Text style={styles.statValue}>{dataHistory.gnss.length}</Text>
              <Text style={styles.statLabel}>قراءات GNSS</Text>
            </View>
            
            <View style={styles.statCard}>
              <Text style={styles.statValue}>{dataHistory.laser.length}</Text>
              <Text style={styles.statLabel}>قياسات ليزر</Text>
            </View>
            
            <View style={styles.statCard}>
              <Text style={styles.statValue}>
                {dataHistory.gnss.length + dataHistory.laser.length}
              </Text>
              <Text style={styles.statLabel}>إجمالي البيانات</Text>
            </View>
          </View>
        </View>

        {/* قسم سجل البيانات */}
        {(dataHistory.gnss.length > 0 || dataHistory.laser.length > 0) && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>سجل البيانات الأخيرة</Text>
            
            {/* سجل GNSS */}
            {dataHistory.gnss.length > 0 && (
              <View style={styles.historyCard}>
                <Text style={styles.historyTitle}>🛰️ سجل GNSS (آخر 5 قراءات)</Text>
                {dataHistory.gnss.slice(-5).reverse().map((data, index) => (
                  <View key={index} style={styles.historyItem}>
                    <Text style={styles.historyTime}>
                      {formatTime(data.timestamp)}
                    </Text>
                    <Text style={styles.historyData}>
                      {formatCoordinate(data.latitude, 4)}°, {formatCoordinate(data.longitude, 4)}°
                      {' '}(±{formatCoordinate(data.accuracy, 1)}م)
                    </Text>
                  </View>
                ))}
              </View>
            )}

            {/* سجل الليزر */}
            {dataHistory.laser.length > 0 && (
              <View style={styles.historyCard}>
                <Text style={styles.historyTitle}>📏 سجل الليزر (آخر 5 قياسات)</Text>
                {dataHistory.laser.slice(-5).reverse().map((data, index) => (
                  <View key={index} style={styles.historyItem}>
                    <Text style={styles.historyTime}>
                      {formatTime(data.timestamp)}
                    </Text>
                    <Text style={styles.historyData}>
                      {formatCoordinate(data.distance, 3)} {data.unit === 'meters' ? 'م' : 'قدم'}
                      {data.angle && ` @ ${formatCoordinate(data.angle, 1)}°`}
                    </Text>
                  </View>
                ))}
              </View>
            )}
          </View>
        )}
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  content: {
    flex: 1,
  },
  section: {
    margin: 16,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#212121',
  },
  clearButton: {
    backgroundColor: '#F44336',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 6,
  },
  clearButtonText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: 'bold',
  },
  dataCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  dataCardTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#2196F3',
    marginBottom: 12,
  },
  dataRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 4,
  },
  dataLabel: {
    fontSize: 14,
    color: '#424242',
    fontWeight: '500',
  },
  dataValue: {
    fontSize: 14,
    color: '#212121',
    fontWeight: 'bold',
    fontFamily: 'monospace',
  },
  noDataCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 24,
    alignItems: 'center',
    elevation: 2,
  },
  noDataText: {
    fontSize: 16,
    color: '#757575',
    textAlign: 'center',
    lineHeight: 24,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  statCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    width: '48%',
    alignItems: 'center',
    marginBottom: 12,
    elevation: 2,
  },
  statValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#2196F3',
  },
  statLabel: {
    fontSize: 12,
    color: '#757575',
    marginTop: 4,
    textAlign: 'center',
  },
  historyCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    elevation: 2,
  },
  historyTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#424242',
    marginBottom: 8,
  },
  historyItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 6,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },
  historyTime: {
    fontSize: 12,
    color: '#757575',
    fontFamily: 'monospace',
  },
  historyData: {
    fontSize: 12,
    color: '#212121',
    fontFamily: 'monospace',
    flex: 1,
    textAlign: 'right',
    marginLeft: 8,
  },
});

export default BluetoothScreen;

