import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Alert,
  ScrollView,
  TextInput,
  Modal,
  FlatList,
} from 'react-native';
import CollaborationPanel from '../components/CollaborationPanel';
import CollaborationService, {
  CollaborationUser,
  CollaborationProject,
  RealTimeUpdate,
} from '../services/CollaborationService';

interface CollaborationScreenProps {
  onNavigate?: (screen: string) => void;
}

const CollaborationScreen: React.FC<CollaborationScreenProps> = ({ onNavigate }) => {
  const [isConnected, setIsConnected] = useState(false);
  const [currentUser, setCurrentUser] = useState<CollaborationUser | null>(null);
  const [currentProject, setCurrentProject] = useState<CollaborationProject | null>(null);
  const [availableProjects, setAvailableProjects] = useState<CollaborationProject[]>([]);
  const [showProjectModal, setShowProjectModal] = useState(false);
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [newProjectName, setNewProjectName] = useState('');
  const [newProjectDescription, setNewProjectDescription] = useState('');
  const [userName, setUserName] = useState('');
  const [userRole, setUserRole] = useState<'surveyor' | 'supervisor' | 'admin'>('surveyor');
  const [connectionStatus, setConnectionStatus] = useState('غير متصل');
  const [recentActivity, setRecentActivity] = useState<RealTimeUpdate[]>([]);

  useEffect(() => {
    initializeService();
    
    return () => {
      CollaborationService.disconnect();
    };
  }, []);

  /**
   * تهيئة خدمة التعاون
   */
  const initializeService = async () => {
    try {
      setConnectionStatus('جاري الاتصال...');
      
      const serverUrl = 'ws://localhost:3001'; // يجب تغييرها لعنوان الخادم الفعلي
      const success = await CollaborationService.initialize(serverUrl);
      
      if (success) {
        setIsConnected(true);
        setConnectionStatus('متصل');
        setCurrentUser(CollaborationService.getCurrentUser());
        setCurrentProject(CollaborationService.getCurrentProject());
        
        // تحميل المشاريع المتاحة (محاكاة)
        loadAvailableProjects();
        
        // تسجيل مستمع للتحديثات
        CollaborationService.registerUpdateListener('screen', handleUpdateReceived);
      } else {
        setConnectionStatus('فشل في الاتصال');
        Alert.alert('خطأ في الاتصال', 'لا يمكن الاتصال بخادم التعاون. تأكد من تشغيل الخادم.');
      }
    } catch (error) {
      setConnectionStatus('خطأ في الاتصال');
      console.error('خطأ في تهيئة الخدمة:', error);
    }
  };

  /**
   * تحميل المشاريع المتاحة
   */
  const loadAvailableProjects = () => {
    // محاكاة تحميل المشاريع من الخادم
    const mockProjects: CollaborationProject[] = [
      {
        id: 'project-1',
        name: 'مسح أراضي الحديدة',
        description: 'مشروع مسح شامل لأراضي محافظة الحديدة',
        createdBy: 'admin-1',
        createdAt: new Date('2024-01-15'),
        members: [],
        isActive: true,
      },
      {
        id: 'project-2',
        name: 'مسح أراضي صنعاء',
        description: 'مشروع مسح أراضي العاصمة صنعاء',
        createdBy: 'admin-1',
        createdAt: new Date('2024-01-10'),
        members: [],
        isActive: true,
      },
      {
        id: 'project-3',
        name: 'مسح أراضي عدن',
        description: 'مشروع مسح شامل لأراضي محافظة عدن',
        createdBy: 'admin-2',
        createdAt: new Date('2024-01-05'),
        members: [],
        isActive: false,
      },
    ];
    
    setAvailableProjects(mockProjects);
  };

  /**
   * معالجة استقبال التحديثات
   */
  const handleUpdateReceived = (update: RealTimeUpdate) => {
    setRecentActivity(prev => [update, ...prev.slice(0, 19)]); // الاحتفاظ بآخر 20 تحديث
  };

  /**
   * الانضمام إلى مشروع
   */
  const joinProject = async (project: CollaborationProject) => {
    try {
      const success = await CollaborationService.joinProject(project.id);
      
      if (success) {
        setCurrentProject(project);
        setShowProjectModal(false);
        Alert.alert('نجح الانضمام', `تم الانضمام إلى مشروع "${project.name}" بنجاح`);
      } else {
        Alert.alert('فشل الانضمام', 'لا يمكن الانضمام إلى هذا المشروع');
      }
    } catch (error) {
      Alert.alert('خطأ', 'حدث خطأ أثناء الانضمام إلى المشروع');
    }
  };

  /**
   * مغادرة المشروع الحالي
   */
  const leaveCurrentProject = async () => {
    Alert.alert(
      'مغادرة المشروع',
      'هل أنت متأكد من مغادرة المشروع الحالي؟',
      [
        { text: 'إلغاء', style: 'cancel' },
        {
          text: 'مغادرة',
          style: 'destructive',
          onPress: async () => {
            await CollaborationService.leaveProject();
            setCurrentProject(null);
            Alert.alert('تم', 'تم مغادرة المشروع بنجاح');
          },
        },
      ]
    );
  };

  /**
   * إنشاء مشروع جديد
   */
  const createNewProject = () => {
    if (!newProjectName.trim()) {
      Alert.alert('خطأ', 'يرجى إدخال اسم المشروع');
      return;
    }

    // محاكاة إنشاء مشروع جديد
    const newProject: CollaborationProject = {
      id: `project-${Date.now()}`,
      name: newProjectName.trim(),
      description: newProjectDescription.trim(),
      createdBy: currentUser?.id || '',
      createdAt: new Date(),
      members: currentUser ? [currentUser] : [],
      isActive: true,
    };

    setAvailableProjects(prev => [newProject, ...prev]);
    setNewProjectName('');
    setNewProjectDescription('');
    
    Alert.alert('تم الإنشاء', `تم إنشاء مشروع "${newProject.name}" بنجاح`);
  };

  /**
   * تحديث ملف المستخدم
   */
  const updateUserProfile = async () => {
    if (!userName.trim()) {
      Alert.alert('خطأ', 'يرجى إدخال اسم المستخدم');
      return;
    }

    try {
      await CollaborationService.updateUserProfile(userName.trim(), userRole);
      setCurrentUser(CollaborationService.getCurrentUser());
      setShowProfileModal(false);
      Alert.alert('تم التحديث', 'تم تحديث ملفك الشخصي بنجاح');
    } catch (error) {
      Alert.alert('خطأ', 'فشل في تحديث الملف الشخصي');
    }
  };

  /**
   * إعادة الاتصال
   */
  const reconnect = () => {
    setConnectionStatus('جاري إعادة الاتصال...');
    CollaborationService.reconnect();
    
    setTimeout(() => {
      if (CollaborationService.isConnectedToServer()) {
        setIsConnected(true);
        setConnectionStatus('متصل');
      } else {
        setConnectionStatus('فشل في إعادة الاتصال');
      }
    }, 3000);
  };

  /**
   * تنسيق الوقت
   */
  const formatTime = (date: Date) => {
    return new Date(date).toLocaleString('ar-SA');
  };

  /**
   * عرض نافذة المشاريع
   */
  const renderProjectModal = () => (
    <Modal
      visible={showProjectModal}
      animationType="slide"
      transparent={true}
      onRequestClose={() => setShowProjectModal(false)}
    >
      <View style={styles.modalOverlay}>
        <View style={styles.modalContent}>
          <Text style={styles.modalTitle}>المشاريع المتاحة</Text>
          
          <ScrollView style={styles.projectsList}>
            {availableProjects.map(project => (
              <TouchableOpacity
                key={project.id}
                style={[
                  styles.projectItem,
                  !project.isActive && styles.inactiveProject
                ]}
                onPress={() => project.isActive && joinProject(project)}
                disabled={!project.isActive}
              >
                <Text style={styles.projectName}>{project.name}</Text>
                <Text style={styles.projectDescription}>{project.description}</Text>
                <Text style={styles.projectDate}>
                  تم الإنشاء: {formatTime(project.createdAt)}
                </Text>
                <Text style={[
                  styles.projectStatus,
                  { color: project.isActive ? '#4CAF50' : '#F44336' }
                ]}>
                  {project.isActive ? 'نشط' : 'غير نشط'}
                </Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
          
          <View style={styles.newProjectSection}>
            <Text style={styles.sectionTitle}>إنشاء مشروع جديد</Text>
            
            <TextInput
              style={styles.input}
              placeholder="اسم المشروع"
              value={newProjectName}
              onChangeText={setNewProjectName}
            />
            
            <TextInput
              style={[styles.input, styles.textArea]}
              placeholder="وصف المشروع (اختياري)"
              value={newProjectDescription}
              onChangeText={setNewProjectDescription}
              multiline
              numberOfLines={3}
            />
            
            <TouchableOpacity
              style={styles.createButton}
              onPress={createNewProject}
            >
              <Text style={styles.createButtonText}>إنشاء مشروع</Text>
            </TouchableOpacity>
          </View>
          
          <TouchableOpacity
            style={styles.closeButton}
            onPress={() => setShowProjectModal(false)}
          >
            <Text style={styles.closeButtonText}>إغلاق</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );

  /**
   * عرض نافذة الملف الشخصي
   */
  const renderProfileModal = () => (
    <Modal
      visible={showProfileModal}
      animationType="slide"
      transparent={true}
      onRequestClose={() => setShowProfileModal(false)}
    >
      <View style={styles.modalOverlay}>
        <View style={styles.modalContent}>
          <Text style={styles.modalTitle}>الملف الشخصي</Text>
          
          <View style={styles.profileForm}>
            <Text style={styles.label}>اسم المستخدم:</Text>
            <TextInput
              style={styles.input}
              placeholder="أدخل اسمك"
              value={userName}
              onChangeText={setUserName}
            />
            
            <Text style={styles.label}>الدور:</Text>
            <View style={styles.roleSelector}>
              {(['surveyor', 'supervisor', 'admin'] as const).map(role => (
                <TouchableOpacity
                  key={role}
                  style={[
                    styles.roleOption,
                    userRole === role && styles.selectedRole
                  ]}
                  onPress={() => setUserRole(role)}
                >
                  <Text style={[
                    styles.roleText,
                    userRole === role && styles.selectedRoleText
                  ]}>
                    {role === 'surveyor' ? 'مساح' :
                     role === 'supervisor' ? 'مشرف' : 'مدير'}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
          
          <View style={styles.modalActions}>
            <TouchableOpacity
              style={styles.saveButton}
              onPress={updateUserProfile}
            >
              <Text style={styles.saveButtonText}>حفظ</Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={styles.cancelButton}
              onPress={() => setShowProfileModal(false)}
            >
              <Text style={styles.cancelButtonText}>إلغاء</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );

  return (
    <View style={styles.container}>
      <ScrollView style={styles.content}>
        {/* قسم الحالة */}
        <View style={styles.statusSection}>
          <Text style={styles.sectionTitle}>حالة الاتصال</Text>
          
          <View style={styles.statusCard}>
            <View style={styles.statusRow}>
              <Text style={styles.statusLabel}>الحالة:</Text>
              <View style={styles.statusIndicator}>
                <View style={[
                  styles.statusDot,
                  { backgroundColor: isConnected ? '#4CAF50' : '#F44336' }
                ]} />
                <Text style={[
                  styles.statusText,
                  { color: isConnected ? '#4CAF50' : '#F44336' }
                ]}>
                  {connectionStatus}
                </Text>
              </View>
            </View>
            
            {currentUser && (
              <View style={styles.statusRow}>
                <Text style={styles.statusLabel}>المستخدم:</Text>
                <Text style={styles.statusValue}>
                  {currentUser.name} ({currentUser.role === 'surveyor' ? 'مساح' : 
                                     currentUser.role === 'supervisor' ? 'مشرف' : 'مدير'})
                </Text>
              </View>
            )}
            
            {currentProject && (
              <View style={styles.statusRow}>
                <Text style={styles.statusLabel}>المشروع:</Text>
                <Text style={styles.statusValue}>{currentProject.name}</Text>
              </View>
            )}
          </View>
        </View>

        {/* قسم الإجراءات */}
        <View style={styles.actionsSection}>
          <Text style={styles.sectionTitle}>الإجراءات</Text>
          
          <View style={styles.actionButtons}>
            <TouchableOpacity
              style={styles.actionButton}
              onPress={() => {
                setUserName(currentUser?.name || '');
                setUserRole(currentUser?.role || 'surveyor');
                setShowProfileModal(true);
              }}
            >
              <Text style={styles.actionButtonText}>تحديث الملف الشخصي</Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={styles.actionButton}
              onPress={() => setShowProjectModal(true)}
            >
              <Text style={styles.actionButtonText}>
                {currentProject ? 'تغيير المشروع' : 'اختيار مشروع'}
              </Text>
            </TouchableOpacity>
            
            {currentProject && (
              <TouchableOpacity
                style={[styles.actionButton, styles.dangerButton]}
                onPress={leaveCurrentProject}
              >
                <Text style={[styles.actionButtonText, styles.dangerButtonText]}>
                  مغادرة المشروع
                </Text>
              </TouchableOpacity>
            )}
            
            {!isConnected && (
              <TouchableOpacity
                style={[styles.actionButton, styles.reconnectButton]}
                onPress={reconnect}
              >
                <Text style={styles.actionButtonText}>إعادة الاتصال</Text>
              </TouchableOpacity>
            )}
          </View>
        </View>

        {/* قسم النشاط الأخير */}
        {recentActivity.length > 0 && (
          <View style={styles.activitySection}>
            <Text style={styles.sectionTitle}>النشاط الأخير</Text>
            
            <View style={styles.activityList}>
              {recentActivity.slice(0, 10).map(activity => (
                <View key={activity.id} style={styles.activityItem}>
                  <Text style={styles.activityType}>
                    {activity.type === 'point_added' ? '➕ تم إضافة نقطة' :
                     activity.type === 'point_updated' ? '✏️ تم تحديث نقطة' :
                     activity.type === 'point_deleted' ? '🗑️ تم حذف نقطة' :
                     activity.type === 'user_joined' ? '👋 انضم مستخدم' :
                     activity.type === 'user_left' ? '👋 غادر مستخدم' :
                     activity.type === 'location_updated' ? '📍 تحديث موقع' : '📝 تحديث'}
                  </Text>
                  <Text style={styles.activityTime}>
                    {formatTime(activity.timestamp)}
                  </Text>
                </View>
              ))}
            </View>
          </View>
        )}

        {/* معلومات إضافية */}
        <View style={styles.infoSection}>
          <Text style={styles.sectionTitle}>معلومات</Text>
          
          <Text style={styles.infoText}>
            ميزة التعاون في الوقت الفعلي تتيح لعدة مساحين العمل على نفس المشروع ومشاركة 
            البيانات والتحديثات فوريًا. يمكنك رؤية مواقع الفريق والدردشة معهم ومتابعة 
            جميع التغييرات التي تحدث في المشروع.
          </Text>
          
          <Text style={styles.infoText}>
            للاستفادة الكاملة من هذه الميزة، تأكد من:
            • الاتصال بالإنترنت
            • الانضمام إلى مشروع نشط
            • تفعيل خدمات الموقع
            • السماح للتطبيق بالعمل في الخلفية
          </Text>
        </View>
      </ScrollView>

      {/* لوحة التعاون */}
      {currentProject && (
        <CollaborationPanel
          projectId={currentProject.id}
          onUserLocationTap={(user) => {
            Alert.alert(
              'موقع المستخدم',
              `${user.name}\nالموقع: ${user.currentLocation?.latitude.toFixed(6)}, ${user.currentLocation?.longitude.toFixed(6)}`,
              [
                { text: 'إغلاق' },
                { text: 'عرض على الخريطة', onPress: () => onNavigate?.('map') },
              ]
            );
          }}
          onUpdateReceived={handleUpdateReceived}
        />
      )}

      {renderProjectModal()}
      {renderProfileModal()}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  content: {
    flex: 1,
  },
  statusSection: {
    margin: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#212121',
    marginBottom: 12,
  },
  statusCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    elevation: 2,
  },
  statusRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  statusLabel: {
    fontSize: 14,
    color: '#424242',
    fontWeight: '500',
  },
  statusIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginRight: 8,
  },
  statusText: {
    fontSize: 14,
    fontWeight: 'bold',
  },
  statusValue: {
    fontSize: 14,
    color: '#212121',
    fontWeight: 'bold',
    flex: 1,
    textAlign: 'right',
  },
  actionsSection: {
    margin: 16,
  },
  actionButtons: {
    gap: 12,
  },
  actionButton: {
    backgroundColor: '#2196F3',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
    alignItems: 'center',
  },
  actionButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  dangerButton: {
    backgroundColor: '#F44336',
  },
  dangerButtonText: {
    color: '#FFFFFF',
  },
  reconnectButton: {
    backgroundColor: '#FF9800',
  },
  activitySection: {
    margin: 16,
  },
  activityList: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    elevation: 2,
  },
  activityItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },
  activityType: {
    fontSize: 14,
    color: '#212121',
    flex: 1,
  },
  activityTime: {
    fontSize: 10,
    color: '#757575',
    fontFamily: 'monospace',
  },
  infoSection: {
    margin: 16,
    marginBottom: 32,
  },
  infoText: {
    fontSize: 14,
    color: '#424242',
    lineHeight: 20,
    marginBottom: 12,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: '#FFFFFF',
    width: '90%',
    maxHeight: '80%',
    borderRadius: 12,
    padding: 20,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#212121',
    textAlign: 'center',
    marginBottom: 16,
  },
  projectsList: {
    maxHeight: 300,
    marginBottom: 16,
  },
  projectItem: {
    backgroundColor: '#f8f9fa',
    padding: 12,
    borderRadius: 8,
    marginBottom: 8,
  },
  inactiveProject: {
    opacity: 0.5,
  },
  projectName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#212121',
  },
  projectDescription: {
    fontSize: 14,
    color: '#424242',
    marginTop: 4,
  },
  projectDate: {
    fontSize: 12,
    color: '#757575',
    marginTop: 4,
  },
  projectStatus: {
    fontSize: 12,
    fontWeight: 'bold',
    marginTop: 4,
  },
  newProjectSection: {
    borderTopWidth: 1,
    borderTopColor: '#E0E0E0',
    paddingTop: 16,
    marginBottom: 16,
  },
  input: {
    borderWidth: 1,
    borderColor: '#E0E0E0',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 8,
    marginBottom: 12,
    fontSize: 16,
  },
  textArea: {
    height: 80,
    textAlignVertical: 'top',
  },
  createButton: {
    backgroundColor: '#4CAF50',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  createButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  closeButton: {
    backgroundColor: '#757575',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  closeButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  profileForm: {
    marginBottom: 20,
  },
  label: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#212121',
    marginBottom: 8,
  },
  roleSelector: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  roleOption: {
    flex: 1,
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderWidth: 1,
    borderColor: '#E0E0E0',
    borderRadius: 8,
    alignItems: 'center',
    marginHorizontal: 4,
  },
  selectedRole: {
    backgroundColor: '#2196F3',
    borderColor: '#2196F3',
  },
  roleText: {
    fontSize: 14,
    color: '#424242',
  },
  selectedRoleText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
  },
  modalActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  saveButton: {
    flex: 1,
    backgroundColor: '#4CAF50',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
    marginRight: 8,
  },
  saveButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  cancelButton: {
    flex: 1,
    backgroundColor: '#757575',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
    marginLeft: 8,
  },
  cancelButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default CollaborationScreen;

