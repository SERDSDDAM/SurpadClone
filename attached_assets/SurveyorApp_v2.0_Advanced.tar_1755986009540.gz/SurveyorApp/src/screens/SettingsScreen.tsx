/**
 * شاشة الإعدادات والتفضيلات
 * Settings Screen
 */

import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  Switch,
  Alert,
} from 'react-native';

interface SettingsScreenProps {
  onNavigate: (screen: string) => void;
  onLogout: () => void;
}

const SettingsScreen: React.FC<SettingsScreenProps> = ({ onNavigate, onLogout }) => {
  const [settings, setSettings] = useState({
    notifications: true,
    gpsTracking: true,
    autoSync: false,
    offlineMode: true,
    darkMode: false,
    language: 'ar',
  });

  const handleSettingChange = (key: string, value: boolean) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  const handleLogout = () => {
    Alert.alert(
      'تسجيل الخروج',
      'هل أنت متأكد من رغبتك في تسجيل الخروج؟',
      [
        { text: 'إلغاء', style: 'cancel' },
        { text: 'تسجيل الخروج', style: 'destructive', onPress: onLogout },
      ]
    );
  };

  const handleExportData = () => {
    Alert.alert('تصدير البيانات', 'سيتم تصدير جميع بياناتك المحلية إلى ملف CSV');
  };

  const handleImportData = () => {
    Alert.alert('استيراد البيانات', 'يرجى اختيار ملف البيانات المراد استيراده');
  };

  const handleClearCache = () => {
    Alert.alert(
      'مسح التخزين المؤقت',
      'هل تريد مسح جميع البيانات المؤقتة؟ هذا قد يحسن أداء التطبيق.',
      [
        { text: 'إلغاء', style: 'cancel' },
        { text: 'مسح', onPress: () => Alert.alert('تم', 'تم مسح التخزين المؤقت بنجاح') },
      ]
    );
  };

  const settingSections = [
    {
      title: 'الإشعارات',
      items: [
        {
          key: 'notifications',
          title: 'تفعيل الإشعارات',
          subtitle: 'استقبال إشعارات حول الطلبات والتحديثات',
          type: 'switch',
          value: settings.notifications,
        },
      ],
    },
    {
      title: 'الموقع والخرائط',
      items: [
        {
          key: 'gpsTracking',
          title: 'تتبع الموقع',
          subtitle: 'السماح للتطبيق بتتبع موقعك لتحسين دقة المسح',
          type: 'switch',
          value: settings.gpsTracking,
        },
      ],
    },
    {
      title: 'المزامنة والبيانات',
      items: [
        {
          key: 'autoSync',
          title: 'المزامنة التلقائية',
          subtitle: 'مزامنة البيانات تلقائياً عند توفر الإنترنت',
          type: 'switch',
          value: settings.autoSync,
        },
        {
          key: 'offlineMode',
          title: 'الوضع غير المتصل',
          subtitle: 'حفظ البيانات محلياً للعمل بدون إنترنت',
          type: 'switch',
          value: settings.offlineMode,
        },
      ],
    },
    {
      title: 'المظهر واللغة',
      items: [
        {
          key: 'darkMode',
          title: 'الوضع الليلي',
          subtitle: 'استخدام المظهر الداكن',
          type: 'switch',
          value: settings.darkMode,
        },
        {
          key: 'language',
          title: 'اللغة',
          subtitle: 'العربية',
          type: 'navigation',
          action: () => Alert.alert('اللغة', 'ميزة تغيير اللغة ستكون متاحة قريباً'),
        },
      ],
    },
    {
      title: 'البيانات والتخزين',
      items: [
        {
          key: 'exportData',
          title: 'تصدير البيانات',
          subtitle: 'تصدير جميع البيانات المحلية',
          type: 'action',
          action: handleExportData,
        },
        {
          key: 'importData',
          title: 'استيراد البيانات',
          subtitle: 'استيراد بيانات من ملف خارجي',
          type: 'action',
          action: handleImportData,
        },
        {
          key: 'clearCache',
          title: 'مسح التخزين المؤقت',
          subtitle: 'مسح البيانات المؤقتة لتحسين الأداء',
          type: 'action',
          action: handleClearCache,
        },
      ],
    },
  ];

  const renderSettingItem = (item: any) => {
    switch (item.type) {
      case 'switch':
        return (
          <View key={item.key} style={styles.settingItem}>
            <View style={styles.settingContent}>
              <Text style={styles.settingTitle}>{item.title}</Text>
              <Text style={styles.settingSubtitle}>{item.subtitle}</Text>
            </View>
            <Switch
              value={item.value}
              onValueChange={(value) => handleSettingChange(item.key, value)}
              trackColor={{ false: '#E0E0E0', true: '#A5D6A7' }}
              thumbColor={item.value ? '#2E7D32' : '#F4F3F4'}
            />
          </View>
        );
      case 'navigation':
        return (
          <TouchableOpacity key={item.key} style={styles.settingItem} onPress={item.action}>
            <View style={styles.settingContent}>
              <Text style={styles.settingTitle}>{item.title}</Text>
              <Text style={styles.settingSubtitle}>{item.subtitle}</Text>
            </View>
            <Text style={styles.chevron}>›</Text>
          </TouchableOpacity>
        );
      case 'action':
        return (
          <TouchableOpacity key={item.key} style={styles.settingItem} onPress={item.action}>
            <View style={styles.settingContent}>
              <Text style={styles.settingTitle}>{item.title}</Text>
              <Text style={styles.settingSubtitle}>{item.subtitle}</Text>
            </View>
            <Text style={styles.chevron}>›</Text>
          </TouchableOpacity>
        );
      default:
        return null;
    }
  };

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      {/* معلومات المستخدم */}
      <View style={styles.userSection}>
        <View style={styles.userAvatar}>
          <Text style={styles.userAvatarText}>👤</Text>
        </View>
        <View style={styles.userInfo}>
          <Text style={styles.userName}>مساح معتمد</Text>
          <Text style={styles.userEmail}>surveyor@binaa-yemen.com</Text>
          <Text style={styles.userRole}>مساح مساحي - المستوى الأول</Text>
        </View>
      </View>

      {/* أقسام الإعدادات */}
      {settingSections.map((section, sectionIndex) => (
        <View key={sectionIndex} style={styles.settingSection}>
          <Text style={styles.sectionTitle}>{section.title}</Text>
          <View style={styles.sectionContent}>
            {section.items.map(renderSettingItem)}
          </View>
        </View>
      ))}

      {/* معلومات التطبيق */}
      <View style={styles.appInfoSection}>
        <Text style={styles.sectionTitle}>معلومات التطبيق</Text>
        <View style={styles.sectionContent}>
          <View style={styles.infoItem}>
            <Text style={styles.infoLabel}>الإصدار</Text>
            <Text style={styles.infoValue}>1.0.0</Text>
          </View>
          <View style={styles.infoItem}>
            <Text style={styles.infoLabel}>آخر تحديث</Text>
            <Text style={styles.infoValue}>2024-01-15</Text>
          </View>
          <View style={styles.infoItem}>
            <Text style={styles.infoLabel}>المطور</Text>
            <Text style={styles.infoValue}>منصة بناء اليمن الرقمية</Text>
          </View>
        </View>
      </View>

      {/* أزرار الإجراءات */}
      <View style={styles.actionSection}>
        <TouchableOpacity style={styles.actionButton} onPress={() => Alert.alert('المساعدة', 'سيتم توجيهك إلى صفحة المساعدة')}>
          <Text style={styles.actionButtonText}>المساعدة والدعم</Text>
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.actionButton} onPress={() => Alert.alert('حول التطبيق', 'تطبيق المساح - منصة بناء اليمن الرقمية\nإصدار 1.0.0')}>
          <Text style={styles.actionButtonText}>حول التطبيق</Text>
        </TouchableOpacity>
        
        <TouchableOpacity style={[styles.actionButton, styles.logoutButton]} onPress={handleLogout}>
          <Text style={[styles.actionButtonText, styles.logoutButtonText]}>تسجيل الخروج</Text>
        </TouchableOpacity>
      </View>

      {/* مساحة إضافية في الأسفل */}
      <View style={styles.bottomSpacing} />
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F9FA',
  },
  userSection: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'white',
    padding: 20,
    marginBottom: 16,
  },
  userAvatar: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: '#2E7D32',
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 16,
  },
  userAvatarText: {
    fontSize: 24,
    color: 'white',
  },
  userInfo: {
    flex: 1,
  },
  userName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'right',
  },
  userEmail: {
    fontSize: 14,
    color: '#666',
    marginTop: 2,
    textAlign: 'right',
  },
  userRole: {
    fontSize: 12,
    color: '#2E7D32',
    marginTop: 4,
    textAlign: 'right',
  },
  settingSection: {
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    paddingHorizontal: 20,
    paddingVertical: 8,
    textAlign: 'right',
  },
  sectionContent: {
    backgroundColor: 'white',
  },
  settingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },
  settingContent: {
    flex: 1,
  },
  settingTitle: {
    fontSize: 16,
    color: '#333',
    textAlign: 'right',
  },
  settingSubtitle: {
    fontSize: 12,
    color: '#666',
    marginTop: 2,
    textAlign: 'right',
  },
  chevron: {
    fontSize: 20,
    color: '#CCC',
    marginRight: 8,
  },
  appInfoSection: {
    marginBottom: 16,
  },
  infoItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },
  infoLabel: {
    fontSize: 14,
    color: '#666',
  },
  infoValue: {
    fontSize: 14,
    color: '#333',
    fontWeight: '500',
  },
  actionSection: {
    padding: 20,
  },
  actionButton: {
    backgroundColor: 'white',
    borderRadius: 8,
    padding: 16,
    alignItems: 'center',
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#E0E0E0',
  },
  logoutButton: {
    backgroundColor: '#FFEBEE',
    borderColor: '#F44336',
  },
  actionButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  logoutButtonText: {
    color: '#F44336',
  },
  bottomSpacing: {
    height: 20,
  },
});

export default SettingsScreen;

