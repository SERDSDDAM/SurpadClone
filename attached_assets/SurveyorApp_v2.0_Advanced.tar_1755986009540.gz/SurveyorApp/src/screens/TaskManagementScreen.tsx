import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Alert,
  Modal,
  TextInput,
  FlatList,
  Switch,
} from 'react-native';
import TaskManagementService, {
  Task,
  Project,
  TaskTemplate,
  TaskFilter,
  TaskStatistics,
  TaskStatus,
  TaskPriority,
  TaskType,
} from '../services/TaskManagementService';

interface TaskManagementScreenProps {
  onNavigate?: (screen: string) => void;
}

const TaskManagementScreen: React.FC<TaskManagementScreenProps> = ({ onNavigate }) => {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [templates, setTemplates] = useState<TaskTemplate[]>([]);
  const [statistics, setStatistics] = useState<TaskStatistics | null>(null);
  const [filteredTasks, setFilteredTasks] = useState<Task[]>([]);
  
  const [showCreateTaskModal, setShowCreateTaskModal] = useState(false);
  const [showCreateProjectModal, setShowCreateProjectModal] = useState(false);
  const [showFilterModal, setShowFilterModal] = useState(false);
  const [showStatisticsModal, setShowStatisticsModal] = useState(false);
  
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  
  const [currentView, setCurrentView] = useState<'tasks' | 'projects' | 'templates'>('tasks');
  
  // فلتر المهام
  const [taskFilter, setTaskFilter] = useState<TaskFilter>({});
  
  // بيانات المهمة الجديدة
  const [newTask, setNewTask] = useState({
    title: '',
    description: '',
    type: 'field_survey' as TaskType,
    priority: 'medium' as TaskPriority,
    assignedTo: '',
    dueDate: '',
    templateId: '',
  });
  
  // بيانات المشروع الجديد
  const [newProject, setNewProject] = useState({
    name: '',
    description: '',
    clientName: '',
    clientContact: '',
    startDate: '',
    endDate: '',
    budget: '',
  });

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    applyFilter();
  }, [tasks, taskFilter]);

  /**
   * تحميل البيانات
   */
  const loadData = async () => {
    try {
      const [tasksData, projectsData, templatesData, statsData] = await Promise.all([
        TaskManagementService.getAllTasks(),
        TaskManagementService.getAllProjects(),
        TaskManagementService.getAvailableTemplates(),
        TaskManagementService.getTaskStatistics(),
      ]);
      
      setTasks(tasksData);
      setProjects(projectsData);
      setTemplates(templatesData);
      setStatistics(statsData);
    } catch (error) {
      Alert.alert('خطأ', 'فشل في تحميل البيانات');
    }
  };

  /**
   * تطبيق الفلتر على المهام
   */
  const applyFilter = () => {
    const filtered = TaskManagementService.filterTasks(taskFilter);
    setFilteredTasks(filtered);
  };

  /**
   * إنشاء مهمة جديدة
   */
  const createTask = async () => {
    if (!newTask.title.trim()) {
      Alert.alert('خطأ', 'يرجى إدخال عنوان المهمة');
      return;
    }

    try {
      let task: Task | null = null;

      if (newTask.templateId) {
        // إنشاء من قالب
        task = await TaskManagementService.createTaskFromTemplate(newTask.templateId, {
          title: newTask.title,
          description: newTask.description || undefined,
          priority: newTask.priority,
          assignedTo: newTask.assignedTo || undefined,
          dueDate: newTask.dueDate ? new Date(newTask.dueDate) : undefined,
        });
      } else {
        // إنشاء مهمة عادية
        task = await TaskManagementService.createTask({
          title: newTask.title,
          description: newTask.description || undefined,
          type: newTask.type,
          status: 'not_started',
          priority: newTask.priority,
          assignedTo: newTask.assignedTo || undefined,
          dueDate: newTask.dueDate ? new Date(newTask.dueDate) : undefined,
          attachments: [],
          subtasks: [],
          dependencies: [],
          tags: [],
          notes: [],
          progress: 0,
          metadata: {},
        });
      }

      if (task) {
        await loadData();
        setShowCreateTaskModal(false);
        resetNewTask();
        Alert.alert('تم الإنشاء', 'تم إنشاء المهمة بنجاح');
      }
    } catch (error) {
      Alert.alert('خطأ', 'فشل في إنشاء المهمة');
    }
  };

  /**
   * إنشاء مشروع جديد
   */
  const createProject = async () => {
    if (!newProject.name.trim()) {
      Alert.alert('خطأ', 'يرجى إدخال اسم المشروع');
      return;
    }

    try {
      await TaskManagementService.createProject({
        name: newProject.name,
        description: newProject.description || undefined,
        status: 'planning',
        priority: 'medium',
        clientName: newProject.clientName || undefined,
        clientContact: newProject.clientContact || undefined,
        startDate: newProject.startDate ? new Date(newProject.startDate) : new Date(),
        endDate: newProject.endDate ? new Date(newProject.endDate) : undefined,
        budget: newProject.budget ? parseFloat(newProject.budget) : undefined,
        teamMembers: [],
        tags: [],
        metadata: {},
      });

      await loadData();
      setShowCreateProjectModal(false);
      resetNewProject();
      Alert.alert('تم الإنشاء', 'تم إنشاء المشروع بنجاح');
    } catch (error) {
      Alert.alert('خطأ', 'فشل في إنشاء المشروع');
    }
  };

  /**
   * تحديث حالة المهمة
   */
  const updateTaskStatus = async (taskId: string, status: TaskStatus) => {
    try {
      await TaskManagementService.updateTask(taskId, { 
        status,
        completedAt: status === 'completed' ? new Date() : undefined,
        progress: status === 'completed' ? 100 : undefined,
      });
      await loadData();
    } catch (error) {
      Alert.alert('خطأ', 'فشل في تحديث حالة المهمة');
    }
  };

  /**
   * حذف مهمة
   */
  const deleteTask = (task: Task) => {
    Alert.alert(
      'تأكيد الحذف',
      `هل أنت متأكد من حذف المهمة "${task.title}"؟`,
      [
        { text: 'إلغاء', style: 'cancel' },
        {
          text: 'حذف',
          style: 'destructive',
          onPress: async () => {
            try {
              await TaskManagementService.deleteTask(task.id);
              await loadData();
              Alert.alert('تم الحذف', 'تم حذف المهمة بنجاح');
            } catch (error) {
              Alert.alert('خطأ', 'فشل في حذف المهمة');
            }
          },
        },
      ]
    );
  };

  /**
   * إعادة تعيين نموذج المهمة الجديدة
   */
  const resetNewTask = () => {
    setNewTask({
      title: '',
      description: '',
      type: 'field_survey',
      priority: 'medium',
      assignedTo: '',
      dueDate: '',
      templateId: '',
    });
  };

  /**
   * إعادة تعيين نموذج المشروع الجديد
   */
  const resetNewProject = () => {
    setNewProject({
      name: '',
      description: '',
      clientName: '',
      clientContact: '',
      startDate: '',
      endDate: '',
      budget: '',
    });
  };

  /**
   * تنسيق التاريخ
   */
  const formatDate = (date: Date): string => {
    return date.toLocaleDateString('ar-SA');
  };

  /**
   * الحصول على لون الحالة
   */
  const getStatusColor = (status: TaskStatus): string => {
    switch (status) {
      case 'completed': return '#4CAF50';
      case 'in_progress': return '#2196F3';
      case 'on_hold': return '#FF9800';
      case 'overdue': return '#F44336';
      case 'cancelled': return '#757575';
      default: return '#9E9E9E';
    }
  };

  /**
   * الحصول على لون الأولوية
   */
  const getPriorityColor = (priority: TaskPriority): string => {
    switch (priority) {
      case 'urgent': return '#F44336';
      case 'high': return '#FF9800';
      case 'medium': return '#2196F3';
      case 'low': return '#4CAF50';
      default: return '#757575';
    }
  };

  /**
   * الحصول على نص الحالة
   */
  const getStatusText = (status: TaskStatus): string => {
    switch (status) {
      case 'not_started': return 'لم تبدأ';
      case 'in_progress': return 'قيد التنفيذ';
      case 'on_hold': return 'معلقة';
      case 'completed': return 'مكتملة';
      case 'cancelled': return 'ملغاة';
      case 'overdue': return 'متأخرة';
      default: return status;
    }
  };

  /**
   * الحصول على نص الأولوية
   */
  const getPriorityText = (priority: TaskPriority): string => {
    switch (priority) {
      case 'urgent': return 'عاجل';
      case 'high': return 'عالي';
      case 'medium': return 'متوسط';
      case 'low': return 'منخفض';
      default: return priority;
    }
  };

  /**
   * الحصول على نص نوع المهمة
   */
  const getTaskTypeText = (type: TaskType): string => {
    switch (type) {
      case 'survey_planning': return 'تخطيط المسح';
      case 'field_survey': return 'مسح ميداني';
      case 'data_processing': return 'معالجة البيانات';
      case 'report_generation': return 'إنتاج التقارير';
      case 'client_meeting': return 'اجتماع عميل';
      case 'equipment_check': return 'فحص المعدات';
      case 'quality_control': return 'مراقبة الجودة';
      case 'documentation': return 'توثيق';
      case 'other': return 'أخرى';
      default: return type;
    }
  };

  /**
   * عرض نافذة إنشاء مهمة جديدة
   */
  const renderCreateTaskModal = () => (
    <Modal
      visible={showCreateTaskModal}
      animationType="slide"
      transparent={true}
      onRequestClose={() => setShowCreateTaskModal(false)}
    >
      <View style={styles.modalOverlay}>
        <View style={styles.createModal}>
          <Text style={styles.modalTitle}>إنشاء مهمة جديدة</Text>
          
          <ScrollView style={styles.createForm}>
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>عنوان المهمة *</Text>
              <TextInput
                style={styles.textInput}
                value={newTask.title}
                onChangeText={(text) => setNewTask(prev => ({ ...prev, title: text }))}
                placeholder="مثل: مسح الأراضي - المنطقة الشمالية"
              />
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>الوصف</Text>
              <TextInput
                style={[styles.textInput, styles.textArea]}
                value={newTask.description}
                onChangeText={(text) => setNewTask(prev => ({ ...prev, description: text }))}
                placeholder="وصف تفصيلي للمهمة"
                multiline
                numberOfLines={3}
              />
            </View>

            <View style={styles.inputRow}>
              <View style={styles.inputHalf}>
                <Text style={styles.inputLabel}>نوع المهمة</Text>
                <View style={styles.pickerContainer}>
                  {(['survey_planning', 'field_survey', 'data_processing', 'report_generation'] as TaskType[]).map(type => (
                    <TouchableOpacity
                      key={type}
                      style={[
                        styles.pickerOption,
                        newTask.type === type && styles.selectedPickerOption
                      ]}
                      onPress={() => setNewTask(prev => ({ ...prev, type }))}
                    >
                      <Text style={[
                        styles.pickerText,
                        newTask.type === type && styles.selectedPickerText
                      ]}>
                        {getTaskTypeText(type)}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </View>

              <View style={styles.inputHalf}>
                <Text style={styles.inputLabel}>الأولوية</Text>
                <View style={styles.pickerContainer}>
                  {(['low', 'medium', 'high', 'urgent'] as TaskPriority[]).map(priority => (
                    <TouchableOpacity
                      key={priority}
                      style={[
                        styles.pickerOption,
                        newTask.priority === priority && styles.selectedPickerOption
                      ]}
                      onPress={() => setNewTask(prev => ({ ...prev, priority }))}
                    >
                      <Text style={[
                        styles.pickerText,
                        newTask.priority === priority && styles.selectedPickerText
                      ]}>
                        {getPriorityText(priority)}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </View>
            </View>

            <View style={styles.inputRow}>
              <View style={styles.inputHalf}>
                <Text style={styles.inputLabel}>المكلف</Text>
                <TextInput
                  style={styles.textInput}
                  value={newTask.assignedTo}
                  onChangeText={(text) => setNewTask(prev => ({ ...prev, assignedTo: text }))}
                  placeholder="اسم المساح المكلف"
                />
              </View>

              <View style={styles.inputHalf}>
                <Text style={styles.inputLabel}>تاريخ الاستحقاق</Text>
                <TextInput
                  style={styles.textInput}
                  value={newTask.dueDate}
                  onChangeText={(text) => setNewTask(prev => ({ ...prev, dueDate: text }))}
                  placeholder="YYYY-MM-DD"
                />
              </View>
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>استخدام قالب</Text>
              <View style={styles.templateSelector}>
                <TouchableOpacity
                  style={[
                    styles.templateOption,
                    !newTask.templateId && styles.selectedTemplate
                  ]}
                  onPress={() => setNewTask(prev => ({ ...prev, templateId: '' }))}
                >
                  <Text style={[
                    styles.templateText,
                    !newTask.templateId && styles.selectedTemplateText
                  ]}>
                    بدون قالب
                  </Text>
                </TouchableOpacity>

                {templates.map(template => (
                  <TouchableOpacity
                    key={template.id}
                    style={[
                      styles.templateOption,
                      newTask.templateId === template.id && styles.selectedTemplate
                    ]}
                    onPress={() => setNewTask(prev => ({ ...prev, templateId: template.id }))}
                  >
                    <Text style={[
                      styles.templateText,
                      newTask.templateId === template.id && styles.selectedTemplateText
                    ]}>
                      {template.name}
                    </Text>
                    {template.description && (
                      <Text style={styles.templateDescription}>
                        {template.description}
                      </Text>
                    )}
                  </TouchableOpacity>
                ))}
              </View>
            </View>
          </ScrollView>

          <View style={styles.modalActions}>
            <TouchableOpacity
              style={styles.createButton}
              onPress={createTask}
            >
              <Text style={styles.createButtonText}>إنشاء المهمة</Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={styles.cancelButton}
              onPress={() => {
                setShowCreateTaskModal(false);
                resetNewTask();
              }}
            >
              <Text style={styles.cancelButtonText}>إلغاء</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );

  /**
   * عرض نافذة الإحصائيات
   */
  const renderStatisticsModal = () => (
    <Modal
      visible={showStatisticsModal}
      animationType="slide"
      transparent={true}
      onRequestClose={() => setShowStatisticsModal(false)}
    >
      <View style={styles.modalOverlay}>
        <View style={styles.statisticsModal}>
          <Text style={styles.modalTitle}>إحصائيات المهام</Text>
          
          {statistics && (
            <ScrollView style={styles.statisticsContent}>
              <View style={styles.statsGrid}>
                <View style={styles.statCard}>
                  <Text style={styles.statNumber}>{statistics.totalTasks}</Text>
                  <Text style={styles.statLabel}>إجمالي المهام</Text>
                </View>
                
                <View style={styles.statCard}>
                  <Text style={styles.statNumber}>{statistics.completedTasks}</Text>
                  <Text style={styles.statLabel}>مكتملة</Text>
                </View>
                
                <View style={styles.statCard}>
                  <Text style={styles.statNumber}>{statistics.inProgressTasks}</Text>
                  <Text style={styles.statLabel}>قيد التنفيذ</Text>
                </View>
                
                <View style={styles.statCard}>
                  <Text style={styles.statNumber}>{statistics.overdueTasks}</Text>
                  <Text style={styles.statLabel}>متأخرة</Text>
                </View>
              </View>

              <View style={styles.productivitySection}>
                <Text style={styles.sectionTitle}>نقاط الإنتاجية</Text>
                <View style={styles.productivityScore}>
                  <Text style={styles.scoreNumber}>{statistics.productivityScore}</Text>
                  <Text style={styles.scoreLabel}>من 100</Text>
                </View>
              </View>

              <View style={styles.averageSection}>
                <Text style={styles.sectionTitle}>متوسط وقت الإنجاز</Text>
                <Text style={styles.averageTime}>
                  {Math.round(statistics.averageCompletionTime / 60)} ساعة
                </Text>
              </View>

              <View style={styles.chartSection}>
                <Text style={styles.sectionTitle}>توزيع المهام حسب الحالة</Text>
                {Object.entries(statistics.tasksByStatus).map(([status, count]) => (
                  <View key={status} style={styles.chartItem}>
                    <View style={styles.chartLabel}>
                      <View style={[styles.chartColor, { backgroundColor: getStatusColor(status as TaskStatus) }]} />
                      <Text style={styles.chartText}>{getStatusText(status as TaskStatus)}</Text>
                    </View>
                    <Text style={styles.chartValue}>{count}</Text>
                  </View>
                ))}
              </View>
            </ScrollView>
          )}
          
          <TouchableOpacity
            style={styles.closeButton}
            onPress={() => setShowStatisticsModal(false)}
          >
            <Text style={styles.closeButtonText}>إغلاق</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );

  return (
    <View style={styles.container}>
      {/* شريط التنقل العلوي */}
      <View style={styles.tabBar}>
        <TouchableOpacity
          style={[styles.tab, currentView === 'tasks' && styles.activeTab]}
          onPress={() => setCurrentView('tasks')}
        >
          <Text style={[styles.tabText, currentView === 'tasks' && styles.activeTabText]}>
            المهام ({filteredTasks.length})
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[styles.tab, currentView === 'projects' && styles.activeTab]}
          onPress={() => setCurrentView('projects')}
        >
          <Text style={[styles.tabText, currentView === 'projects' && styles.activeTabText]}>
            المشاريع ({projects.length})
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[styles.tab, currentView === 'templates' && styles.activeTab]}
          onPress={() => setCurrentView('templates')}
        >
          <Text style={[styles.tabText, currentView === 'templates' && styles.activeTabText]}>
            القوالب ({templates.length})
          </Text>
        </TouchableOpacity>
      </View>

      {/* شريط الأدوات */}
      <View style={styles.toolbar}>
        <TouchableOpacity
          style={styles.toolbarButton}
          onPress={() => setShowStatisticsModal(true)}
        >
          <Text style={styles.toolbarButtonText}>الإحصائيات</Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={styles.toolbarButton}
          onPress={() => setShowFilterModal(true)}
        >
          <Text style={styles.toolbarButtonText}>فلترة</Text>
        </TouchableOpacity>
        
        {currentView === 'tasks' && (
          <TouchableOpacity
            style={[styles.toolbarButton, styles.primaryButton]}
            onPress={() => setShowCreateTaskModal(true)}
          >
            <Text style={[styles.toolbarButtonText, styles.primaryButtonText]}>+ مهمة</Text>
          </TouchableOpacity>
        )}
        
        {currentView === 'projects' && (
          <TouchableOpacity
            style={[styles.toolbarButton, styles.primaryButton]}
            onPress={() => setShowCreateProjectModal(true)}
          >
            <Text style={[styles.toolbarButtonText, styles.primaryButtonText]}>+ مشروع</Text>
          </TouchableOpacity>
        )}
      </View>

      <ScrollView style={styles.content}>
        {/* عرض المهام */}
        {currentView === 'tasks' && (
          <View style={styles.section}>
            {filteredTasks.length === 0 ? (
              <View style={styles.emptyState}>
                <Text style={styles.emptyText}>لا توجد مهام</Text>
                <Text style={styles.emptyHint}>
                  اضغط على "+ مهمة" لإنشاء مهمة جديدة
                </Text>
              </View>
            ) : (
              <FlatList
                data={filteredTasks}
                keyExtractor={(item) => item.id}
                renderItem={({ item }) => (
                  <View style={styles.taskCard}>
                    <View style={styles.taskHeader}>
                      <Text style={styles.taskTitle}>{item.title}</Text>
                      <View style={styles.taskBadges}>
                        <View style={[styles.statusBadge, { backgroundColor: getStatusColor(item.status) }]}>
                          <Text style={styles.badgeText}>{getStatusText(item.status)}</Text>
                        </View>
                        <View style={[styles.priorityBadge, { backgroundColor: getPriorityColor(item.priority) }]}>
                          <Text style={styles.badgeText}>{getPriorityText(item.priority)}</Text>
                        </View>
                      </View>
                    </View>
                    
                    {item.description && (
                      <Text style={styles.taskDescription}>{item.description}</Text>
                    )}
                    
                    <View style={styles.taskMeta}>
                      <Text style={styles.taskMetaText}>النوع: {getTaskTypeText(item.type)}</Text>
                      {item.assignedTo && (
                        <Text style={styles.taskMetaText}>المكلف: {item.assignedTo}</Text>
                      )}
                      {item.dueDate && (
                        <Text style={styles.taskMetaText}>الاستحقاق: {formatDate(item.dueDate)}</Text>
                      )}
                    </View>
                    
                    {/* شريط التقدم */}
                    <View style={styles.progressContainer}>
                      <View style={styles.progressBar}>
                        <View 
                          style={[
                            styles.progressFill,
                            { width: `${item.progress}%` }
                          ]} 
                        />
                      </View>
                      <Text style={styles.progressText}>{item.progress}%</Text>
                    </View>
                    
                    {/* المهام الفرعية */}
                    {item.subtasks.length > 0 && (
                      <View style={styles.subtasksContainer}>
                        <Text style={styles.subtasksTitle}>
                          المهام الفرعية ({item.subtasks.filter(st => st.status === 'completed').length}/{item.subtasks.length})
                        </Text>
                      </View>
                    )}
                    
                    <View style={styles.taskActions}>
                      {item.status !== 'completed' && (
                        <>
                          {item.status === 'not_started' && (
                            <TouchableOpacity
                              style={styles.startButton}
                              onPress={() => updateTaskStatus(item.id, 'in_progress')}
                            >
                              <Text style={styles.startButtonText}>بدء</Text>
                            </TouchableOpacity>
                          )}
                          
                          {item.status === 'in_progress' && (
                            <TouchableOpacity
                              style={styles.completeButton}
                              onPress={() => updateTaskStatus(item.id, 'completed')}
                            >
                              <Text style={styles.completeButtonText}>إكمال</Text>
                            </TouchableOpacity>
                          )}
                        </>
                      )}
                      
                      <TouchableOpacity
                        style={styles.deleteButton}
                        onPress={() => deleteTask(item)}
                      >
                        <Text style={styles.deleteButtonText}>حذف</Text>
                      </TouchableOpacity>
                    </View>
                    
                    <Text style={styles.taskDate}>
                      تم الإنشاء: {formatDate(item.createdAt)}
                    </Text>
                  </View>
                )}
                scrollEnabled={false}
              />
            )}
          </View>
        )}

        {/* عرض المشاريع */}
        {currentView === 'projects' && (
          <View style={styles.section}>
            {projects.length === 0 ? (
              <View style={styles.emptyState}>
                <Text style={styles.emptyText}>لا توجد مشاريع</Text>
                <Text style={styles.emptyHint}>
                  اضغط على "+ مشروع" لإنشاء مشروع جديد
                </Text>
              </View>
            ) : (
              <FlatList
                data={projects}
                keyExtractor={(item) => item.id}
                renderItem={({ item }) => (
                  <View style={styles.projectCard}>
                    <Text style={styles.projectName}>{item.name}</Text>
                    {item.description && (
                      <Text style={styles.projectDescription}>{item.description}</Text>
                    )}
                    
                    <View style={styles.projectMeta}>
                      {item.clientName && (
                        <Text style={styles.projectMetaText}>العميل: {item.clientName}</Text>
                      )}
                      <Text style={styles.projectMetaText}>
                        المهام: {TaskManagementService.getProjectTasks(item.id).length}
                      </Text>
                      <Text style={styles.projectMetaText}>
                        بدء: {formatDate(item.startDate)}
                      </Text>
                    </View>
                  </View>
                )}
                scrollEnabled={false}
              />
            )}
          </View>
        )}

        {/* عرض القوالب */}
        {currentView === 'templates' && (
          <View style={styles.section}>
            <FlatList
              data={templates}
              keyExtractor={(item) => item.id}
              renderItem={({ item }) => (
                <View style={styles.templateCard}>
                  <Text style={styles.templateName}>{item.name}</Text>
                  {item.description && (
                    <Text style={styles.templateCardDescription}>{item.description}</Text>
                  )}
                  
                  <View style={styles.templateMeta}>
                    <Text style={styles.templateMetaText}>
                      النوع: {getTaskTypeText(item.type)}
                    </Text>
                    {item.estimatedDuration && (
                      <Text style={styles.templateMetaText}>
                        المدة المقدرة: {Math.round(item.estimatedDuration / 60)} ساعة
                      </Text>
                    )}
                    <Text style={styles.templateMetaText}>
                      المهام الفرعية: {item.subtasks.length}
                    </Text>
                  </View>
                  
                  {item.isDefault && (
                    <View style={styles.defaultBadge}>
                      <Text style={styles.defaultText}>افتراضي</Text>
                    </View>
                  )}
                </View>
              )}
              scrollEnabled={false}
            />
          </View>
        )}
      </ScrollView>

      {renderCreateTaskModal()}
      {renderStatisticsModal()}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  tabBar: {
    flexDirection: 'row',
    backgroundColor: '#FFFFFF',
    elevation: 2,
  },
  tab: {
    flex: 1,
    paddingVertical: 16,
    alignItems: 'center',
    borderBottomWidth: 2,
    borderBottomColor: 'transparent',
  },
  activeTab: {
    borderBottomColor: '#2196F3',
  },
  tabText: {
    fontSize: 14,
    color: '#757575',
  },
  activeTabText: {
    color: '#2196F3',
    fontWeight: 'bold',
  },
  toolbar: {
    flexDirection: 'row',
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 8,
    elevation: 1,
  },
  toolbarButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 6,
    backgroundColor: '#f8f9fa',
    borderWidth: 1,
    borderColor: '#E0E0E0',
  },
  primaryButton: {
    backgroundColor: '#4CAF50',
    borderColor: '#4CAF50',
  },
  toolbarButtonText: {
    fontSize: 12,
    color: '#424242',
    fontWeight: 'bold',
  },
  primaryButtonText: {
    color: '#FFFFFF',
  },
  content: {
    flex: 1,
  },
  section: {
    backgroundColor: '#FFFFFF',
    margin: 16,
    borderRadius: 12,
    padding: 16,
    elevation: 2,
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 32,
  },
  emptyText: {
    fontSize: 16,
    color: '#757575',
    textAlign: 'center',
    marginBottom: 8,
  },
  emptyHint: {
    fontSize: 14,
    color: '#9E9E9E',
    textAlign: 'center',
  },
  taskCard: {
    backgroundColor: '#f8f9fa',
    padding: 16,
    borderRadius: 8,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#E0E0E0',
  },
  taskHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 8,
  },
  taskTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#212121',
    flex: 1,
    marginRight: 8,
  },
  taskBadges: {
    gap: 4,
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 4,
  },
  priorityBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 4,
  },
  badgeText: {
    color: '#FFFFFF',
    fontSize: 10,
    fontWeight: 'bold',
  },
  taskDescription: {
    fontSize: 14,
    color: '#424242',
    marginBottom: 8,
  },
  taskMeta: {
    marginBottom: 12,
  },
  taskMetaText: {
    fontSize: 12,
    color: '#757575',
    marginBottom: 2,
  },
  progressContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  progressBar: {
    flex: 1,
    height: 6,
    backgroundColor: '#E0E0E0',
    borderRadius: 3,
    marginRight: 8,
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#4CAF50',
    borderRadius: 3,
  },
  progressText: {
    fontSize: 10,
    color: '#757575',
    fontWeight: 'bold',
  },
  subtasksContainer: {
    marginBottom: 12,
  },
  subtasksTitle: {
    fontSize: 12,
    color: '#2196F3',
    fontWeight: 'bold',
  },
  taskActions: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 8,
  },
  startButton: {
    backgroundColor: '#4CAF50',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 4,
  },
  startButtonText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: 'bold',
  },
  completeButton: {
    backgroundColor: '#2196F3',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 4,
  },
  completeButtonText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: 'bold',
  },
  deleteButton: {
    backgroundColor: '#F44336',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 4,
  },
  deleteButtonText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: 'bold',
  },
  taskDate: {
    fontSize: 10,
    color: '#9E9E9E',
  },
  projectCard: {
    backgroundColor: '#f8f9fa',
    padding: 16,
    borderRadius: 8,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#E0E0E0',
  },
  projectName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#212121',
    marginBottom: 8,
  },
  projectDescription: {
    fontSize: 14,
    color: '#424242',
    marginBottom: 8,
  },
  projectMeta: {
    marginBottom: 8,
  },
  projectMetaText: {
    fontSize: 12,
    color: '#757575',
    marginBottom: 2,
  },
  templateCard: {
    backgroundColor: '#f8f9fa',
    padding: 16,
    borderRadius: 8,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#E0E0E0',
  },
  templateName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#212121',
    marginBottom: 8,
  },
  templateCardDescription: {
    fontSize: 14,
    color: '#424242',
    marginBottom: 8,
  },
  templateMeta: {
    marginBottom: 8,
  },
  templateMetaText: {
    fontSize: 12,
    color: '#757575',
    marginBottom: 2,
  },
  defaultBadge: {
    alignSelf: 'flex-start',
    backgroundColor: '#4CAF50',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 4,
  },
  defaultText: {
    color: '#FFFFFF',
    fontSize: 10,
    fontWeight: 'bold',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  createModal: {
    backgroundColor: '#FFFFFF',
    width: '95%',
    maxHeight: '90%',
    borderRadius: 12,
    padding: 20,
  },
  statisticsModal: {
    backgroundColor: '#FFFFFF',
    width: '90%',
    maxHeight: '80%',
    borderRadius: 12,
    padding: 20,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#212121',
    textAlign: 'center',
    marginBottom: 20,
  },
  createForm: {
    maxHeight: 500,
  },
  inputGroup: {
    marginBottom: 16,
  },
  inputRow: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 16,
  },
  inputHalf: {
    flex: 1,
  },
  inputLabel: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#212121',
    marginBottom: 8,
  },
  textInput: {
    borderWidth: 1,
    borderColor: '#E0E0E0',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 14,
  },
  textArea: {
    height: 80,
    textAlignVertical: 'top',
  },
  pickerContainer: {
    gap: 4,
  },
  pickerOption: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderWidth: 1,
    borderColor: '#E0E0E0',
    borderRadius: 6,
    backgroundColor: '#f8f9fa',
  },
  selectedPickerOption: {
    backgroundColor: '#2196F3',
    borderColor: '#2196F3',
  },
  pickerText: {
    fontSize: 12,
    color: '#424242',
  },
  selectedPickerText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
  },
  templateSelector: {
    gap: 8,
  },
  templateOption: {
    padding: 12,
    borderWidth: 1,
    borderColor: '#E0E0E0',
    borderRadius: 8,
    backgroundColor: '#f8f9fa',
  },
  selectedTemplate: {
    backgroundColor: '#E3F2FD',
    borderColor: '#2196F3',
  },
  templateText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#212121',
  },
  selectedTemplateText: {
    color: '#1976D2',
  },
  templateDescription: {
    fontSize: 12,
    color: '#757575',
    marginTop: 4,
  },
  modalActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 20,
    gap: 12,
  },
  createButton: {
    flex: 1,
    backgroundColor: '#4CAF50',
    paddingVertical: 14,
    borderRadius: 8,
    alignItems: 'center',
  },
  createButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  cancelButton: {
    flex: 1,
    backgroundColor: '#757575',
    paddingVertical: 14,
    borderRadius: 8,
    alignItems: 'center',
  },
  cancelButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  statisticsContent: {
    maxHeight: 400,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  statCard: {
    width: '48%',
    backgroundColor: '#f8f9fa',
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
    marginBottom: 8,
  },
  statNumber: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#2196F3',
  },
  statLabel: {
    fontSize: 12,
    color: '#757575',
    marginTop: 4,
  },
  productivitySection: {
    alignItems: 'center',
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#212121',
    marginBottom: 12,
  },
  productivityScore: {
    alignItems: 'center',
  },
  scoreNumber: {
    fontSize: 36,
    fontWeight: 'bold',
    color: '#4CAF50',
  },
  scoreLabel: {
    fontSize: 14,
    color: '#757575',
  },
  averageSection: {
    alignItems: 'center',
    marginBottom: 20,
  },
  averageTime: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FF9800',
  },
  chartSection: {
    marginBottom: 20,
  },
  chartItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 8,
  },
  chartLabel: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  chartColor: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginRight: 8,
  },
  chartText: {
    fontSize: 14,
    color: '#424242',
  },
  chartValue: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#212121',
  },
  closeButton: {
    backgroundColor: '#2196F3',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 16,
  },
  closeButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default TaskManagementScreen;

