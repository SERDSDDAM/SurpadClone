/**
 * شاشة الخريطة المحدثة مع الميزات الجديدة
 * Updated Map Screen with New Features
 */

import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Alert,
  Modal,
  TextInput,
  ScrollView,
} from 'react-native';
import MapComponent from '../components/MapComponent';
import SurveyDataCollector from '../components/SurveyDataCollector';
import SyncStatusIndicator from '../components/SyncStatusIndicator';
import LocationService, { SurveyPoint } from '../services/LocationService';
import DataCollectionService, { SurveyProject } from '../services/DataCollectionService';
import { LatLng } from 'react-native-maps';

interface MapScreenProps {
  onNavigate: (screen: string) => void;
}

const MapScreen: React.FC<MapScreenProps> = ({ onNavigate }) => {
  const [currentProject, setCurrentProject] = useState<SurveyProject | null>(null);
  const [projects, setProjects] = useState<SurveyProject[]>([]);
  const [showProjectModal, setShowProjectModal] = useState(false);
  const [showDataCollector, setShowDataCollector] = useState(false);
  const [newProjectData, setNewProjectData] = useState({
    name: '',
    description: '',
    location: '',
  });

  useEffect(() => {
    loadProjects();
  }, []);

  const loadProjects = async () => {
    try {
      const allProjects = await DataCollectionService.getAllProjects();
      setProjects(allProjects);
      
      // اختيار أول مشروع نشط أو إنشاء مشروع افتراضي
      const activeProject = allProjects.find(p => p.status === 'active') || allProjects[0];
      if (activeProject) {
        setCurrentProject(activeProject);
      } else {
        // إنشاء مشروع افتراضي
        await createDefaultProject();
      }
    } catch (error) {
      console.error('خطأ في تحميل المشاريع:', error);
    }
  };

  const createDefaultProject = async () => {
    try {
      const defaultProject = await DataCollectionService.createProject(
        'مشروع جديد',
        'مشروع مسح افتراضي',
        'الموقع الحالي'
      );
      setCurrentProject(defaultProject);
      setProjects([defaultProject]);
    } catch (error) {
      console.error('خطأ في إنشاء المشروع الافتراضي:', error);
    }
  };

  const createNewProject = async () => {
    if (!newProjectData.name.trim()) {
      Alert.alert('خطأ', 'يرجى إدخال اسم المشروع');
      return;
    }

    try {
      const project = await DataCollectionService.createProject(
        newProjectData.name,
        newProjectData.description,
        newProjectData.location || 'الموقع الحالي'
      );

      setCurrentProject(project);
      await loadProjects();
      setNewProjectData({ name: '', description: '', location: '' });
      setShowProjectModal(false);
      
      Alert.alert('تم', 'تم إنشاء المشروع بنجاح');
    } catch (error) {
      console.error('خطأ في إنشاء المشروع:', error);
      Alert.alert('خطأ', 'فشل في إنشاء المشروع');
    }
  };

  const handleMapPress = async (coordinate: LatLng) => {
    if (!currentProject) return;

    Alert.alert(
      'إضافة نقطة',
      'هل تريد إضافة نقطة مسح في هذا الموقع؟',
      [
        { text: 'إلغاء', style: 'cancel' },
        {
          text: 'إضافة',
          onPress: async () => {
            try {
              const pointName = `نقطة ${currentProject.points.length + 1}`;
              await DataCollectionService.addSurveyPoint(
                currentProject.id,
                pointName,
                {
                  latitude: coordinate.latitude,
                  longitude: coordinate.longitude,
                  accuracy: 5, // دقة افتراضية
                  timestamp: Date.now(),
                },
                'reference'
              );
              
              await loadProjects();
              Alert.alert('تم', 'تم إضافة النقطة بنجاح');
            } catch (error) {
              console.error('خطأ في إضافة النقطة:', error);
              Alert.alert('خطأ', 'فشل في إضافة النقطة');
            }
          },
        },
      ]
    );
  };

  const handleMarkerPress = (point: SurveyPoint) => {
    const coordinates = LocationService.formatCoordinates(point.coordinates);
    Alert.alert(
      point.name,
      `النوع: ${getPointTypeText(point.type)}\n` +
      `الإحداثيات: ${coordinates.latitude}, ${coordinates.longitude}\n` +
      `الدقة: ±${point.coordinates.accuracy.toFixed(1)} متر\n` +
      `${point.notes ? `الملاحظات: ${point.notes}` : ''}`,
      [
        { text: 'إغلاق', style: 'cancel' },
        {
          text: 'حذف',
          style: 'destructive',
          onPress: () => confirmDeletePoint(point),
        },
      ]
    );
  };

  const confirmDeletePoint = (point: SurveyPoint) => {
    Alert.alert(
      'تأكيد الحذف',
      `هل تريد حذف النقطة "${point.name}"؟`,
      [
        { text: 'إلغاء', style: 'cancel' },
        {
          text: 'حذف',
          style: 'destructive',
          onPress: async () => {
            try {
              if (currentProject) {
                const updatedProject = {
                  ...currentProject,
                  points: currentProject.points.filter(p => p.id !== point.id),
                };
                await DataCollectionService.saveProject(updatedProject);
                await loadProjects();
                Alert.alert('تم', 'تم حذف النقطة');
              }
            } catch (error) {
              console.error('خطأ في حذف النقطة:', error);
              Alert.alert('خطأ', 'فشل في حذف النقطة');
            }
          },
        },
      ]
    );
  };

  const getPointTypeText = (type: SurveyPoint['type']): string => {
    switch (type) {
      case 'boundary': return 'حد';
      case 'corner': return 'زاوية';
      case 'reference': return 'مرجع';
      case 'building': return 'مبنى';
      default: return 'غير محدد';
    }
  };

  const getBoundaries = (): LatLng[][] => {
    if (!currentProject || currentProject.boundaries.length === 0) return [];
    
    return currentProject.boundaries.map(boundary =>
      boundary.points.map(point => ({
        latitude: point.latitude,
        longitude: point.longitude,
      }))
    );
  };

  const exportProjectData = async () => {
    if (!currentProject) return;

    try {
      const filePath = await DataCollectionService.exportProjectToCSV(currentProject.id);
      Alert.alert(
        'تم التصدير',
        `تم تصدير بيانات المشروع إلى:\n${filePath}`,
        [
          { text: 'موافق' },
          {
            text: 'مشاركة',
            onPress: () => {
              // يمكن إضافة منطق المشاركة هنا
              Alert.alert('قريباً', 'ميزة المشاركة ستكون متاحة قريباً');
            },
          },
        ]
      );
    } catch (error) {
      console.error('خطأ في تصدير البيانات:', error);
      Alert.alert('خطأ', 'فشل في تصدير البيانات');
    }
  };

  return (
    <View style={styles.container}>
      {/* شريط الأدوات العلوي */}
      <View style={styles.toolbar}>
        <View style={styles.toolbarLeft}>
          <SyncStatusIndicator showDetails={true} />
        </View>
        
        <View style={styles.toolbarCenter}>
          <Text style={styles.projectTitle}>
            {currentProject?.name || 'لا يوجد مشروع'}
          </Text>
          <Text style={styles.projectSubtitle}>
            {currentProject?.points.length || 0} نقطة
          </Text>
        </View>

        <View style={styles.toolbarRight}>
          <TouchableOpacity
            style={styles.toolbarButton}
            onPress={() => setShowProjectModal(true)}
          >
            <Text style={styles.toolbarButtonText}>➕</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* الخريطة */}
      <View style={styles.mapContainer}>
        <MapComponent
          points={currentProject?.points || []}
          boundaries={getBoundaries()}
          onMapPress={handleMapPress}
          onMarkerPress={handleMarkerPress}
          showCurrentLocation={true}
          editable={true}
          style={styles.map}
        />
      </View>

      {/* شريط الأدوات السفلي */}
      <View style={styles.bottomToolbar}>
        <TouchableOpacity
          style={styles.bottomButton}
          onPress={() => setShowDataCollector(!showDataCollector)}
        >
          <Text style={styles.bottomButtonIcon}>📊</Text>
          <Text style={styles.bottomButtonText}>جمع البيانات</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.bottomButton}
          onPress={exportProjectData}
          disabled={!currentProject || currentProject.points.length === 0}
        >
          <Text style={styles.bottomButtonIcon}>📤</Text>
          <Text style={styles.bottomButtonText}>تصدير</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.bottomButton}
          onPress={() => onNavigate('surveys')}
        >
          <Text style={styles.bottomButtonIcon}>📋</Text>
          <Text style={styles.bottomButtonText}>الطلبات</Text>
        </TouchableOpacity>
      </View>

      {/* جامع البيانات */}
      {showDataCollector && currentProject && (
        <View style={styles.dataCollectorContainer}>
          <View style={styles.dataCollectorHeader}>
            <TouchableOpacity
              onPress={() => setShowDataCollector(false)}
              style={styles.closeButton}
            >
              <Text style={styles.closeButtonText}>✕</Text>
            </TouchableOpacity>
            <Text style={styles.dataCollectorTitle}>جمع البيانات</Text>
          </View>
          <SurveyDataCollector
            projectId={currentProject.id}
            onDataUpdated={loadProjects}
          />
        </View>
      )}

      {/* نافذة إنشاء مشروع جديد */}
      <Modal
        visible={showProjectModal}
        animationType="slide"
        presentationStyle="pageSheet"
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <TouchableOpacity
              onPress={() => setShowProjectModal(false)}
              style={styles.modalCloseButton}
            >
              <Text style={styles.modalCloseText}>إلغاء</Text>
            </TouchableOpacity>
            <Text style={styles.modalTitle}>مشروع جديد</Text>
            <TouchableOpacity
              onPress={createNewProject}
              style={styles.modalSaveButton}
            >
              <Text style={styles.modalSaveText}>إنشاء</Text>
            </TouchableOpacity>
          </View>

          <ScrollView style={styles.modalContent}>
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>اسم المشروع *</Text>
              <TextInput
                style={styles.textInput}
                value={newProjectData.name}
                onChangeText={(text) => setNewProjectData({ ...newProjectData, name: text })}
                placeholder="مثال: مسح أراضي حي السبعين"
                placeholderTextColor="#999"
                textAlign="right"
              />
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>الوصف</Text>
              <TextInput
                style={[styles.textInput, styles.textArea]}
                value={newProjectData.description}
                onChangeText={(text) => setNewProjectData({ ...newProjectData, description: text })}
                placeholder="وصف مختصر للمشروع..."
                placeholderTextColor="#999"
                multiline
                numberOfLines={3}
                textAlign="right"
                textAlignVertical="top"
              />
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>الموقع</Text>
              <TextInput
                style={styles.textInput}
                value={newProjectData.location}
                onChangeText={(text) => setNewProjectData({ ...newProjectData, location: text })}
                placeholder="مثال: صنعاء، حي السبعين"
                placeholderTextColor="#999"
                textAlign="right"
              />
            </View>

            {/* قائمة المشاريع الموجودة */}
            {projects.length > 0 && (
              <View style={styles.existingProjects}>
                <Text style={styles.existingProjectsTitle}>المشاريع الموجودة:</Text>
                {projects.map((project) => (
                  <TouchableOpacity
                    key={project.id}
                    style={[
                      styles.projectItem,
                      currentProject?.id === project.id && styles.activeProjectItem
                    ]}
                    onPress={() => {
                      setCurrentProject(project);
                      setShowProjectModal(false);
                    }}
                  >
                    <View style={styles.projectItemContent}>
                      <Text style={styles.projectItemName}>{project.name}</Text>
                      <Text style={styles.projectItemDetails}>
                        {project.points.length} نقطة • {project.status}
                      </Text>
                    </View>
                    <Text style={styles.projectItemDate}>
                      {project.updatedAt.toLocaleDateString('ar-SA')}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            )}
          </ScrollView>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F9FA',
  },
  toolbar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: 'white',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
  },
  toolbarLeft: {
    flex: 1,
  },
  toolbarCenter: {
    flex: 2,
    alignItems: 'center',
  },
  toolbarRight: {
    flex: 1,
    alignItems: 'flex-end',
  },
  projectTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'center',
  },
  projectSubtitle: {
    fontSize: 12,
    color: '#666',
    textAlign: 'center',
  },
  toolbarButton: {
    width: 36,
    height: 36,
    backgroundColor: '#2E7D32',
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
  },
  toolbarButtonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
  mapContainer: {
    flex: 1,
  },
  map: {
    flex: 1,
  },
  bottomToolbar: {
    flexDirection: 'row',
    backgroundColor: 'white',
    borderTopWidth: 1,
    borderTopColor: '#E0E0E0',
    paddingVertical: 8,
  },
  bottomButton: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 8,
  },
  bottomButtonIcon: {
    fontSize: 20,
    marginBottom: 4,
  },
  bottomButtonText: {
    fontSize: 12,
    color: '#333',
    fontWeight: 'bold',
  },
  dataCollectorContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: '50%',
    backgroundColor: 'white',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: -2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  dataCollectorHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
  },
  closeButton: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#F0F0F0',
    justifyContent: 'center',
    alignItems: 'center',
  },
  closeButtonText: {
    fontSize: 16,
    color: '#666',
  },
  dataCollectorTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    flex: 1,
    textAlign: 'center',
  },
  modalContainer: {
    flex: 1,
    backgroundColor: 'white',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
  },
  modalCloseButton: {
    padding: 8,
  },
  modalCloseText: {
    color: '#666',
    fontSize: 16,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  modalSaveButton: {
    padding: 8,
  },
  modalSaveText: {
    color: '#2E7D32',
    fontSize: 16,
    fontWeight: 'bold',
  },
  modalContent: {
    flex: 1,
    padding: 20,
  },
  inputGroup: {
    marginBottom: 20,
  },
  inputLabel: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 8,
    textAlign: 'right',
  },
  textInput: {
    borderWidth: 1,
    borderColor: '#DDD',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    backgroundColor: '#F9F9F9',
    textAlign: 'right',
  },
  textArea: {
    height: 80,
  },
  existingProjects: {
    marginTop: 20,
  },
  existingProjectsTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 12,
    textAlign: 'right',
  },
  projectItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#F8F9FA',
    padding: 16,
    borderRadius: 8,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: '#E0E0E0',
  },
  activeProjectItem: {
    backgroundColor: '#E8F5E8',
    borderColor: '#4CAF50',
  },
  projectItemContent: {
    flex: 1,
  },
  projectItemName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'right',
    marginBottom: 4,
  },
  projectItemDetails: {
    fontSize: 12,
    color: '#666',
    textAlign: 'right',
  },
  projectItemDate: {
    fontSize: 12,
    color: '#666',
    marginLeft: 12,
  },
});

export default MapScreen;

