import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Alert,
  Modal,
  TextInput,
  FlatList,
  ProgressBarAndroid,
  Switch,
} from 'react-native';
import OfflineMapService, {
  MapRegion,
  MapProvider,
  DownloadProgress,
} from '../services/OfflineMapService';

interface OfflineMapScreenProps {
  onNavigate?: (screen: string) => void;
}

const OfflineMapScreen: React.FC<OfflineMapScreenProps> = ({ onNavigate }) => {
  const [regions, setRegions] = useState<MapRegion[]>([]);
  const [mapProviders, setMapProviders] = useState<MapProvider[]>([]);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showStorageModal, setShowStorageModal] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState<Map<string, DownloadProgress>>(new Map());
  const [storageStats, setStorageStats] = useState({
    totalRegions: 0,
    totalTiles: 0,
    totalSize: 0,
    availableSpace: 0,
  });

  // بيانات إنشاء منطقة جديدة
  const [newRegion, setNewRegion] = useState({
    name: '',
    description: '',
    north: 15.3710,
    south: 15.3690,
    east: 44.1920,
    west: 44.1900,
    minZoom: 10,
    maxZoom: 16,
    providerId: 'osm',
  });

  useEffect(() => {
    loadData();
    
    // تسجيل مستمع لتقدم التنزيل
    OfflineMapService.registerProgressListener('screen', handleDownloadProgress);
    
    return () => {
      OfflineMapService.unregisterProgressListener('screen');
    };
  }, []);

  /**
   * تحميل البيانات
   */
  const loadData = async () => {
    try {
      const [regionsData, providersData, statsData] = await Promise.all([
        OfflineMapService.getAllRegions(),
        OfflineMapService.getMapProviders(),
        OfflineMapService.getStorageStats(),
      ]);
      
      setRegions(regionsData);
      setMapProviders(providersData);
      setStorageStats(statsData);
    } catch (error) {
      Alert.alert('خطأ', 'فشل في تحميل البيانات');
    }
  };

  /**
   * معالج تقدم التنزيل
   */
  const handleDownloadProgress = (progress: DownloadProgress) => {
    setDownloadProgress(prev => new Map(prev.set(progress.regionId, progress)));
  };

  /**
   * إنشاء منطقة جديدة
   */
  const createNewRegion = async () => {
    if (!newRegion.name.trim()) {
      Alert.alert('خطأ', 'يرجى إدخال اسم المنطقة');
      return;
    }

    try {
      const region = await OfflineMapService.createMapRegion(
        newRegion.name.trim(),
        {
          north: newRegion.north,
          south: newRegion.south,
          east: newRegion.east,
          west: newRegion.west,
        },
        newRegion.minZoom,
        newRegion.maxZoom,
        newRegion.providerId,
        newRegion.description.trim() || undefined
      );

      setRegions(prev => [region, ...prev]);
      setShowCreateModal(false);
      
      // إعادة تعيين النموذج
      setNewRegion({
        name: '',
        description: '',
        north: 15.3710,
        south: 15.3690,
        east: 44.1920,
        west: 44.1900,
        minZoom: 10,
        maxZoom: 16,
        providerId: 'osm',
      });

      Alert.alert(
        'تم الإنشاء',
        `تم إنشاء منطقة "${region.name}" بنجاح\nعدد البلاطات: ${region.tileCount}`,
        [
          { text: 'موافق' },
          {
            text: 'بدء التنزيل',
            onPress: () => startDownload(region.id),
          },
        ]
      );
    } catch (error) {
      Alert.alert('خطأ', error.message);
    }
  };

  /**
   * بدء تنزيل منطقة
   */
  const startDownload = async (regionId: string) => {
    try {
      await OfflineMapService.startDownload(regionId);
      await loadData(); // تحديث البيانات
    } catch (error) {
      Alert.alert('خطأ', error.message);
    }
  };

  /**
   * إيقاف تنزيل منطقة
   */
  const pauseDownload = async (regionId: string) => {
    try {
      await OfflineMapService.pauseDownload(regionId);
      await loadData();
    } catch (error) {
      Alert.alert('خطأ', error.message);
    }
  };

  /**
   * استئناف تنزيل منطقة
   */
  const resumeDownload = async (regionId: string) => {
    try {
      await OfflineMapService.resumeDownload(regionId);
      await loadData();
    } catch (error) {
      Alert.alert('خطأ', error.message);
    }
  };

  /**
   * حذف منطقة
   */
  const deleteRegion = (region: MapRegion) => {
    Alert.alert(
      'تأكيد الحذف',
      `هل أنت متأكد من حذف منطقة "${region.name}"؟\n\nسيتم حذف جميع البلاطات المحملة (${formatFileSize(region.downloadedSize)})`,
      [
        { text: 'إلغاء', style: 'cancel' },
        {
          text: 'حذف',
          style: 'destructive',
          onPress: async () => {
            try {
              await OfflineMapService.deleteRegion(region.id);
              setRegions(prev => prev.filter(r => r.id !== region.id));
              await loadData(); // تحديث الإحصائيات
              Alert.alert('تم الحذف', 'تم حذف المنطقة بنجاح');
            } catch (error) {
              Alert.alert('خطأ', 'فشل في حذف المنطقة');
            }
          },
        },
      ]
    );
  };

  /**
   * تنسيق حجم الملف
   */
  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  /**
   * تنسيق التاريخ
   */
  const formatDate = (date: Date): string => {
    return date.toLocaleString('ar-SA');
  };

  /**
   * الحصول على لون الحالة
   */
  const getStatusColor = (status: string): string => {
    switch (status) {
      case 'completed': return '#4CAF50';
      case 'downloading': return '#2196F3';
      case 'paused': return '#FF9800';
      case 'error': return '#F44336';
      default: return '#757575';
    }
  };

  /**
   * الحصول على نص الحالة
   */
  const getStatusText = (status: string): string => {
    switch (status) {
      case 'completed': return 'مكتمل';
      case 'downloading': return 'جاري التنزيل';
      case 'paused': return 'متوقف';
      case 'error': return 'خطأ';
      case 'pending': return 'في الانتظار';
      default: return status;
    }
  };

  /**
   * حساب نسبة التقدم
   */
  const getProgressPercentage = (region: MapRegion): number => {
    return region.tileCount > 0 ? (region.downloadedTiles / region.tileCount) * 100 : 0;
  };

  /**
   * عرض نافذة إنشاء منطقة جديدة
   */
  const renderCreateModal = () => (
    <Modal
      visible={showCreateModal}
      animationType="slide"
      transparent={true}
      onRequestClose={() => setShowCreateModal(false)}
    >
      <View style={styles.modalOverlay}>
        <View style={styles.createModal}>
          <Text style={styles.modalTitle}>إنشاء منطقة خريطة جديدة</Text>
          
          <ScrollView style={styles.createForm}>
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>اسم المنطقة *</Text>
              <TextInput
                style={styles.textInput}
                value={newRegion.name}
                onChangeText={(text) => setNewRegion(prev => ({ ...prev, name: text }))}
                placeholder="مثل: منطقة المسح الشمالية"
              />
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>الوصف</Text>
              <TextInput
                style={[styles.textInput, styles.textArea]}
                value={newRegion.description}
                onChangeText={(text) => setNewRegion(prev => ({ ...prev, description: text }))}
                placeholder="وصف اختياري للمنطقة"
                multiline
                numberOfLines={3}
              />
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>مقدم الخريطة</Text>
              <View style={styles.providerSelector}>
                {mapProviders.map(provider => (
                  <TouchableOpacity
                    key={provider.id}
                    style={[
                      styles.providerOption,
                      newRegion.providerId === provider.id && styles.selectedProvider
                    ]}
                    onPress={() => setNewRegion(prev => ({ ...prev, providerId: provider.id }))}
                  >
                    <Text style={[
                      styles.providerText,
                      newRegion.providerId === provider.id && styles.selectedProviderText
                    ]}>
                      {provider.name}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>

            <View style={styles.coordinatesGroup}>
              <Text style={styles.inputLabel}>الحدود الجغرافية</Text>
              
              <View style={styles.coordinateRow}>
                <View style={styles.coordinateInput}>
                  <Text style={styles.coordinateLabel}>الشمال</Text>
                  <TextInput
                    style={styles.numberInput}
                    value={newRegion.north.toString()}
                    onChangeText={(text) => setNewRegion(prev => ({ ...prev, north: parseFloat(text) || 0 }))}
                    keyboardType="numeric"
                  />
                </View>
                <View style={styles.coordinateInput}>
                  <Text style={styles.coordinateLabel}>الجنوب</Text>
                  <TextInput
                    style={styles.numberInput}
                    value={newRegion.south.toString()}
                    onChangeText={(text) => setNewRegion(prev => ({ ...prev, south: parseFloat(text) || 0 }))}
                    keyboardType="numeric"
                  />
                </View>
              </View>

              <View style={styles.coordinateRow}>
                <View style={styles.coordinateInput}>
                  <Text style={styles.coordinateLabel}>الشرق</Text>
                  <TextInput
                    style={styles.numberInput}
                    value={newRegion.east.toString()}
                    onChangeText={(text) => setNewRegion(prev => ({ ...prev, east: parseFloat(text) || 0 }))}
                    keyboardType="numeric"
                  />
                </View>
                <View style={styles.coordinateInput}>
                  <Text style={styles.coordinateLabel}>الغرب</Text>
                  <TextInput
                    style={styles.numberInput}
                    value={newRegion.west.toString()}
                    onChangeText={(text) => setNewRegion(prev => ({ ...prev, west: parseFloat(text) || 0 }))}
                    keyboardType="numeric"
                  />
                </View>
              </View>
            </View>

            <View style={styles.zoomGroup}>
              <Text style={styles.inputLabel}>مستويات التكبير</Text>
              
              <View style={styles.coordinateRow}>
                <View style={styles.coordinateInput}>
                  <Text style={styles.coordinateLabel}>الحد الأدنى</Text>
                  <TextInput
                    style={styles.numberInput}
                    value={newRegion.minZoom.toString()}
                    onChangeText={(text) => setNewRegion(prev => ({ ...prev, minZoom: parseInt(text) || 0 }))}
                    keyboardType="numeric"
                  />
                </View>
                <View style={styles.coordinateInput}>
                  <Text style={styles.coordinateLabel}>الحد الأقصى</Text>
                  <TextInput
                    style={styles.numberInput}
                    value={newRegion.maxZoom.toString()}
                    onChangeText={(text) => setNewRegion(prev => ({ ...prev, maxZoom: parseInt(text) || 0 }))}
                    keyboardType="numeric"
                  />
                </View>
              </View>
            </View>

            <View style={styles.estimateInfo}>
              <Text style={styles.estimateText}>
                التقدير: سيتم تنزيل حوالي {Math.pow(4, newRegion.maxZoom - newRegion.minZoom + 1)} بلاطة
              </Text>
              <Text style={styles.estimateSize}>
                الحجم المتوقع: {formatFileSize(Math.pow(4, newRegion.maxZoom - newRegion.minZoom + 1) * 15000)}
              </Text>
            </View>
          </ScrollView>

          <View style={styles.modalActions}>
            <TouchableOpacity
              style={styles.createButton}
              onPress={createNewRegion}
            >
              <Text style={styles.createButtonText}>إنشاء المنطقة</Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={styles.cancelButton}
              onPress={() => setShowCreateModal(false)}
            >
              <Text style={styles.cancelButtonText}>إلغاء</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );

  /**
   * عرض نافذة إحصائيات التخزين
   */
  const renderStorageModal = () => (
    <Modal
      visible={showStorageModal}
      animationType="slide"
      transparent={true}
      onRequestClose={() => setShowStorageModal(false)}
    >
      <View style={styles.modalOverlay}>
        <View style={styles.storageModal}>
          <Text style={styles.modalTitle}>إحصائيات التخزين</Text>
          
          <View style={styles.storageStats}>
            <View style={styles.statItem}>
              <Text style={styles.statLabel}>إجمالي المناطق:</Text>
              <Text style={styles.statValue}>{storageStats.totalRegions}</Text>
            </View>
            
            <View style={styles.statItem}>
              <Text style={styles.statLabel}>إجمالي البلاطات:</Text>
              <Text style={styles.statValue}>{storageStats.totalTiles.toLocaleString()}</Text>
            </View>
            
            <View style={styles.statItem}>
              <Text style={styles.statLabel}>المساحة المستخدمة:</Text>
              <Text style={styles.statValue}>{formatFileSize(storageStats.totalSize)}</Text>
            </View>
            
            <View style={styles.statItem}>
              <Text style={styles.statLabel}>المساحة المتاحة:</Text>
              <Text style={styles.statValue}>{formatFileSize(storageStats.availableSpace)}</Text>
            </View>
          </View>
          
          <View style={styles.storageActions}>
            <TouchableOpacity
              style={styles.cleanupButton}
              onPress={async () => {
                try {
                  await OfflineMapService.cleanupExpiredTiles();
                  await loadData();
                  Alert.alert('تم التنظيف', 'تم تنظيف البلاطات المنتهية الصلاحية');
                } catch (error) {
                  Alert.alert('خطأ', 'فشل في تنظيف البلاطات');
                }
              }}
            >
              <Text style={styles.cleanupButtonText}>تنظيف البلاطات المنتهية</Text>
            </TouchableOpacity>
          </View>
          
          <TouchableOpacity
            style={styles.closeButton}
            onPress={() => setShowStorageModal(false)}
          >
            <Text style={styles.closeButtonText}>إغلاق</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );

  return (
    <View style={styles.container}>
      <ScrollView style={styles.content}>
        {/* قسم الإحصائيات */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>إحصائيات التخزين</Text>
            
            <TouchableOpacity
              style={styles.storageButton}
              onPress={() => setShowStorageModal(true)}
            >
              <Text style={styles.storageButtonText}>التفاصيل</Text>
            </TouchableOpacity>
          </View>
          
          <View style={styles.statsGrid}>
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>{storageStats.totalRegions}</Text>
              <Text style={styles.statLabel}>مناطق</Text>
            </View>
            
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>{Math.round(storageStats.totalTiles / 1000)}K</Text>
              <Text style={styles.statLabel}>بلاطات</Text>
            </View>
            
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>{formatFileSize(storageStats.totalSize)}</Text>
              <Text style={styles.statLabel}>مستخدم</Text>
            </View>
            
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>{formatFileSize(storageStats.availableSpace)}</Text>
              <Text style={styles.statLabel}>متاح</Text>
            </View>
          </View>
        </View>

        {/* قسم المناطق */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>المناطق المحملة ({regions.length})</Text>
            
            <TouchableOpacity
              style={styles.addButton}
              onPress={() => setShowCreateModal(true)}
            >
              <Text style={styles.addButtonText}>+ إضافة</Text>
            </TouchableOpacity>
          </View>
          
          {regions.length === 0 ? (
            <View style={styles.emptyState}>
              <Text style={styles.emptyText}>لا توجد مناطق محملة</Text>
              <Text style={styles.emptyHint}>
                اضغط على "إضافة" لإنشاء منطقة خريطة جديدة للعمل دون اتصال
              </Text>
            </View>
          ) : (
            <FlatList
              data={regions}
              keyExtractor={(item) => item.id}
              renderItem={({ item }) => (
                <View style={styles.regionCard}>
                  <View style={styles.regionHeader}>
                    <Text style={styles.regionName}>{item.name}</Text>
                    <View style={[styles.statusBadge, { backgroundColor: getStatusColor(item.status) }]}>
                      <Text style={styles.statusText}>{getStatusText(item.status)}</Text>
                    </View>
                  </View>
                  
                  {item.description && (
                    <Text style={styles.regionDescription}>{item.description}</Text>
                  )}
                  
                  <View style={styles.regionStats}>
                    <Text style={styles.regionStat}>
                      البلاطات: {item.downloadedTiles.toLocaleString()} / {item.tileCount.toLocaleString()}
                    </Text>
                    <Text style={styles.regionStat}>
                      الحجم: {formatFileSize(item.downloadedSize)} / {formatFileSize(item.totalSize)}
                    </Text>
                    <Text style={styles.regionStat}>
                      التكبير: {item.minZoom} - {item.maxZoom}
                    </Text>
                  </View>
                  
                  {/* شريط التقدم */}
                  <View style={styles.progressContainer}>
                    <View style={styles.progressBar}>
                      <View 
                        style={[
                          styles.progressFill,
                          { width: `${getProgressPercentage(item)}%` }
                        ]} 
                      />
                    </View>
                    <Text style={styles.progressText}>
                      {getProgressPercentage(item).toFixed(1)}%
                    </Text>
                  </View>
                  
                  <View style={styles.regionActions}>
                    {item.status === 'pending' && (
                      <TouchableOpacity
                        style={styles.downloadButton}
                        onPress={() => startDownload(item.id)}
                      >
                        <Text style={styles.downloadButtonText}>بدء التنزيل</Text>
                      </TouchableOpacity>
                    )}
                    
                    {item.status === 'downloading' && (
                      <TouchableOpacity
                        style={styles.pauseButton}
                        onPress={() => pauseDownload(item.id)}
                      >
                        <Text style={styles.pauseButtonText}>إيقاف</Text>
                      </TouchableOpacity>
                    )}
                    
                    {item.status === 'paused' && (
                      <TouchableOpacity
                        style={styles.resumeButton}
                        onPress={() => resumeDownload(item.id)}
                      >
                        <Text style={styles.resumeButtonText}>استئناف</Text>
                      </TouchableOpacity>
                    )}
                    
                    <TouchableOpacity
                      style={styles.deleteButton}
                      onPress={() => deleteRegion(item)}
                    >
                      <Text style={styles.deleteButtonText}>حذف</Text>
                    </TouchableOpacity>
                  </View>
                  
                  <Text style={styles.regionDate}>
                    تم الإنشاء: {formatDate(item.createdAt)}
                  </Text>
                </View>
              )}
              scrollEnabled={false}
            />
          )}
        </View>

        {/* معلومات إضافية */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>معلومات الخرائط غير المتصلة</Text>
          
          <Text style={styles.infoText}>
            تتيح لك الخرائط غير المتصلة العمل في المناطق التي لا يتوفر فيها اتصال بالإنترنت:
          </Text>
          
          <View style={styles.featuresList}>
            <Text style={styles.featureItem}>• تنزيل خرائط مناطق محددة مسبقاً</Text>
            <Text style={styles.featureItem}>• دعم مقدمي خرائط متعددين</Text>
            <Text style={styles.featureItem">• تحكم في مستويات التكبير والجودة</Text>
            <Text style={styles.featureItem">• إدارة ذكية للتخزين والمساحة</Text>
            <Text style={styles.featureItem">• تنزيل متوازي وسريع</Text>
          </View>
          
          <Text style={styles.infoText}>
            يُنصح بتنزيل الخرائط عند توفر اتصال Wi-Fi سريع لتوفير بيانات الهاتف المحمول.
          </Text>
        </View>
      </ScrollView>

      {renderCreateModal()}
      {renderStorageModal()}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  content: {
    flex: 1,
  },
  section: {
    backgroundColor: '#FFFFFF',
    margin: 16,
    borderRadius: 12,
    padding: 16,
    elevation: 2,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#212121',
  },
  storageButton: {
    backgroundColor: '#2196F3',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 6,
  },
  storageButtonText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: 'bold',
  },
  addButton: {
    backgroundColor: '#4CAF50',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 6,
  },
  addButtonText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: 'bold',
  },
  statsGrid: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  statCard: {
    alignItems: 'center',
    flex: 1,
    padding: 8,
  },
  statNumber: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#2196F3',
  },
  statLabel: {
    fontSize: 12,
    color: '#757575',
    marginTop: 4,
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 32,
  },
  emptyText: {
    fontSize: 16,
    color: '#757575',
    textAlign: 'center',
    marginBottom: 8,
  },
  emptyHint: {
    fontSize: 14,
    color: '#9E9E9E',
    textAlign: 'center',
  },
  regionCard: {
    backgroundColor: '#f8f9fa',
    padding: 16,
    borderRadius: 8,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#E0E0E0',
  },
  regionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  regionName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#212121',
    flex: 1,
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 4,
  },
  statusText: {
    color: '#FFFFFF',
    fontSize: 10,
    fontWeight: 'bold',
  },
  regionDescription: {
    fontSize: 14,
    color: '#424242',
    marginBottom: 8,
  },
  regionStats: {
    marginBottom: 12,
  },
  regionStat: {
    fontSize: 12,
    color: '#757575',
    marginBottom: 2,
  },
  progressContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  progressBar: {
    flex: 1,
    height: 6,
    backgroundColor: '#E0E0E0',
    borderRadius: 3,
    marginRight: 8,
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#4CAF50',
    borderRadius: 3,
  },
  progressText: {
    fontSize: 10,
    color: '#757575',
    fontWeight: 'bold',
  },
  regionActions: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 8,
  },
  downloadButton: {
    backgroundColor: '#4CAF50',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 4,
  },
  downloadButtonText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: 'bold',
  },
  pauseButton: {
    backgroundColor: '#FF9800',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 4,
  },
  pauseButtonText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: 'bold',
  },
  resumeButton: {
    backgroundColor: '#2196F3',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 4,
  },
  resumeButtonText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: 'bold',
  },
  deleteButton: {
    backgroundColor: '#F44336',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 4,
  },
  deleteButtonText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: 'bold',
  },
  regionDate: {
    fontSize: 10,
    color: '#9E9E9E',
  },
  infoText: {
    fontSize: 14,
    color: '#424242',
    lineHeight: 20,
    marginBottom: 12,
  },
  featuresList: {
    marginVertical: 8,
  },
  featureItem: {
    fontSize: 14,
    color: '#424242',
    marginBottom: 4,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  createModal: {
    backgroundColor: '#FFFFFF',
    width: '90%',
    maxHeight: '90%',
    borderRadius: 12,
    padding: 20,
  },
  storageModal: {
    backgroundColor: '#FFFFFF',
    width: '90%',
    borderRadius: 12,
    padding: 20,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#212121',
    textAlign: 'center',
    marginBottom: 16,
  },
  createForm: {
    maxHeight: 400,
  },
  inputGroup: {
    marginBottom: 16,
  },
  inputLabel: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#212121',
    marginBottom: 8,
  },
  textInput: {
    borderWidth: 1,
    borderColor: '#E0E0E0',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 8,
    fontSize: 16,
  },
  textArea: {
    height: 80,
    textAlignVertical: 'top',
  },
  providerSelector: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  providerOption: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderWidth: 1,
    borderColor: '#E0E0E0',
    borderRadius: 6,
    backgroundColor: '#f8f9fa',
  },
  selectedProvider: {
    backgroundColor: '#2196F3',
    borderColor: '#2196F3',
  },
  providerText: {
    fontSize: 14,
    color: '#424242',
  },
  selectedProviderText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
  },
  coordinatesGroup: {
    marginBottom: 16,
  },
  coordinateRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 12,
    marginBottom: 8,
  },
  coordinateInput: {
    flex: 1,
  },
  coordinateLabel: {
    fontSize: 12,
    color: '#757575',
    marginBottom: 4,
  },
  numberInput: {
    borderWidth: 1,
    borderColor: '#E0E0E0',
    borderRadius: 6,
    paddingHorizontal: 8,
    paddingVertical: 6,
    fontSize: 14,
    textAlign: 'center',
  },
  zoomGroup: {
    marginBottom: 16,
  },
  estimateInfo: {
    backgroundColor: '#E3F2FD',
    padding: 12,
    borderRadius: 8,
    marginBottom: 16,
  },
  estimateText: {
    fontSize: 12,
    color: '#1976D2',
    marginBottom: 4,
  },
  estimateSize: {
    fontSize: 12,
    color: '#1976D2',
    fontWeight: 'bold',
  },
  modalActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 16,
  },
  createButton: {
    flex: 1,
    backgroundColor: '#4CAF50',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
    marginRight: 8,
  },
  createButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  cancelButton: {
    flex: 1,
    backgroundColor: '#757575',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
    marginLeft: 8,
  },
  cancelButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  storageStats: {
    marginBottom: 20,
  },
  statItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },
  statValue: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#2196F3',
  },
  storageActions: {
    marginBottom: 16,
  },
  cleanupButton: {
    backgroundColor: '#FF9800',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  cleanupButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  closeButton: {
    backgroundColor: '#2196F3',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  closeButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default OfflineMapScreen;

