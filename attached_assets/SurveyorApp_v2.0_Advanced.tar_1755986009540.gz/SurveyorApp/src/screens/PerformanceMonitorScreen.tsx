import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Alert,
  Switch,
  RefreshControl,
} from 'react-native';
import PerformanceOptimizationService, {
  PerformanceMetrics,
  OptimizationSettings,
} from '../services/PerformanceOptimizationService';

interface PerformanceMonitorScreenProps {
  onNavigate?: (screen: string) => void;
}

const PerformanceMonitorScreen: React.FC<PerformanceMonitorScreenProps> = ({ onNavigate }) => {
  const [currentMetrics, setCurrentMetrics] = useState<PerformanceMetrics | null>(null);
  const [settings, setSettings] = useState<OptimizationSettings | null>(null);
  const [recommendations, setRecommendations] = useState<string[]>([]);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadData();
    
    // تحديث البيانات كل 30 ثانية
    const interval = setInterval(loadData, 30000);
    
    return () => clearInterval(interval);
  }, []);

  /**
   * تحميل البيانات
   */
  const loadData = async () => {
    try {
      const [metrics, currentSettings, recs] = await Promise.all([
        PerformanceOptimizationService.getCurrentMetrics(),
        Promise.resolve(PerformanceOptimizationService.getSettings()),
        Promise.resolve(PerformanceOptimizationService.getOptimizationRecommendations()),
      ]);
      
      setCurrentMetrics(metrics);
      setSettings(currentSettings);
      setRecommendations(recs);
    } catch (error) {
      Alert.alert('خطأ', 'فشل في تحميل بيانات الأداء');
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  };

  /**
   * تحديث الإعدادات
   */
  const updateSettings = async (newSettings: Partial<OptimizationSettings>) => {
    try {
      await PerformanceOptimizationService.updateSettings(newSettings);
      setSettings(prev => prev ? { ...prev, ...newSettings } : null);
      Alert.alert('تم التحديث', 'تم تحديث إعدادات الأداء بنجاح');
    } catch (error) {
      Alert.alert('خطأ', 'فشل في تحديث الإعدادات');
    }
  };

  /**
   * إعادة تعيين المقاييس
   */
  const resetMetrics = () => {
    Alert.alert(
      'تأكيد إعادة التعيين',
      'هل أنت متأكد من إعادة تعيين جميع مقاييس الأداء؟',
      [
        { text: 'إلغاء', style: 'cancel' },
        {
          text: 'إعادة تعيين',
          style: 'destructive',
          onPress: async () => {
            try {
              await PerformanceOptimizationService.resetMetrics();
              await loadData();
              Alert.alert('تم إعادة التعيين', 'تم إعادة تعيين مقاييس الأداء بنجاح');
            } catch (error) {
              Alert.alert('خطأ', 'فشل في إعادة تعيين المقاييس');
            }
          },
        },
      ]
    );
  };

  /**
   * تصدير تقرير الأداء
   */
  const exportReport = () => {
    try {
      const report = PerformanceOptimizationService.exportPerformanceReport();
      
      // في التطبيق الحقيقي، يمكن حفظ التقرير أو مشاركته
      Alert.alert(
        'تقرير الأداء',
        'تم إنشاء تقرير الأداء بنجاح',
        [
          { text: 'موافق' },
          {
            text: 'عرض التفاصيل',
            onPress: () => {
              // عرض التقرير في نافذة منفصلة
              console.log('تقرير الأداء:', report);
            },
          },
        ]
      );
    } catch (error) {
      Alert.alert('خطأ', 'فشل في تصدير تقرير الأداء');
    }
  };

  /**
   * تنسيق حجم الذاكرة
   */
  const formatMemorySize = (sizeInMB: number): string => {
    if (sizeInMB >= 1024) {
      return `${(sizeInMB / 1024).toFixed(1)} GB`;
    }
    return `${sizeInMB.toFixed(0)} MB`;
  };

  /**
   * تنسيق النسبة المئوية
   */
  const formatPercentage = (percentage: number): string => {
    return `${percentage.toFixed(1)}%`;
  };

  /**
   * الحصول على لون الحالة
   */
  const getStatusColor = (percentage: number): string => {
    if (percentage >= 80) return '#F44336'; // أحمر
    if (percentage >= 60) return '#FF9800'; // برتقالي
    return '#4CAF50'; // أخضر
  };

  /**
   * الحصول على لون البطارية
   */
  const getBatteryColor = (level: number): string => {
    if (level <= 0.2) return '#F44336'; // أحمر
    if (level <= 0.5) return '#FF9800'; // برتقالي
    return '#4CAF50'; // أخضر
  };

  /**
   * عرض شريط التقدم
   */
  const renderProgressBar = (percentage: number, color: string) => (
    <View style={styles.progressBarContainer}>
      <View style={styles.progressBarBackground}>
        <View 
          style={[
            styles.progressBarFill,
            { width: `${Math.min(percentage, 100)}%`, backgroundColor: color }
          ]} 
        />
      </View>
      <Text style={styles.progressBarText}>{formatPercentage(percentage)}</Text>
    </View>
  );

  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <Text style={styles.loadingText}>جاري تحميل بيانات الأداء...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <ScrollView 
        style={styles.content}
        refreshControl={
          <RefreshControl
            refreshing={isRefreshing}
            onRefresh={() => {
              setIsRefreshing(true);
              loadData();
            }}
          />
        }
      >
        {/* قسم الذاكرة */}
        {currentMetrics && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>استخدام الذاكرة</Text>
            
            <View style={styles.metricCard}>
              <View style={styles.metricRow}>
                <Text style={styles.metricLabel}>المستخدمة:</Text>
                <Text style={styles.metricValue}>
                  {formatMemorySize(currentMetrics.memoryUsage.used)}
                </Text>
              </View>
              
              <View style={styles.metricRow}>
                <Text style={styles.metricLabel}>المتاحة:</Text>
                <Text style={styles.metricValue}>
                  {formatMemorySize(currentMetrics.memoryUsage.available)}
                </Text>
              </View>
              
              <View style={styles.metricRow}>
                <Text style={styles.metricLabel}>الإجمالية:</Text>
                <Text style={styles.metricValue}>
                  {formatMemorySize(currentMetrics.memoryUsage.total)}
                </Text>
              </View>
              
              {renderProgressBar(
                currentMetrics.memoryUsage.percentage,
                getStatusColor(currentMetrics.memoryUsage.percentage)
              )}
              
              {currentMetrics.memoryUsage.jsHeapSizeUsed && (
                <View style={styles.subMetric}>
                  <Text style={styles.subMetricLabel}>
                    ذاكرة JavaScript: {formatMemorySize(currentMetrics.memoryUsage.jsHeapSizeUsed)}
                  </Text>
                </View>
              )}
            </View>
          </View>
        )}

        {/* قسم البطارية */}
        {currentMetrics && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>معلومات البطارية</Text>
            
            <View style={styles.metricCard}>
              <View style={styles.metricRow}>
                <Text style={styles.metricLabel}>المستوى:</Text>
                <Text style={[
                  styles.metricValue,
                  { color: getBatteryColor(currentMetrics.batteryInfo.level) }
                ]}>
                  {formatPercentage(currentMetrics.batteryInfo.level * 100)}
                </Text>
              </View>
              
              <View style={styles.metricRow}>
                <Text style={styles.metricLabel}>الحالة:</Text>
                <Text style={styles.metricValue}>
                  {currentMetrics.batteryInfo.isCharging ? 'يشحن' : 'لا يشحن'}
                </Text>
              </View>
              
              {renderProgressBar(
                currentMetrics.batteryInfo.level * 100,
                getBatteryColor(currentMetrics.batteryInfo.level)
              )}
            </View>
          </View>
        )}

        {/* قسم الشبكة */}
        {currentMetrics && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>معلومات الشبكة</Text>
            
            <View style={styles.metricCard}>
              <View style={styles.metricRow}>
                <Text style={styles.metricLabel}>الحالة:</Text>
                <Text style={[
                  styles.metricValue,
                  { color: currentMetrics.networkInfo.isConnected ? '#4CAF50' : '#F44336' }
                ]}>
                  {currentMetrics.networkInfo.isConnected ? 'متصل' : 'غير متصل'}
                </Text>
              </View>
              
              <View style={styles.metricRow}>
                <Text style={styles.metricLabel}>النوع:</Text>
                <Text style={styles.metricValue}>
                  {currentMetrics.networkInfo.type === 'wifi' ? 'واي فاي' : 
                   currentMetrics.networkInfo.type === 'cellular' ? 'شبكة خلوية' : 'غير معروف'}
                </Text>
              </View>
              
              {currentMetrics.networkInfo.speed && (
                <View style={styles.metricRow}>
                  <Text style={styles.metricLabel}>السرعة:</Text>
                  <Text style={styles.metricValue}>
                    {currentMetrics.networkInfo.speed.toFixed(1)} Mbps
                  </Text>
                </View>
              )}
              
              {currentMetrics.networkInfo.strength && (
                <>
                  <Text style={styles.subMetricLabel}>قوة الإشارة:</Text>
                  {renderProgressBar(
                    currentMetrics.networkInfo.strength,
                    getStatusColor(100 - currentMetrics.networkInfo.strength)
                  )}
                </>
              )}
            </View>
          </View>
        )}

        {/* قسم التخزين */}
        {currentMetrics && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>معلومات التخزين</Text>
            
            <View style={styles.metricCard}>
              <View style={styles.metricRow}>
                <Text style={styles.metricLabel}>المستخدمة:</Text>
                <Text style={styles.metricValue}>
                  {formatMemorySize(currentMetrics.storageInfo.used)}
                </Text>
              </View>
              
              <View style={styles.metricRow}>
                <Text style={styles.metricLabel}>المتاحة:</Text>
                <Text style={styles.metricValue}>
                  {formatMemorySize(currentMetrics.storageInfo.available)}
                </Text>
              </View>
              
              <View style={styles.metricRow}>
                <Text style={styles.metricLabel}>الإجمالية:</Text>
                <Text style={styles.metricValue}>
                  {formatMemorySize(currentMetrics.storageInfo.total)}
                </Text>
              </View>
              
              {renderProgressBar(
                currentMetrics.storageInfo.percentage,
                getStatusColor(currentMetrics.storageInfo.percentage)
              )}
              
              <View style={styles.subMetricsContainer}>
                <View style={styles.subMetric}>
                  <Text style={styles.subMetricLabel}>
                    ذاكرة التخزين المؤقت: {formatMemorySize(currentMetrics.storageInfo.cacheSize)}
                  </Text>
                </View>
                
                <View style={styles.subMetric}>
                  <Text style={styles.subMetricLabel}>
                    الملفات المؤقتة: {formatMemorySize(currentMetrics.storageInfo.tempSize)}
                  </Text>
                </View>
              </View>
            </View>
          </View>
        )}

        {/* قسم أداء التطبيق */}
        {currentMetrics && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>أداء التطبيق</Text>
            
            <View style={styles.metricCard}>
              <View style={styles.metricRow}>
                <Text style={styles.metricLabel}>معدل الإطارات:</Text>
                <Text style={[
                  styles.metricValue,
                  { color: currentMetrics.appPerformance.averageFrameRate >= 30 ? '#4CAF50' : '#F44336' }
                ]}>
                  {currentMetrics.appPerformance.averageFrameRate.toFixed(1)} fps
                </Text>
              </View>
              
              <View style={styles.metricRow}>
                <Text style={styles.metricLabel}>وقت التشغيل:</Text>
                <Text style={styles.metricValue}>
                  {Math.round(currentMetrics.appPerformance.uptime)} دقيقة
                </Text>
              </View>
              
              <View style={styles.metricRow}>
                <Text style={styles.metricLabel}>وقت الخلفية:</Text>
                <Text style={styles.metricValue}>
                  {Math.round(currentMetrics.appPerformance.backgroundTime)} دقيقة
                </Text>
              </View>
              
              <View style={styles.metricRow}>
                <Text style={styles.metricLabel}>عدد الأخطاء:</Text>
                <Text style={[
                  styles.metricValue,
                  { color: currentMetrics.appPerformance.errorCount > 0 ? '#F44336' : '#4CAF50' }
                ]}>
                  {currentMetrics.appPerformance.errorCount}
                </Text>
              </View>
              
              {currentMetrics.appPerformance.memoryLeaks.length > 0 && (
                <View style={styles.warningContainer}>
                  <Text style={styles.warningText}>
                    ⚠️ تم اكتشاف {currentMetrics.appPerformance.memoryLeaks.length} تسريب في الذاكرة
                  </Text>
                </View>
              )}
            </View>
          </View>
        )}

        {/* قسم التوصيات */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>توصيات التحسين</Text>
          
          <View style={styles.recommendationsContainer}>
            {recommendations.map((recommendation, index) => (
              <View key={index} style={styles.recommendationItem}>
                <Text style={styles.recommendationText}>• {recommendation}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* قسم الإعدادات */}
        {settings && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>إعدادات التحسين</Text>
            
            <View style={styles.settingsContainer}>
              <View style={styles.settingItem}>
                <Text style={styles.settingLabel}>مراقبة الأداء</Text>
                <Switch
                  value={settings.enablePerformanceMonitoring}
                  onValueChange={(value) => 
                    updateSettings({ enablePerformanceMonitoring: value })
                  }
                />
              </View>
              
              <View style={styles.settingItem}>
                <Text style={styles.settingLabel}>التنظيف التلقائي</Text>
                <Switch
                  value={settings.enableAutoCleanup}
                  onValueChange={(value) => 
                    updateSettings({ enableAutoCleanup: value })
                  }
                />
              </View>
              
              <View style={styles.settingItem}>
                <Text style={styles.settingLabel}>تحسين البطارية</Text>
                <Switch
                  value={settings.enableBatteryOptimization}
                  onValueChange={(value) => 
                    updateSettings({ enableBatteryOptimization: value })
                  }
                />
              </View>
              
              <View style={styles.settingItem}>
                <Text style={styles.settingLabel}>تحسين الذاكرة</Text>
                <Switch
                  value={settings.enableMemoryOptimization}
                  onValueChange={(value) => 
                    updateSettings({ enableMemoryOptimization: value })
                  }
                />
              </View>
              
              <View style={styles.settingItem}>
                <Text style={styles.settingLabel}>المزامنة في الخلفية</Text>
                <Switch
                  value={settings.enableBackgroundSync}
                  onValueChange={(value) => 
                    updateSettings({ enableBackgroundSync: value })
                  }
                />
              </View>
            </View>
          </View>
        )}

        {/* قسم الإجراءات */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>إجراءات الصيانة</Text>
          
          <View style={styles.actionsContainer}>
            <TouchableOpacity
              style={styles.actionButton}
              onPress={exportReport}
            >
              <Text style={styles.actionButtonText}>تصدير تقرير الأداء</Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={[styles.actionButton, styles.warningButton]}
              onPress={resetMetrics}
            >
              <Text style={[styles.actionButtonText, styles.warningButtonText]}>
                إعادة تعيين المقاييس
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    fontSize: 16,
    color: '#757575',
  },
  content: {
    flex: 1,
  },
  section: {
    backgroundColor: '#FFFFFF',
    margin: 16,
    borderRadius: 12,
    padding: 16,
    elevation: 2,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#212121',
    marginBottom: 16,
  },
  metricCard: {
    backgroundColor: '#f8f9fa',
    padding: 16,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#E0E0E0',
  },
  metricRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  metricLabel: {
    fontSize: 14,
    color: '#424242',
    fontWeight: 'bold',
  },
  metricValue: {
    fontSize: 14,
    color: '#212121',
    fontWeight: 'bold',
  },
  progressBarContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 12,
  },
  progressBarBackground: {
    flex: 1,
    height: 8,
    backgroundColor: '#E0E0E0',
    borderRadius: 4,
    marginRight: 8,
  },
  progressBarFill: {
    height: '100%',
    borderRadius: 4,
  },
  progressBarText: {
    fontSize: 12,
    color: '#757575',
    fontWeight: 'bold',
    minWidth: 40,
    textAlign: 'right',
  },
  subMetricsContainer: {
    marginTop: 12,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#E0E0E0',
  },
  subMetric: {
    marginBottom: 4,
  },
  subMetricLabel: {
    fontSize: 12,
    color: '#757575',
    marginBottom: 4,
  },
  warningContainer: {
    backgroundColor: '#FFF3E0',
    padding: 8,
    borderRadius: 4,
    marginTop: 8,
    borderLeftWidth: 4,
    borderLeftColor: '#FF9800',
  },
  warningText: {
    fontSize: 12,
    color: '#E65100',
    fontWeight: 'bold',
  },
  recommendationsContainer: {
    gap: 8,
  },
  recommendationItem: {
    backgroundColor: '#E3F2FD',
    padding: 12,
    borderRadius: 8,
    borderLeftWidth: 4,
    borderLeftColor: '#2196F3',
  },
  recommendationText: {
    fontSize: 14,
    color: '#1976D2',
    lineHeight: 20,
  },
  settingsContainer: {
    gap: 16,
  },
  settingItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 4,
  },
  settingLabel: {
    fontSize: 14,
    color: '#212121',
    fontWeight: 'bold',
  },
  actionsContainer: {
    gap: 12,
  },
  actionButton: {
    backgroundColor: '#2196F3',
    paddingVertical: 14,
    paddingHorizontal: 16,
    borderRadius: 8,
    alignItems: 'center',
  },
  warningButton: {
    backgroundColor: '#F44336',
  },
  actionButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: 'bold',
  },
  warningButtonText: {
    color: '#FFFFFF',
  },
});

export default PerformanceMonitorScreen;

