import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Alert,
  Switch,
  I18nManager,
} from 'react-native';
import { useTranslation } from 'react-i18next';
import LocalizationService from '../services/LocalizationService';

interface LanguageSettingsScreenProps {
  onNavigate?: (screen: string) => void;
  onLanguageChange?: (language: string) => void;
}

interface LanguageOption {
  code: string;
  name: string;
  nativeName: string;
  flag: string;
  isRTL: boolean;
}

const LanguageSettingsScreen: React.FC<LanguageSettingsScreenProps> = ({ 
  onNavigate, 
  onLanguageChange 
}) => {
  const { t, i18n } = useTranslation();
  const [currentLanguage, setCurrentLanguage] = useState<string>('ar');
  const [isRTL, setIsRTL] = useState<boolean>(true);
  const [isChanging, setIsChanging] = useState<boolean>(false);
  const [deviceInfo, setDeviceInfo] = useState<any>(null);

  // اللغات المدعومة مع معلومات إضافية
  const supportedLanguages: LanguageOption[] = [
    {
      code: 'ar',
      name: 'Arabic',
      nativeName: 'العربية',
      flag: '🇸🇦',
      isRTL: true,
    },
    {
      code: 'en',
      name: 'English',
      nativeName: 'English',
      flag: '🇺🇸',
      isRTL: false,
    },
  ];

  useEffect(() => {
    loadCurrentSettings();
    loadDeviceInfo();
  }, []);

  /**
   * تحميل الإعدادات الحالية
   */
  const loadCurrentSettings = () => {
    const language = LocalizationService.getCurrentLanguage();
    const rtl = LocalizationService.isRightToLeft();
    
    setCurrentLanguage(language);
    setIsRTL(rtl);
  };

  /**
   * تحميل معلومات الجهاز
   */
  const loadDeviceInfo = () => {
    try {
      const info = LocalizationService.getDeviceLocaleInfo();
      setDeviceInfo(info);
    } catch (error) {
      console.error('خطأ في تحميل معلومات الجهاز:', error);
    }
  };

  /**
   * تغيير اللغة
   */
  const changeLanguage = async (languageCode: string) => {
    if (languageCode === currentLanguage) return;

    setIsChanging(true);

    try {
      const success = await LocalizationService.changeLanguage(languageCode);
      
      if (success) {
        const newIsRTL = languageCode === 'ar';
        
        setCurrentLanguage(languageCode);
        setIsRTL(newIsRTL);

        // إشعار المكون الأب بتغيير اللغة
        if (onLanguageChange) {
          onLanguageChange(languageCode);
        }

        // تحديث اتجاه التطبيق إذا لزم الأمر
        if (I18nManager.isRTL !== newIsRTL) {
          Alert.alert(
            t('dialogs.confirmReset'),
            t('messages.info.restartRequired'),
            [
              {
                text: t('buttons.cancel'),
                style: 'cancel',
              },
              {
                text: t('buttons.confirm'),
                onPress: () => {
                  I18nManager.allowRTL(newIsRTL);
                  I18nManager.forceRTL(newIsRTL);
                  // في التطبيق الحقيقي، يجب إعادة تشغيل التطبيق
                  Alert.alert(
                    t('messages.success.updateSuccess'),
                    t('messages.info.restartApp')
                  );
                },
              },
            ]
          );
        } else {
          Alert.alert(
            t('messages.success.updateSuccess'),
            t('messages.success.languageChanged')
          );
        }
      } else {
        Alert.alert(
          t('messages.error.updateFailed'),
          t('messages.error.languageChangeFailed')
        );
      }
    } catch (error) {
      console.error('خطأ في تغيير اللغة:', error);
      Alert.alert(
        t('messages.error.updateFailed'),
        t('messages.error.languageChangeFailed')
      );
    } finally {
      setIsChanging(false);
    }
  };

  /**
   * إعادة تعيين إعدادات اللغة
   */
  const resetLanguageSettings = () => {
    Alert.alert(
      t('dialogs.confirmReset'),
      t('messages.warning.resetLanguageSettings'),
      [
        {
          text: t('buttons.cancel'),
          style: 'cancel',
        },
        {
          text: t('buttons.confirm'),
          style: 'destructive',
          onPress: async () => {
            try {
              await changeLanguage('ar'); // العودة للعربية كلغة افتراضية
              Alert.alert(
                t('messages.success.updateSuccess'),
                t('messages.success.settingsReset')
              );
            } catch (error) {
              Alert.alert(
                t('messages.error.updateFailed'),
                t('messages.error.resetFailed')
              );
            }
          },
        },
      ]
    );
  };

  /**
   * اختبار الترجمات
   */
  const testTranslations = () => {
    const testKeys = [
      'navigation.dashboard',
      'buttons.save',
      'forms.name',
      'status.completed',
      'messages.success.saveSuccess',
    ];

    const results = testKeys.map(key => ({
      key,
      translation: LocalizationService.translate(key),
      exists: LocalizationService.hasTranslation(key),
    }));

    const message = results
      .map(result => `${result.key}: ${result.exists ? '✓' : '✗'} "${result.translation}"`)
      .join('\n');

    Alert.alert(t('settings.testTranslations'), message);
  };

  /**
   * عرض معلومات الجهاز
   */
  const showDeviceInfo = () => {
    if (!deviceInfo) return;

    const info = [
      `${t('settings.language')}: ${deviceInfo.locales?.[0]?.languageCode || 'N/A'}`,
      `${t('settings.country')}: ${deviceInfo.country || 'N/A'}`,
      `${t('settings.timeZone')}: ${deviceInfo.timeZone || 'N/A'}`,
      `${t('settings.uses24Hour')}: ${deviceInfo.uses24HourClock ? t('common.yes') : t('common.no')}`,
      `${t('settings.usesMetric')}: ${deviceInfo.usesMetricSystem ? t('common.yes') : t('common.no')}`,
      `${t('settings.currencies')}: ${deviceInfo.currencies?.join(', ') || 'N/A'}`,
    ].join('\n');

    Alert.alert(t('settings.deviceInfo'), info);
  };

  /**
   * تنسيق أمثلة النصوص
   */
  const formatExamples = () => {
    const now = new Date();
    const number = 1234.56;
    const currency = 999.99;

    return {
      date: LocalizationService.formatDate(now),
      time: LocalizationService.formatTime(now),
      number: LocalizationService.formatNumber(number),
      currency: LocalizationService.formatCurrency(currency),
    };
  };

  const examples = formatExamples();

  return (
    <View style={[styles.container, isRTL && styles.rtlContainer]}>
      <ScrollView style={styles.content}>
        {/* قسم اختيار اللغة */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, isRTL && styles.rtlText]}>
            {t('settings.language')}
          </Text>
          
          {supportedLanguages.map((language) => (
            <TouchableOpacity
              key={language.code}
              style={[
                styles.languageOption,
                currentLanguage === language.code && styles.selectedLanguage,
                isRTL && styles.rtlLanguageOption,
              ]}
              onPress={() => changeLanguage(language.code)}
              disabled={isChanging}
            >
              <View style={[styles.languageInfo, isRTL && styles.rtlLanguageInfo]}>
                <Text style={styles.languageFlag}>{language.flag}</Text>
                <View style={styles.languageText}>
                  <Text style={[
                    styles.languageName,
                    currentLanguage === language.code && styles.selectedLanguageText,
                    isRTL && styles.rtlText,
                  ]}>
                    {language.nativeName}
                  </Text>
                  <Text style={[
                    styles.languageSubtext,
                    isRTL && styles.rtlText,
                  ]}>
                    {language.name} • {language.isRTL ? 'RTL' : 'LTR'}
                  </Text>
                </View>
              </View>
              
              {currentLanguage === language.code && (
                <View style={styles.selectedIndicator}>
                  <Text style={styles.checkmark}>✓</Text>
                </View>
              )}
            </TouchableOpacity>
          ))}
        </View>

        {/* قسم معلومات اللغة الحالية */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, isRTL && styles.rtlText]}>
            {t('settings.currentLanguage')}
          </Text>
          
          <View style={styles.infoCard}>
            <View style={styles.infoRow}>
              <Text style={[styles.infoLabel, isRTL && styles.rtlText]}>
                {t('forms.language')}:
              </Text>
              <Text style={[styles.infoValue, isRTL && styles.rtlText]}>
                {LocalizationService.getLanguageName(currentLanguage)}
              </Text>
            </View>
            
            <View style={styles.infoRow}>
              <Text style={[styles.infoLabel, isRTL && styles.rtlText]}>
                {t('settings.textDirection')}:
              </Text>
              <Text style={[styles.infoValue, isRTL && styles.rtlText]}>
                {isRTL ? 'من اليمين إلى اليسار (RTL)' : 'من اليسار إلى اليمين (LTR)'}
              </Text>
            </View>
          </View>
        </View>

        {/* قسم أمثلة التنسيق */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, isRTL && styles.rtlText]}>
            {t('settings.formatExamples')}
          </Text>
          
          <View style={styles.examplesCard}>
            <View style={styles.exampleRow}>
              <Text style={[styles.exampleLabel, isRTL && styles.rtlText]}>
                {t('forms.date')}:
              </Text>
              <Text style={[styles.exampleValue, isRTL && styles.rtlText]}>
                {examples.date}
              </Text>
            </View>
            
            <View style={styles.exampleRow}>
              <Text style={[styles.exampleLabel, isRTL && styles.rtlText]}>
                {t('forms.time')}:
              </Text>
              <Text style={[styles.exampleValue, isRTL && styles.rtlText]}>
                {examples.time}
              </Text>
            </View>
            
            <View style={styles.exampleRow}>
              <Text style={[styles.exampleLabel, isRTL && styles.rtlText]}>
                {t('settings.number')}:
              </Text>
              <Text style={[styles.exampleValue, isRTL && styles.rtlText]}>
                {examples.number}
              </Text>
            </View>
            
            <View style={styles.exampleRow}>
              <Text style={[styles.exampleLabel, isRTL && styles.rtlText]}>
                {t('settings.currency')}:
              </Text>
              <Text style={[styles.exampleValue, isRTL && styles.rtlText]}>
                {examples.currency}
              </Text>
            </View>
          </View>
        </View>

        {/* قسم الأدوات */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, isRTL && styles.rtlText]}>
            {t('settings.tools')}
          </Text>
          
          <TouchableOpacity
            style={styles.toolButton}
            onPress={testTranslations}
          >
            <Text style={[styles.toolButtonText, isRTL && styles.rtlText]}>
              {t('settings.testTranslations')}
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={styles.toolButton}
            onPress={showDeviceInfo}
          >
            <Text style={[styles.toolButtonText, isRTL && styles.rtlText]}>
              {t('settings.deviceInfo')}
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[styles.toolButton, styles.resetButton]}
            onPress={resetLanguageSettings}
          >
            <Text style={[styles.toolButtonText, styles.resetButtonText, isRTL && styles.rtlText]}>
              {t('settings.resetLanguage')}
            </Text>
          </TouchableOpacity>
        </View>

        {/* قسم معلومات إضافية */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, isRTL && styles.rtlText]}>
            {t('settings.additionalInfo')}
          </Text>
          
          <Text style={[styles.infoText, isRTL && styles.rtlText]}>
            {t('settings.languageDescription')}
          </Text>
          
          <View style={styles.featuresList}>
            <Text style={[styles.featureItem, isRTL && styles.rtlText]}>
              • {t('settings.feature1')}
            </Text>
            <Text style={[styles.featureItem, isRTL && styles.rtlText]}>
              • {t('settings.feature2')}
            </Text>
            <Text style={[styles.featureItem, isRTL && styles.rtlText]}>
              • {t('settings.feature3')}
            </Text>
            <Text style={[styles.featureItem, isRTL && styles.rtlText]}>
              • {t('settings.feature4')}
            </Text>
          </View>
        </View>
      </ScrollView>

      {/* شريط الحالة */}
      {isChanging && (
        <View style={styles.statusBar}>
          <Text style={[styles.statusText, isRTL && styles.rtlText]}>
            {t('messages.info.changingLanguage')}...
          </Text>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  rtlContainer: {
    direction: 'rtl',
  },
  content: {
    flex: 1,
  },
  section: {
    backgroundColor: '#FFFFFF',
    margin: 16,
    borderRadius: 12,
    padding: 16,
    elevation: 2,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#212121',
    marginBottom: 16,
  },
  rtlText: {
    textAlign: 'right',
    writingDirection: 'rtl',
  },
  languageOption: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 16,
    paddingHorizontal: 12,
    borderRadius: 8,
    marginBottom: 8,
    backgroundColor: '#f8f9fa',
    borderWidth: 2,
    borderColor: 'transparent',
  },
  rtlLanguageOption: {
    flexDirection: 'row-reverse',
  },
  selectedLanguage: {
    backgroundColor: '#E3F2FD',
    borderColor: '#2196F3',
  },
  languageInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  rtlLanguageInfo: {
    flexDirection: 'row-reverse',
  },
  languageFlag: {
    fontSize: 24,
    marginRight: 12,
  },
  languageText: {
    flex: 1,
  },
  languageName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#212121',
    marginBottom: 2,
  },
  selectedLanguageText: {
    color: '#1976D2',
  },
  languageSubtext: {
    fontSize: 12,
    color: '#757575',
  },
  selectedIndicator: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: '#4CAF50',
    alignItems: 'center',
    justifyContent: 'center',
  },
  checkmark: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: 'bold',
  },
  infoCard: {
    backgroundColor: '#f8f9fa',
    padding: 16,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#E0E0E0',
  },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  infoLabel: {
    fontSize: 14,
    color: '#424242',
    fontWeight: 'bold',
  },
  infoValue: {
    fontSize: 14,
    color: '#212121',
    flex: 1,
    textAlign: 'right',
  },
  examplesCard: {
    backgroundColor: '#f8f9fa',
    padding: 16,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#E0E0E0',
  },
  exampleRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  exampleLabel: {
    fontSize: 14,
    color: '#424242',
    fontWeight: 'bold',
  },
  exampleValue: {
    fontSize: 14,
    color: '#2196F3',
    fontWeight: 'bold',
    flex: 1,
    textAlign: 'right',
  },
  toolButton: {
    backgroundColor: '#2196F3',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
    marginBottom: 8,
    alignItems: 'center',
  },
  resetButton: {
    backgroundColor: '#F44336',
  },
  toolButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: 'bold',
  },
  resetButtonText: {
    color: '#FFFFFF',
  },
  infoText: {
    fontSize: 14,
    color: '#424242',
    lineHeight: 20,
    marginBottom: 12,
  },
  featuresList: {
    marginTop: 8,
  },
  featureItem: {
    fontSize: 14,
    color: '#424242',
    marginBottom: 4,
  },
  statusBar: {
    backgroundColor: '#2196F3',
    paddingVertical: 8,
    paddingHorizontal: 16,
    alignItems: 'center',
  },
  statusText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: 'bold',
  },
});

export default LanguageSettingsScreen;

