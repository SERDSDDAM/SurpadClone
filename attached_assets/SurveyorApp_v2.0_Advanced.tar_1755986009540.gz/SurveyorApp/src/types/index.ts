/**
 * الأنواع المشتركة للتطبيق
 * Shared Types for the App
 */

export type Screen = 'login' | 'dashboard' | 'surveys' | 'map' | 'settings';

export interface User {
  id: string;
  username: string;
  fullName: string;
  role: 'surveyor' | 'inspector' | 'citizen' | 'admin';
  email?: string;
  phone?: string;
}

export interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  message?: string;
  error?: string;
}

export interface Location {
  latitude: number;
  longitude: number;
  accuracy?: number;
  timestamp?: number;
}

export interface SurveyRequest {
  id: string;
  title: string;
  description: string;
  status: 'pending' | 'assigned' | 'in_progress' | 'completed' | 'cancelled';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  location: Location;
  createdAt: Date;
  updatedAt: Date;
  assignedTo?: string;
  notes?: string;
}

export interface NavigationProps {
  onNavigate: (screen: Screen) => void;
}

export interface AuthProps {
  onLogin?: (username: string, password: string, role: string) => void;
  onLogout?: () => void;
  isLoading?: boolean;
}

export interface UserProps {
  user: User | null;
}

// أنواع الخرائط
export interface MapPoint {
  id: string;
  name: string;
  location: Location;
  type: 'survey_point' | 'boundary' | 'building' | 'reference';
  status: 'active' | 'completed' | 'pending';
}

export interface MapBoundary {
  id: string;
  name: string;
  points: Location[];
  area?: number;
  perimeter?: number;
}

// أنواع المزامنة
export interface SyncStatus {
  isOnline: boolean;
  isSyncing: boolean;
  lastSyncTime: Date | null;
  pendingUploads: number;
  pendingDownloads: number;
  syncErrors: string[];
}

// أنواع جمع البيانات
export interface SurveyData {
  id: string;
  projectId: string;
  type: 'point' | 'measurement' | 'photo' | 'note';
  data: any;
  location?: Location;
  timestamp: Date;
  synced: boolean;
}

export interface Project {
  id: string;
  name: string;
  description: string;
  status: 'active' | 'completed' | 'paused';
  createdAt: Date;
  updatedAt: Date;
  location: string;
  surveyData: SurveyData[];
}

