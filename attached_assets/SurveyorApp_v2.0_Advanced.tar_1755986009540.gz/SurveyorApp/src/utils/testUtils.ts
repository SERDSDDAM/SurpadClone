/**
 * أدوات الاختبار والمحاكاة
 * Testing and Mock Utilities
 */

import { User, SurveyRequest, Location, MapPoint } from '../types';

// بيانات وهمية للاختبار
export const mockUsers: User[] = [
  {
    id: '1',
    username: 'surveyor1',
    fullName: 'أحمد المساح',
    role: 'surveyor',
    email: 'surveyor@binaa.gov.ye',
    phone: '+967-1-234567',
  },
  {
    id: '2',
    username: 'inspector1',
    fullName: 'محمد المفتش',
    role: 'inspector',
    email: 'inspector@binaa.gov.ye',
    phone: '+967-1-234568',
  },
  {
    id: '3',
    username: 'citizen1',
    fullName: 'علي المواطن',
    role: 'citizen',
    email: 'citizen@example.com',
    phone: '+967-1-234569',
  },
];

// مواقع وهمية في صنعاء
export const mockLocations: Location[] = [
  { latitude: 15.3694, longitude: 44.1910, accuracy: 5, timestamp: Date.now() }, // صنعاء القديمة
  { latitude: 15.3547, longitude: 44.2066, accuracy: 3, timestamp: Date.now() }, // جامعة صنعاء
  { latitude: 15.3729, longitude: 44.1947, accuracy: 4, timestamp: Date.now() }, // السبعين
  { latitude: 15.3441, longitude: 44.2187, accuracy: 6, timestamp: Date.now() }, // الحصبة
];

// طلبات مسح وهمية
export const mockSurveyRequests: SurveyRequest[] = [
  {
    id: '1',
    title: 'مسح أرض سكنية - حي السبعين',
    description: 'مطلوب مسح قطعة أرض سكنية بمساحة 400 متر مربع',
    status: 'assigned',
    priority: 'high',
    location: mockLocations[2],
    createdAt: new Date('2024-01-15'),
    updatedAt: new Date('2024-01-16'),
    assignedTo: '1',
    notes: 'الأرض محاطة بسور من ثلاث جهات',
  },
  {
    id: '2',
    title: 'مسح حدود مبنى تجاري',
    description: 'تحديد حدود مبنى تجاري في منطقة الحصبة',
    status: 'in_progress',
    priority: 'medium',
    location: mockLocations[3],
    createdAt: new Date('2024-01-14'),
    updatedAt: new Date('2024-01-17'),
    assignedTo: '1',
  },
  {
    id: '3',
    title: 'مسح أرض زراعية',
    description: 'مسح قطعة أرض زراعية خارج المدينة',
    status: 'pending',
    priority: 'low',
    location: mockLocations[0],
    createdAt: new Date('2024-01-18'),
    updatedAt: new Date('2024-01-18'),
  },
];

// نقاط خريطة وهمية
export const mockMapPoints: MapPoint[] = [
  {
    id: '1',
    name: 'نقطة مرجعية 1',
    location: mockLocations[0],
    type: 'reference',
    status: 'completed',
  },
  {
    id: '2',
    name: 'زاوية شمالية شرقية',
    location: mockLocations[1],
    type: 'boundary',
    status: 'active',
  },
  {
    id: '3',
    name: 'مبنى رئيسي',
    location: mockLocations[2],
    type: 'building',
    status: 'completed',
  },
];

// دوال مساعدة للاختبار
export const delay = (ms: number): Promise<void> => {
  return new Promise(resolve => setTimeout(resolve, ms));
};

export const mockApiCall = async <T>(data: T, delayMs: number = 1000): Promise<T> => {
  await delay(delayMs);
  return data;
};

export const mockApiError = async (message: string, delayMs: number = 1000): Promise<never> => {
  await delay(delayMs);
  throw new Error(message);
};

// محاكاة تسجيل الدخول
export const mockLogin = async (username: string, password: string): Promise<User> => {
  await delay(1500);
  
  const user = mockUsers.find(u => u.username === username);
  if (!user || password.length < 3) {
    throw new Error('اسم المستخدم أو كلمة المرور غير صحيحة');
  }
  
  return user;
};

// محاكاة جلب طلبات المسح
export const mockGetSurveyRequests = async (userId?: string): Promise<SurveyRequest[]> => {
  await delay(800);
  
  if (userId) {
    return mockSurveyRequests.filter(req => req.assignedTo === userId);
  }
  
  return mockSurveyRequests;
};

// محاكاة الحصول على الموقع الحالي
export const mockGetCurrentLocation = async (): Promise<Location> => {
  await delay(2000);
  
  // محاكاة خطأ GPS أحياناً
  if (Math.random() < 0.1) {
    throw new Error('لا يمكن تحديد الموقع الحالي');
  }
  
  return {
    latitude: 15.3694 + (Math.random() - 0.5) * 0.01,
    longitude: 44.1910 + (Math.random() - 0.5) * 0.01,
    accuracy: Math.random() * 10 + 2,
    timestamp: Date.now(),
  };
};

// محاكاة حفظ البيانات محلياً
export const mockSaveData = async (key: string, data: any): Promise<void> => {
  await delay(200);
  console.log(`حفظ البيانات: ${key}`, data);
};

// محاكاة جلب البيانات محلياً
export const mockLoadData = async <T>(key: string, defaultValue: T): Promise<T> => {
  await delay(200);
  console.log(`جلب البيانات: ${key}`);
  return defaultValue;
};

// إحصائيات وهمية
export const mockStats = {
  totalRequests: 25,
  completedRequests: 18,
  pendingRequests: 7,
  todayRequests: 3,
  thisWeekRequests: 12,
  accuracy: 95.5,
  avgResponseTime: '2.3 ساعة',
};

// رسائل الاختبار
export const testMessages = {
  loginSuccess: 'تم تسجيل الدخول بنجاح',
  loginError: 'فشل في تسجيل الدخول',
  locationError: 'لا يمكن تحديد الموقع',
  syncSuccess: 'تمت المزامنة بنجاح',
  syncError: 'فشلت المزامنة',
  saveSuccess: 'تم الحفظ بنجاح',
  saveError: 'فشل في الحفظ',
};

export default {
  mockUsers,
  mockLocations,
  mockSurveyRequests,
  mockMapPoints,
  mockStats,
  testMessages,
  delay,
  mockApiCall,
  mockApiError,
  mockLogin,
  mockGetSurveyRequests,
  mockGetCurrentLocation,
  mockSaveData,
  mockLoadData,
};

