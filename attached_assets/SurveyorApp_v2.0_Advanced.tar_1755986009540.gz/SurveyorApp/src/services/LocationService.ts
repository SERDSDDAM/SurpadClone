/**
 * خدمة الموقع والGPS
 * Location and GPS Service
 */

import Geolocation from '@react-native-community/geolocation';
import { PermissionsAndroid, Platform, Alert } from 'react-native';

export interface LocationCoordinates {
  latitude: number;
  longitude: number;
  accuracy: number;
  altitude?: number;
  heading?: number;
  speed?: number;
  timestamp: number;
}

export interface SurveyPoint {
  id: string;
  name: string;
  coordinates: LocationCoordinates;
  type: 'boundary' | 'corner' | 'reference' | 'building';
  notes?: string;
  photos?: string[];
  createdAt: Date;
  updatedAt: Date;
}

class LocationService {
  private watchId: number | null = null;
  private isTracking: boolean = false;
  private currentLocation: LocationCoordinates | null = null;
  private locationCallbacks: ((location: LocationCoordinates) => void)[] = [];

  /**
   * طلب صلاحيات الموقع
   */
  async requestLocationPermission(): Promise<boolean> {
    try {
      if (Platform.OS === 'android') {
        const granted = await PermissionsAndroid.request(
          PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
          {
            title: 'صلاحية الوصول للموقع',
            message: 'يحتاج التطبيق للوصول لموقعك لتحديد النقاط المساحية بدقة',
            buttonNeutral: 'اسأل لاحقاً',
            buttonNegative: 'إلغاء',
            buttonPositive: 'موافق',
          }
        );
        return granted === PermissionsAndroid.RESULTS.GRANTED;
      }
      return true; // iOS يتم التعامل معه تلقائياً
    } catch (err) {
      console.warn('خطأ في طلب صلاحية الموقع:', err);
      return false;
    }
  }

  /**
   * الحصول على الموقع الحالي
   */
  async getCurrentLocation(): Promise<LocationCoordinates> {
    return new Promise((resolve, reject) => {
      const hasPermission = this.requestLocationPermission();
      if (!hasPermission) {
        reject(new Error('لا توجد صلاحية للوصول للموقع'));
        return;
      }

      Geolocation.getCurrentPosition(
        (position) => {
          const location: LocationCoordinates = {
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
            accuracy: position.coords.accuracy,
            altitude: position.coords.altitude || undefined,
            heading: position.coords.heading || undefined,
            speed: position.coords.speed || undefined,
            timestamp: position.timestamp,
          };
          
          this.currentLocation = location;
          resolve(location);
        },
        (error) => {
          console.error('خطأ في الحصول على الموقع:', error);
          reject(new Error(`فشل في تحديد الموقع: ${error.message}`));
        },
        {
          enableHighAccuracy: true,
          timeout: 15000,
          maximumAge: 10000,
        }
      );
    });
  }

  /**
   * بدء تتبع الموقع
   */
  async startLocationTracking(callback: (location: LocationCoordinates) => void): Promise<void> {
    const hasPermission = await this.requestLocationPermission();
    if (!hasPermission) {
      throw new Error('لا توجد صلاحية للوصول للموقع');
    }

    if (this.isTracking) {
      this.stopLocationTracking();
    }

    this.locationCallbacks.push(callback);
    this.isTracking = true;

    this.watchId = Geolocation.watchPosition(
      (position) => {
        const location: LocationCoordinates = {
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          accuracy: position.coords.accuracy,
          altitude: position.coords.altitude || undefined,
          heading: position.coords.heading || undefined,
          speed: position.coords.speed || undefined,
          timestamp: position.timestamp,
        };

        this.currentLocation = location;
        this.locationCallbacks.forEach(cb => cb(location));
      },
      (error) => {
        console.error('خطأ في تتبع الموقع:', error);
        Alert.alert('خطأ', `فشل في تتبع الموقع: ${error.message}`);
      },
      {
        enableHighAccuracy: true,
        distanceFilter: 1, // متر واحد
        interval: 1000, // ثانية واحدة
        fastestInterval: 500, // نصف ثانية
      }
    );
  }

  /**
   * إيقاف تتبع الموقع
   */
  stopLocationTracking(): void {
    if (this.watchId !== null) {
      Geolocation.clearWatch(this.watchId);
      this.watchId = null;
    }
    this.isTracking = false;
    this.locationCallbacks = [];
  }

  /**
   * الحصول على الموقع الحالي المحفوظ
   */
  getCurrentLocationCache(): LocationCoordinates | null {
    return this.currentLocation;
  }

  /**
   * حساب المسافة بين نقطتين (بالمتر)
   */
  calculateDistance(
    point1: { latitude: number; longitude: number },
    point2: { latitude: number; longitude: number }
  ): number {
    const R = 6371e3; // نصف قطر الأرض بالمتر
    const φ1 = (point1.latitude * Math.PI) / 180;
    const φ2 = (point2.latitude * Math.PI) / 180;
    const Δφ = ((point2.latitude - point1.latitude) * Math.PI) / 180;
    const Δλ = ((point2.longitude - point1.longitude) * Math.PI) / 180;

    const a =
      Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
      Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

    return R * c;
  }

  /**
   * حساب المساحة لمضلع من النقاط
   */
  calculatePolygonArea(points: { latitude: number; longitude: number }[]): number {
    if (points.length < 3) return 0;

    let area = 0;
    const n = points.length;

    for (let i = 0; i < n; i++) {
      const j = (i + 1) % n;
      const xi = points[i].longitude;
      const yi = points[i].latitude;
      const xj = points[j].longitude;
      const yj = points[j].latitude;
      area += xi * yj - xj * yi;
    }

    area = Math.abs(area) / 2;
    
    // تحويل من درجات إلى متر مربع (تقريبي)
    const metersPerDegree = 111320; // متر لكل درجة عند خط الاستواء
    return area * metersPerDegree * metersPerDegree;
  }

  /**
   * تحويل الإحداثيات إلى عنوان (Reverse Geocoding)
   */
  async reverseGeocode(latitude: number, longitude: number): Promise<string> {
    try {
      // في التطبيق الحقيقي، يمكن استخدام خدمة مثل Google Maps API
      // هنا نعيد إحداثيات مبسطة
      return `${latitude.toFixed(6)}, ${longitude.toFixed(6)}`;
    } catch (error) {
      console.error('خطأ في تحويل الإحداثيات:', error);
      return `${latitude.toFixed(6)}, ${longitude.toFixed(6)}`;
    }
  }

  /**
   * التحقق من دقة الموقع
   */
  isLocationAccurate(location: LocationCoordinates, requiredAccuracy: number = 5): boolean {
    return location.accuracy <= requiredAccuracy;
  }

  /**
   * الحصول على معلومات حالة GPS
   */
  getGPSStatus(): {
    isTracking: boolean;
    hasLocation: boolean;
    accuracy: number | null;
    lastUpdate: number | null;
  } {
    return {
      isTracking: this.isTracking,
      hasLocation: this.currentLocation !== null,
      accuracy: this.currentLocation?.accuracy || null,
      lastUpdate: this.currentLocation?.timestamp || null,
    };
  }

  /**
   * تنسيق الإحداثيات للعرض
   */
  formatCoordinates(location: LocationCoordinates): {
    latitude: string;
    longitude: string;
    dms: { latitude: string; longitude: string };
  } {
    const formatDMS = (decimal: number, isLatitude: boolean): string => {
      const absolute = Math.abs(decimal);
      const degrees = Math.floor(absolute);
      const minutes = Math.floor((absolute - degrees) * 60);
      const seconds = ((absolute - degrees - minutes / 60) * 3600).toFixed(2);
      
      const direction = isLatitude 
        ? (decimal >= 0 ? 'شمال' : 'جنوب')
        : (decimal >= 0 ? 'شرق' : 'غرب');
      
      return `${degrees}° ${minutes}' ${seconds}" ${direction}`;
    };

    return {
      latitude: location.latitude.toFixed(6),
      longitude: location.longitude.toFixed(6),
      dms: {
        latitude: formatDMS(location.latitude, true),
        longitude: formatDMS(location.longitude, false),
      },
    };
  }
}

export default new LocationService();

