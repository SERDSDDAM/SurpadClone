import AsyncStorage from '@react-native-async-storage/async-storage';
import { Alert, AppState, AppStateStatus } from 'react-native';

export interface PerformanceMetrics {
  memoryUsage: MemoryUsage;
  batteryInfo: BatteryInfo;
  networkInfo: NetworkInfo;
  storageInfo: StorageInfo;
  appPerformance: AppPerformance;
  timestamp: Date;
}

export interface MemoryUsage {
  used: number; // MB
  available: number; // MB
  total: number; // MB
  percentage: number; // 0-100
  jsHeapSizeUsed?: number; // MB
  jsHeapSizeTotal?: number; // MB
}

export interface BatteryInfo {
  level: number; // 0-1
  isCharging: boolean;
  chargingTime?: number; // minutes
  dischargingTime?: number; // minutes
  status: 'unknown' | 'charging' | 'discharging' | 'not_charging' | 'full';
}

export interface NetworkInfo {
  isConnected: boolean;
  type: 'none' | 'wifi' | 'cellular' | 'unknown';
  isInternetReachable: boolean;
  strength?: number; // 0-100
  speed?: number; // Mbps
}

export interface StorageInfo {
  used: number; // MB
  available: number; // MB
  total: number; // MB
  percentage: number; // 0-100
  cacheSize: number; // MB
  tempSize: number; // MB
}

export interface AppPerformance {
  startupTime: number; // ms
  averageFrameRate: number; // fps
  memoryLeaks: MemoryLeak[];
  crashCount: number;
  errorCount: number;
  lastCrashTime?: Date;
  uptime: number; // minutes
  backgroundTime: number; // minutes
}

export interface MemoryLeak {
  component: string;
  size: number; // MB
  timestamp: Date;
  stackTrace?: string;
}

export interface OptimizationSettings {
  enableAutoCleanup: boolean;
  cleanupInterval: number; // minutes
  maxCacheSize: number; // MB
  maxTempSize: number; // MB
  enableBatteryOptimization: boolean;
  enableMemoryOptimization: boolean;
  enableNetworkOptimization: boolean;
  enableBackgroundSync: boolean;
  maxBackgroundTasks: number;
  enablePerformanceMonitoring: boolean;
  monitoringInterval: number; // seconds
}

export interface OptimizationAction {
  type: 'cleanup_cache' | 'cleanup_temp' | 'reduce_quality' | 'pause_sync' | 'close_connections' | 'garbage_collect';
  description: string;
  impact: 'low' | 'medium' | 'high';
  executed: boolean;
  timestamp?: Date;
  result?: string;
}

class PerformanceOptimizationService {
  private static instance: PerformanceOptimizationService;
  private metrics: PerformanceMetrics[] = [];
  private settings: OptimizationSettings;
  private monitoringInterval?: NodeJS.Timeout;
  private cleanupInterval?: NodeJS.Timeout;
  private appStartTime: Date;
  private appState: AppStateStatus = 'active';
  private backgroundStartTime?: Date;
  private totalBackgroundTime: number = 0;
  private frameRateHistory: number[] = [];
  private memoryLeaks: MemoryLeak[] = [];
  private crashCount: number = 0;
  private errorCount: number = 0;
  private lastCrashTime?: Date;

  constructor() {
    this.appStartTime = new Date();
    this.settings = this.getDefaultSettings();
    this.initializeService();
  }

  static getInstance(): PerformanceOptimizationService {
    if (!PerformanceOptimizationService.instance) {
      PerformanceOptimizationService.instance = new PerformanceOptimizationService();
    }
    return PerformanceOptimizationService.instance;
  }

  /**
   * تهيئة خدمة تحسين الأداء
   */
  private async initializeService(): Promise<void> {
    try {
      await this.loadSettings();
      await this.loadMetricsHistory();
      
      this.setupAppStateListener();
      this.setupErrorHandling();
      
      if (this.settings.enablePerformanceMonitoring) {
        this.startPerformanceMonitoring();
      }
      
      if (this.settings.enableAutoCleanup) {
        this.startAutoCleanup();
      }
      
      console.log('تم تهيئة خدمة تحسين الأداء');
    } catch (error) {
      console.error('خطأ في تهيئة خدمة تحسين الأداء:', error);
    }
  }

  /**
   * الحصول على الإعدادات الافتراضية
   */
  private getDefaultSettings(): OptimizationSettings {
    return {
      enableAutoCleanup: true,
      cleanupInterval: 30, // 30 minutes
      maxCacheSize: 100, // 100 MB
      maxTempSize: 50, // 50 MB
      enableBatteryOptimization: true,
      enableMemoryOptimization: true,
      enableNetworkOptimization: true,
      enableBackgroundSync: true,
      maxBackgroundTasks: 3,
      enablePerformanceMonitoring: true,
      monitoringInterval: 30, // 30 seconds
    };
  }

  /**
   * تحميل الإعدادات المحفوظة
   */
  private async loadSettings(): Promise<void> {
    try {
      const savedSettings = await AsyncStorage.getItem('performance_settings');
      if (savedSettings) {
        this.settings = { ...this.settings, ...JSON.parse(savedSettings) };
      }
    } catch (error) {
      console.error('خطأ في تحميل إعدادات الأداء:', error);
    }
  }

  /**
   * حفظ الإعدادات
   */
  private async saveSettings(): Promise<void> {
    try {
      await AsyncStorage.setItem('performance_settings', JSON.stringify(this.settings));
    } catch (error) {
      console.error('خطأ في حفظ إعدادات الأداء:', error);
    }
  }

  /**
   * تحميل تاريخ المقاييس
   */
  private async loadMetricsHistory(): Promise<void> {
    try {
      const savedMetrics = await AsyncStorage.getItem('performance_metrics');
      if (savedMetrics) {
        const parsedMetrics = JSON.parse(savedMetrics);
        this.metrics = parsedMetrics.map((metric: any) => ({
          ...metric,
          timestamp: new Date(metric.timestamp),
        }));
        
        // الاحتفاظ بآخر 100 قياس فقط
        if (this.metrics.length > 100) {
          this.metrics = this.metrics.slice(-100);
        }
      }
    } catch (error) {
      console.error('خطأ في تحميل تاريخ المقاييس:', error);
    }
  }

  /**
   * حفظ المقاييس
   */
  private async saveMetrics(): Promise<void> {
    try {
      await AsyncStorage.setItem('performance_metrics', JSON.stringify(this.metrics));
    } catch (error) {
      console.error('خطأ في حفظ المقاييس:', error);
    }
  }

  /**
   * إعداد مستمع حالة التطبيق
   */
  private setupAppStateListener(): void {
    AppState.addEventListener('change', (nextAppState: AppStateStatus) => {
      if (this.appState === 'active' && nextAppState.match(/inactive|background/)) {
        // التطبيق انتقل إلى الخلفية
        this.backgroundStartTime = new Date();
        this.onAppGoesToBackground();
      } else if (this.appState.match(/inactive|background/) && nextAppState === 'active') {
        // التطبيق عاد إلى المقدمة
        if (this.backgroundStartTime) {
          const backgroundDuration = (new Date().getTime() - this.backgroundStartTime.getTime()) / (1000 * 60);
          this.totalBackgroundTime += backgroundDuration;
        }
        this.onAppComesToForeground();
      }
      
      this.appState = nextAppState;
    });
  }

  /**
   * إعداد معالجة الأخطاء
   */
  private setupErrorHandling(): void {
    // في التطبيق الحقيقي، يمكن استخدام مكتبات مثل react-native-exception-handler
    const originalConsoleError = console.error;
    console.error = (...args) => {
      this.errorCount++;
      originalConsoleError.apply(console, args);
    };
  }

  /**
   * بدء مراقبة الأداء
   */
  private startPerformanceMonitoring(): void {
    if (this.monitoringInterval) {
      clearInterval(this.monitoringInterval);
    }

    this.monitoringInterval = setInterval(async () => {
      try {
        const metrics = await this.collectPerformanceMetrics();
        this.metrics.push(metrics);
        
        // الاحتفاظ بآخر 100 قياس فقط
        if (this.metrics.length > 100) {
          this.metrics = this.metrics.slice(-100);
        }
        
        await this.saveMetrics();
        await this.analyzeAndOptimize(metrics);
      } catch (error) {
        console.error('خطأ في مراقبة الأداء:', error);
      }
    }, this.settings.monitoringInterval * 1000);
  }

  /**
   * إيقاف مراقبة الأداء
   */
  private stopPerformanceMonitoring(): void {
    if (this.monitoringInterval) {
      clearInterval(this.monitoringInterval);
      this.monitoringInterval = undefined;
    }
  }

  /**
   * بدء التنظيف التلقائي
   */
  private startAutoCleanup(): void {
    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval);
    }

    this.cleanupInterval = setInterval(async () => {
      try {
        await this.performAutoCleanup();
      } catch (error) {
        console.error('خطأ في التنظيف التلقائي:', error);
      }
    }, this.settings.cleanupInterval * 60 * 1000);
  }

  /**
   * إيقاف التنظيف التلقائي
   */
  private stopAutoCleanup(): void {
    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval);
      this.cleanupInterval = undefined;
    }
  }

  /**
   * جمع مقاييس الأداء
   */
  private async collectPerformanceMetrics(): Promise<PerformanceMetrics> {
    const memoryUsage = await this.getMemoryUsage();
    const batteryInfo = await this.getBatteryInfo();
    const networkInfo = await this.getNetworkInfo();
    const storageInfo = await this.getStorageInfo();
    const appPerformance = this.getAppPerformance();

    return {
      memoryUsage,
      batteryInfo,
      networkInfo,
      storageInfo,
      appPerformance,
      timestamp: new Date(),
    };
  }

  /**
   * الحصول على معلومات استخدام الذاكرة
   */
  private async getMemoryUsage(): Promise<MemoryUsage> {
    // في التطبيق الحقيقي، يمكن استخدام مكتبات مثل react-native-device-info
    const mockMemoryUsage: MemoryUsage = {
      used: Math.random() * 200 + 100, // 100-300 MB
      available: Math.random() * 1000 + 500, // 500-1500 MB
      total: 2048, // 2 GB
      percentage: 0,
      jsHeapSizeUsed: Math.random() * 50 + 20, // 20-70 MB
      jsHeapSizeTotal: Math.random() * 100 + 50, // 50-150 MB
    };

    mockMemoryUsage.percentage = (mockMemoryUsage.used / mockMemoryUsage.total) * 100;
    return mockMemoryUsage;
  }

  /**
   * الحصول على معلومات البطارية
   */
  private async getBatteryInfo(): Promise<BatteryInfo> {
    // في التطبيق الحقيقي، يمكن استخدام مكتبات مثل react-native-battery
    return {
      level: Math.random() * 0.8 + 0.2, // 20-100%
      isCharging: Math.random() > 0.5,
      status: Math.random() > 0.5 ? 'discharging' : 'charging',
    };
  }

  /**
   * الحصول على معلومات الشبكة
   */
  private async getNetworkInfo(): Promise<NetworkInfo> {
    // في التطبيق الحقيقي، يمكن استخدام مكتبات مثل @react-native-community/netinfo
    return {
      isConnected: Math.random() > 0.1, // 90% connected
      type: Math.random() > 0.5 ? 'wifi' : 'cellular',
      isInternetReachable: Math.random() > 0.05, // 95% reachable
      strength: Math.random() * 100,
      speed: Math.random() * 100 + 10, // 10-110 Mbps
    };
  }

  /**
   * الحصول على معلومات التخزين
   */
  private async getStorageInfo(): Promise<StorageInfo> {
    // في التطبيق الحقيقي، يمكن استخدام مكتبات مثل react-native-fs
    const used = Math.random() * 1000 + 500; // 500-1500 MB
    const total = 8192; // 8 GB
    const available = total - used;

    return {
      used,
      available,
      total,
      percentage: (used / total) * 100,
      cacheSize: Math.random() * 100 + 50, // 50-150 MB
      tempSize: Math.random() * 50 + 10, // 10-60 MB
    };
  }

  /**
   * الحصول على معلومات أداء التطبيق
   */
  private getAppPerformance(): AppPerformance {
    const now = new Date();
    const uptime = (now.getTime() - this.appStartTime.getTime()) / (1000 * 60); // minutes
    
    // محاكاة معدل الإطارات
    const currentFrameRate = Math.random() * 20 + 40; // 40-60 fps
    this.frameRateHistory.push(currentFrameRate);
    if (this.frameRateHistory.length > 10) {
      this.frameRateHistory = this.frameRateHistory.slice(-10);
    }
    
    const averageFrameRate = this.frameRateHistory.reduce((sum, rate) => sum + rate, 0) / this.frameRateHistory.length;

    return {
      startupTime: Math.random() * 2000 + 1000, // 1-3 seconds
      averageFrameRate,
      memoryLeaks: [...this.memoryLeaks],
      crashCount: this.crashCount,
      errorCount: this.errorCount,
      lastCrashTime: this.lastCrashTime,
      uptime,
      backgroundTime: this.totalBackgroundTime,
    };
  }

  /**
   * تحليل وتحسين الأداء
   */
  private async analyzeAndOptimize(metrics: PerformanceMetrics): Promise<void> {
    const actions: OptimizationAction[] = [];

    // فحص استخدام الذاكرة
    if (metrics.memoryUsage.percentage > 80) {
      actions.push({
        type: 'garbage_collect',
        description: 'تنظيف الذاكرة - استخدام عالي للذاكرة',
        impact: 'medium',
        executed: false,
      });
    }

    // فحص مستوى البطارية
    if (metrics.batteryInfo.level < 0.2 && this.settings.enableBatteryOptimization) {
      actions.push({
        type: 'reduce_quality',
        description: 'تقليل جودة العرض - بطارية منخفضة',
        impact: 'high',
        executed: false,
      });
      
      actions.push({
        type: 'pause_sync',
        description: 'إيقاف المزامنة - بطارية منخفضة',
        impact: 'medium',
        executed: false,
      });
    }

    // فحص مساحة التخزين
    if (metrics.storageInfo.cacheSize > this.settings.maxCacheSize) {
      actions.push({
        type: 'cleanup_cache',
        description: 'تنظيف ذاكرة التخزين المؤقت - حجم كبير',
        impact: 'low',
        executed: false,
      });
    }

    if (metrics.storageInfo.tempSize > this.settings.maxTempSize) {
      actions.push({
        type: 'cleanup_temp',
        description: 'تنظيف الملفات المؤقتة - حجم كبير',
        impact: 'low',
        executed: false,
      });
    }

    // فحص الشبكة
    if (!metrics.networkInfo.isConnected && this.settings.enableNetworkOptimization) {
      actions.push({
        type: 'close_connections',
        description: 'إغلاق الاتصالات - لا يوجد إنترنت',
        impact: 'low',
        executed: false,
      });
    }

    // تنفيذ الإجراءات
    for (const action of actions) {
      try {
        await this.executeOptimizationAction(action);
      } catch (error) {
        console.error(`خطأ في تنفيذ إجراء التحسين ${action.type}:`, error);
      }
    }
  }

  /**
   * تنفيذ إجراء التحسين
   */
  private async executeOptimizationAction(action: OptimizationAction): Promise<void> {
    action.timestamp = new Date();
    
    try {
      switch (action.type) {
        case 'cleanup_cache':
          await this.cleanupCache();
          action.result = 'تم تنظيف ذاكرة التخزين المؤقت';
          break;
          
        case 'cleanup_temp':
          await this.cleanupTempFiles();
          action.result = 'تم تنظيف الملفات المؤقتة';
          break;
          
        case 'reduce_quality':
          await this.reduceQuality();
          action.result = 'تم تقليل جودة العرض';
          break;
          
        case 'pause_sync':
          await this.pauseBackgroundSync();
          action.result = 'تم إيقاف المزامنة في الخلفية';
          break;
          
        case 'close_connections':
          await this.closeUnnecessaryConnections();
          action.result = 'تم إغلاق الاتصالات غير الضرورية';
          break;
          
        case 'garbage_collect':
          await this.forceGarbageCollection();
          action.result = 'تم تنظيف الذاكرة';
          break;
      }
      
      action.executed = true;
      console.log(`تم تنفيذ إجراء التحسين: ${action.description}`);
    } catch (error) {
      action.result = `خطأ: ${error.message}`;
      console.error(`فشل في تنفيذ إجراء التحسين ${action.type}:`, error);
    }
  }

  /**
   * تنظيف ذاكرة التخزين المؤقت
   */
  private async cleanupCache(): Promise<void> {
    // في التطبيق الحقيقي، يمكن تنظيف ذاكرة التخزين المؤقت الفعلية
    console.log('تنظيف ذاكرة التخزين المؤقت...');
    
    // محاكاة تنظيف البيانات القديمة
    const oldKeys = await AsyncStorage.getAllKeys();
    const keysToRemove = oldKeys.filter(key => key.startsWith('cache_'));
    
    if (keysToRemove.length > 0) {
      await AsyncStorage.multiRemove(keysToRemove);
    }
  }

  /**
   * تنظيف الملفات المؤقتة
   */
  private async cleanupTempFiles(): Promise<void> {
    // في التطبيق الحقيقي، يمكن حذف الملفات المؤقتة الفعلية
    console.log('تنظيف الملفات المؤقتة...');
  }

  /**
   * تقليل جودة العرض
   */
  private async reduceQuality(): Promise<void> {
    // في التطبيق الحقيقي، يمكن تقليل جودة الصور والرسوم
    console.log('تقليل جودة العرض لتوفير البطارية...');
  }

  /**
   * إيقاف المزامنة في الخلفية
   */
  private async pauseBackgroundSync(): Promise<void> {
    // في التطبيق الحقيقي، يمكن إيقاف المزامنة الفعلية
    console.log('إيقاف المزامنة في الخلفية...');
  }

  /**
   * إغلاق الاتصالات غير الضرورية
   */
  private async closeUnnecessaryConnections(): Promise<void> {
    // في التطبيق الحقيقي، يمكن إغلاق اتصالات WebSocket وغيرها
    console.log('إغلاق الاتصالات غير الضرورية...');
  }

  /**
   * فرض تنظيف الذاكرة
   */
  private async forceGarbageCollection(): Promise<void> {
    // في التطبيق الحقيقي، يمكن استخدام تقنيات تنظيف الذاكرة
    console.log('تنظيف الذاكرة...');
    
    if (global.gc) {
      global.gc();
    }
  }

  /**
   * تنفيذ التنظيف التلقائي
   */
  private async performAutoCleanup(): Promise<void> {
    console.log('تنفيذ التنظيف التلقائي...');
    
    try {
      await this.cleanupCache();
      await this.cleanupTempFiles();
      
      // تنظيف المقاييس القديمة
      const oneWeekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
      this.metrics = this.metrics.filter(metric => metric.timestamp > oneWeekAgo);
      
      await this.saveMetrics();
    } catch (error) {
      console.error('خطأ في التنظيف التلقائي:', error);
    }
  }

  /**
   * معالجة انتقال التطبيق إلى الخلفية
   */
  private onAppGoesToBackground(): void {
    console.log('التطبيق انتقل إلى الخلفية - تحسين الأداء...');
    
    if (this.settings.enableBatteryOptimization) {
      // تقليل تكرار المراقبة
      if (this.monitoringInterval) {
        clearInterval(this.monitoringInterval);
        this.monitoringInterval = setInterval(async () => {
          try {
            const metrics = await this.collectPerformanceMetrics();
            this.metrics.push(metrics);
            await this.analyzeAndOptimize(metrics);
          } catch (error) {
            console.error('خطأ في مراقبة الأداء في الخلفية:', error);
          }
        }, this.settings.monitoringInterval * 3 * 1000); // 3x slower
      }
    }
  }

  /**
   * معالجة عودة التطبيق إلى المقدمة
   */
  private onAppComesToForeground(): void {
    console.log('التطبيق عاد إلى المقدمة - استعادة الأداء الكامل...');
    
    // استعادة تكرار المراقبة العادي
    if (this.settings.enablePerformanceMonitoring) {
      this.startPerformanceMonitoring();
    }
  }

  /**
   * الحصول على المقاييس الحالية
   */
  async getCurrentMetrics(): Promise<PerformanceMetrics> {
    return await this.collectPerformanceMetrics();
  }

  /**
   * الحصول على تاريخ المقاييس
   */
  getMetricsHistory(): PerformanceMetrics[] {
    return [...this.metrics];
  }

  /**
   * الحصول على الإعدادات الحالية
   */
  getSettings(): OptimizationSettings {
    return { ...this.settings };
  }

  /**
   * تحديث الإعدادات
   */
  async updateSettings(newSettings: Partial<OptimizationSettings>): Promise<void> {
    this.settings = { ...this.settings, ...newSettings };
    await this.saveSettings();
    
    // إعادة تشغيل الخدمات حسب الإعدادات الجديدة
    if (this.settings.enablePerformanceMonitoring) {
      this.startPerformanceMonitoring();
    } else {
      this.stopPerformanceMonitoring();
    }
    
    if (this.settings.enableAutoCleanup) {
      this.startAutoCleanup();
    } else {
      this.stopAutoCleanup();
    }
  }

  /**
   * تسجيل تسرب في الذاكرة
   */
  reportMemoryLeak(component: string, size: number, stackTrace?: string): void {
    const leak: MemoryLeak = {
      component,
      size,
      timestamp: new Date(),
      stackTrace,
    };
    
    this.memoryLeaks.push(leak);
    
    // الاحتفاظ بآخر 50 تسريب فقط
    if (this.memoryLeaks.length > 50) {
      this.memoryLeaks = this.memoryLeaks.slice(-50);
    }
    
    console.warn(`تسريب في الذاكرة: ${component} (${size} MB)`);
  }

  /**
   * تسجيل انهيار التطبيق
   */
  reportCrash(error: Error): void {
    this.crashCount++;
    this.lastCrashTime = new Date();
    
    console.error('انهيار التطبيق:', error);
    
    // في التطبيق الحقيقي، يمكن إرسال تقرير الانهيار إلى خدمة التحليلات
  }

  /**
   * الحصول على توصيات التحسين
   */
  getOptimizationRecommendations(): string[] {
    const recommendations: string[] = [];
    
    if (this.metrics.length > 0) {
      const latestMetrics = this.metrics[this.metrics.length - 1];
      
      if (latestMetrics.memoryUsage.percentage > 70) {
        recommendations.push('استخدام الذاكرة مرتفع - فكر في تقليل البيانات المحملة');
      }
      
      if (latestMetrics.batteryInfo.level < 0.3) {
        recommendations.push('البطارية منخفضة - قم بتفعيل وضع توفير الطاقة');
      }
      
      if (latestMetrics.storageInfo.percentage > 80) {
        recommendations.push('مساحة التخزين منخفضة - قم بتنظيف الملفات غير المرغوبة');
      }
      
      if (latestMetrics.appPerformance.averageFrameRate < 30) {
        recommendations.push('أداء الرسوم منخفض - قم بتقليل جودة العرض');
      }
      
      if (!latestMetrics.networkInfo.isConnected) {
        recommendations.push('لا يوجد اتصال بالإنترنت - استخدم الوضع غير المتصل');
      }
    }
    
    if (recommendations.length === 0) {
      recommendations.push('الأداء جيد - لا توجد توصيات حالياً');
    }
    
    return recommendations;
  }

  /**
   * إعادة تعيين المقاييس
   */
  async resetMetrics(): Promise<void> {
    this.metrics = [];
    this.memoryLeaks = [];
    this.crashCount = 0;
    this.errorCount = 0;
    this.lastCrashTime = undefined;
    this.frameRateHistory = [];
    
    await this.saveMetrics();
  }

  /**
   * تصدير تقرير الأداء
   */
  exportPerformanceReport(): string {
    const report = {
      generatedAt: new Date().toISOString(),
      appStartTime: this.appStartTime.toISOString(),
      totalUptime: (new Date().getTime() - this.appStartTime.getTime()) / (1000 * 60), // minutes
      totalBackgroundTime: this.totalBackgroundTime,
      settings: this.settings,
      metricsCount: this.metrics.length,
      latestMetrics: this.metrics.length > 0 ? this.metrics[this.metrics.length - 1] : null,
      memoryLeaks: this.memoryLeaks,
      crashCount: this.crashCount,
      errorCount: this.errorCount,
      lastCrashTime: this.lastCrashTime?.toISOString(),
      recommendations: this.getOptimizationRecommendations(),
    };
    
    return JSON.stringify(report, null, 2);
  }

  /**
   * تنظيف الخدمة
   */
  cleanup(): void {
    this.stopPerformanceMonitoring();
    this.stopAutoCleanup();
    
    // إزالة مستمعي الأحداث
    AppState.removeEventListener('change', () => {});
  }
}

export default PerformanceOptimizationService.getInstance();

