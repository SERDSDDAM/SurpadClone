import io, { Socket } from 'socket.io-client';
import uuid from 'react-native-uuid';
import AsyncStorage from '@react-native-async-storage/async-storage';

export interface CollaborationUser {
  id: string;
  name: string;
  role: 'surveyor' | 'supervisor' | 'admin';
  isOnline: boolean;
  lastSeen: Date;
  currentLocation?: {
    latitude: number;
    longitude: number;
    accuracy: number;
  };
  avatar?: string;
}

export interface CollaborationProject {
  id: string;
  name: string;
  description: string;
  createdBy: string;
  createdAt: Date;
  members: CollaborationUser[];
  isActive: boolean;
}

export interface RealTimeUpdate {
  id: string;
  type: 'point_added' | 'point_updated' | 'point_deleted' | 'user_joined' | 'user_left' | 'location_updated' | 'message_sent';
  projectId: string;
  userId: string;
  timestamp: Date;
  data: any;
}

export interface ChatMessage {
  id: string;
  projectId: string;
  userId: string;
  userName: string;
  message: string;
  timestamp: Date;
  type: 'text' | 'location' | 'image' | 'file';
  metadata?: any;
}

export interface SurveyPointUpdate {
  pointId: string;
  action: 'create' | 'update' | 'delete';
  data: any;
  userId: string;
  timestamp: Date;
}

class CollaborationService {
  private socket: Socket | null = null;
  private currentUser: CollaborationUser | null = null;
  private currentProject: CollaborationProject | null = null;
  private isConnected = false;
  private reconnectAttempts = 0;
  private maxReconnectAttempts = 5;
  private updateListeners: Map<string, (update: RealTimeUpdate) => void> = new Map();
  private messageListeners: Map<string, (message: ChatMessage) => void> = new Map();
  private userListeners: Map<string, (users: CollaborationUser[]) => void> = new Map();

  /**
   * تهيئة خدمة التعاون
   */
  async initialize(serverUrl: string): Promise<boolean> {
    try {
      // تحميل بيانات المستخدم المحفوظة
      await this.loadUserData();

      // إنشاء اتصال WebSocket
      this.socket = io(serverUrl, {
        transports: ['websocket'],
        timeout: 10000,
        reconnection: true,
        reconnectionAttempts: this.maxReconnectAttempts,
        reconnectionDelay: 2000,
      });

      this.setupSocketListeners();
      
      return new Promise((resolve) => {
        this.socket!.on('connect', () => {
          this.isConnected = true;
          this.reconnectAttempts = 0;
          console.log('تم الاتصال بخادم التعاون');
          resolve(true);
        });

        this.socket!.on('connect_error', (error) => {
          console.error('خطأ في الاتصال:', error);
          resolve(false);
        });
      });
    } catch (error) {
      console.error('خطأ في تهيئة خدمة التعاون:', error);
      return false;
    }
  }

  /**
   * إعداد مستمعي أحداث WebSocket
   */
  private setupSocketListeners(): void {
    if (!this.socket) return;

    // حدث الاتصال
    this.socket.on('connect', () => {
      this.isConnected = true;
      this.reconnectAttempts = 0;
      
      // إرسال بيانات المستخدم عند الاتصال
      if (this.currentUser) {
        this.socket!.emit('user_authenticate', {
          userId: this.currentUser.id,
          name: this.currentUser.name,
          role: this.currentUser.role,
        });
      }
    });

    // حدث قطع الاتصال
    this.socket.on('disconnect', (reason) => {
      this.isConnected = false;
      console.log('تم قطع الاتصال:', reason);
    });

    // حدث إعادة الاتصال
    this.socket.on('reconnect', (attemptNumber) => {
      this.isConnected = true;
      this.reconnectAttempts = 0;
      console.log(`تم إعادة الاتصال بعد ${attemptNumber} محاولات`);
    });

    // حدث فشل إعادة الاتصال
    this.socket.on('reconnect_failed', () => {
      console.error('فشل في إعادة الاتصال بعد عدة محاولات');
    });

    // استقبال التحديثات المباشرة
    this.socket.on('real_time_update', (update: RealTimeUpdate) => {
      this.handleRealTimeUpdate(update);
    });

    // استقبال رسائل الدردشة
    this.socket.on('chat_message', (message: ChatMessage) => {
      this.handleChatMessage(message);
    });

    // تحديث قائمة المستخدمين المتصلين
    this.socket.on('users_updated', (users: CollaborationUser[]) => {
      this.handleUsersUpdate(users);
    });

    // استقبال تحديثات نقاط المسح
    this.socket.on('survey_point_update', (update: SurveyPointUpdate) => {
      this.handleSurveyPointUpdate(update);
    });
  }

  /**
   * تحميل بيانات المستخدم المحفوظة
   */
  private async loadUserData(): Promise<void> {
    try {
      const userData = await AsyncStorage.getItem('collaboration_user');
      if (userData) {
        this.currentUser = JSON.parse(userData);
      } else {
        // إنشاء مستخدم جديد
        this.currentUser = {
          id: uuid.v4() as string,
          name: 'مساح جديد',
          role: 'surveyor',
          isOnline: false,
          lastSeen: new Date(),
        };
        await this.saveUserData();
      }
    } catch (error) {
      console.error('خطأ في تحميل بيانات المستخدم:', error);
    }
  }

  /**
   * حفظ بيانات المستخدم
   */
  private async saveUserData(): Promise<void> {
    try {
      if (this.currentUser) {
        await AsyncStorage.setItem('collaboration_user', JSON.stringify(this.currentUser));
      }
    } catch (error) {
      console.error('خطأ في حفظ بيانات المستخدم:', error);
    }
  }

  /**
   * الانضمام إلى مشروع
   */
  async joinProject(projectId: string): Promise<boolean> {
    try {
      if (!this.isConnected || !this.socket || !this.currentUser) {
        throw new Error('غير متصل بالخادم');
      }

      return new Promise((resolve) => {
        this.socket!.emit('join_project', {
          projectId,
          userId: this.currentUser!.id,
        });

        this.socket!.once('project_joined', (response) => {
          if (response.success) {
            this.currentProject = response.project;
            console.log(`تم الانضمام إلى المشروع: ${projectId}`);
            resolve(true);
          } else {
            console.error('فشل في الانضمام إلى المشروع:', response.error);
            resolve(false);
          }
        });
      });
    } catch (error) {
      console.error('خطأ في الانضمام إلى المشروع:', error);
      return false;
    }
  }

  /**
   * مغادرة المشروع
   */
  async leaveProject(): Promise<void> {
    try {
      if (this.socket && this.currentProject && this.currentUser) {
        this.socket.emit('leave_project', {
          projectId: this.currentProject.id,
          userId: this.currentUser.id,
        });
        
        this.currentProject = null;
      }
    } catch (error) {
      console.error('خطأ في مغادرة المشروع:', error);
    }
  }

  /**
   * إرسال تحديث مباشر
   */
  sendRealTimeUpdate(type: string, data: any): void {
    if (!this.isConnected || !this.socket || !this.currentProject || !this.currentUser) {
      console.warn('لا يمكن إرسال التحديث: غير متصل');
      return;
    }

    const update: RealTimeUpdate = {
      id: uuid.v4() as string,
      type: type as any,
      projectId: this.currentProject.id,
      userId: this.currentUser.id,
      timestamp: new Date(),
      data,
    };

    this.socket.emit('send_update', update);
  }

  /**
   * إرسال رسالة دردشة
   */
  sendChatMessage(message: string, type: 'text' | 'location' | 'image' | 'file' = 'text', metadata?: any): void {
    if (!this.isConnected || !this.socket || !this.currentProject || !this.currentUser) {
      console.warn('لا يمكن إرسال الرسالة: غير متصل');
      return;
    }

    const chatMessage: ChatMessage = {
      id: uuid.v4() as string,
      projectId: this.currentProject.id,
      userId: this.currentUser.id,
      userName: this.currentUser.name,
      message,
      timestamp: new Date(),
      type,
      metadata,
    };

    this.socket.emit('send_message', chatMessage);
  }

  /**
   * تحديث موقع المستخدم
   */
  updateUserLocation(latitude: number, longitude: number, accuracy: number): void {
    if (!this.currentUser) return;

    this.currentUser.currentLocation = { latitude, longitude, accuracy };
    this.saveUserData();

    if (this.isConnected && this.socket && this.currentProject) {
      this.socket.emit('update_location', {
        projectId: this.currentProject.id,
        userId: this.currentUser.id,
        location: this.currentUser.currentLocation,
      });
    }
  }

  /**
   * إرسال تحديث نقطة مسح
   */
  sendSurveyPointUpdate(pointId: string, action: 'create' | 'update' | 'delete', data: any): void {
    if (!this.isConnected || !this.socket || !this.currentProject || !this.currentUser) {
      console.warn('لا يمكن إرسال تحديث النقطة: غير متصل');
      return;
    }

    const update: SurveyPointUpdate = {
      pointId,
      action,
      data,
      userId: this.currentUser.id,
      timestamp: new Date(),
    };

    this.socket.emit('survey_point_update', {
      projectId: this.currentProject.id,
      update,
    });
  }

  /**
   * معالجة التحديثات المباشرة
   */
  private handleRealTimeUpdate(update: RealTimeUpdate): void {
    // تجاهل التحديثات من نفس المستخدم
    if (this.currentUser && update.userId === this.currentUser.id) {
      return;
    }

    // إشعار المستمعين
    this.updateListeners.forEach(listener => {
      try {
        listener(update);
      } catch (error) {
        console.error('خطأ في معالجة التحديث:', error);
      }
    });
  }

  /**
   * معالجة رسائل الدردشة
   */
  private handleChatMessage(message: ChatMessage): void {
    // إشعار مستمعي الرسائل
    this.messageListeners.forEach(listener => {
      try {
        listener(message);
      } catch (error) {
        console.error('خطأ في معالجة الرسالة:', error);
      }
    });
  }

  /**
   * معالجة تحديث المستخدمين
   */
  private handleUsersUpdate(users: CollaborationUser[]): void {
    // إشعار مستمعي المستخدمين
    this.userListeners.forEach(listener => {
      try {
        listener(users);
      } catch (error) {
        console.error('خطأ في معالجة تحديث المستخدمين:', error);
      }
    });
  }

  /**
   * معالجة تحديثات نقاط المسح
   */
  private handleSurveyPointUpdate(update: SurveyPointUpdate): void {
    // تجاهل التحديثات من نفس المستخدم
    if (this.currentUser && update.userId === this.currentUser.id) {
      return;
    }

    // إنشاء تحديث مباشر لنقطة المسح
    const realTimeUpdate: RealTimeUpdate = {
      id: uuid.v4() as string,
      type: `point_${update.action}` as any,
      projectId: this.currentProject?.id || '',
      userId: update.userId,
      timestamp: update.timestamp,
      data: {
        pointId: update.pointId,
        pointData: update.data,
      },
    };

    this.handleRealTimeUpdate(realTimeUpdate);
  }

  /**
   * تسجيل مستمع للتحديثات المباشرة
   */
  registerUpdateListener(id: string, listener: (update: RealTimeUpdate) => void): void {
    this.updateListeners.set(id, listener);
  }

  /**
   * إلغاء تسجيل مستمع التحديثات
   */
  unregisterUpdateListener(id: string): void {
    this.updateListeners.delete(id);
  }

  /**
   * تسجيل مستمع للرسائل
   */
  registerMessageListener(id: string, listener: (message: ChatMessage) => void): void {
    this.messageListeners.set(id, listener);
  }

  /**
   * إلغاء تسجيل مستمع الرسائل
   */
  unregisterMessageListener(id: string): void {
    this.messageListeners.delete(id);
  }

  /**
   * تسجيل مستمع للمستخدمين
   */
  registerUserListener(id: string, listener: (users: CollaborationUser[]) => void): void {
    this.userListeners.set(id, listener);
  }

  /**
   * إلغاء تسجيل مستمع المستخدمين
   */
  unregisterUserListener(id: string): void {
    this.userListeners.delete(id);
  }

  /**
   * الحصول على المستخدم الحالي
   */
  getCurrentUser(): CollaborationUser | null {
    return this.currentUser;
  }

  /**
   * الحصول على المشروع الحالي
   */
  getCurrentProject(): CollaborationProject | null {
    return this.currentProject;
  }

  /**
   * التحقق من حالة الاتصال
   */
  isConnectedToServer(): boolean {
    return this.isConnected;
  }

  /**
   * تحديث بيانات المستخدم
   */
  async updateUserProfile(name: string, role: 'surveyor' | 'supervisor' | 'admin'): Promise<void> {
    if (this.currentUser) {
      this.currentUser.name = name;
      this.currentUser.role = role;
      await this.saveUserData();

      // إرسال التحديث إلى الخادم
      if (this.isConnected && this.socket) {
        this.socket.emit('update_profile', {
          userId: this.currentUser.id,
          name,
          role,
        });
      }
    }
  }

  /**
   * قطع الاتصال وتنظيف الموارد
   */
  disconnect(): void {
    if (this.socket) {
      this.socket.disconnect();
      this.socket = null;
    }
    
    this.isConnected = false;
    this.currentProject = null;
    this.updateListeners.clear();
    this.messageListeners.clear();
    this.userListeners.clear();
  }

  /**
   * إعادة الاتصال يدوياً
   */
  reconnect(): void {
    if (this.socket && !this.isConnected) {
      this.socket.connect();
    }
  }
}

export default new CollaborationService();

