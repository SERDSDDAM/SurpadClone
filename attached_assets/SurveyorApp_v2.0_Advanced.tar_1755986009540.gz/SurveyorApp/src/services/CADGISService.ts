import RNFS from 'react-native-fs';
import DocumentPicker from 'react-native-document-picker';
import Share from 'react-native-share';
import { Alert } from 'react-native';

export interface CADPoint {
  id: string;
  x: number;
  y: number;
  z?: number;
  code?: string;
  description?: string;
  layer?: string;
  attributes?: Record<string, any>;
}

export interface CADLine {
  id: string;
  startPoint: CADPoint;
  endPoint: CADPoint;
  layer?: string;
  lineType?: string;
  color?: string;
  attributes?: Record<string, any>;
}

export interface CADPolygon {
  id: string;
  points: CADPoint[];
  layer?: string;
  fillColor?: string;
  borderColor?: string;
  attributes?: Record<string, any>;
}

export interface GISFeature {
  id: string;
  type: 'Point' | 'LineString' | 'Polygon';
  coordinates: number[] | number[][] | number[][][];
  properties: Record<string, any>;
  crs?: string;
}

export interface CADDrawing {
  id: string;
  name: string;
  description?: string;
  units: 'meters' | 'feet' | 'millimeters';
  coordinateSystem?: string;
  points: CADPoint[];
  lines: CADLine[];
  polygons: CADPolygon[];
  layers: string[];
  bounds: {
    minX: number;
    minY: number;
    maxX: number;
    maxY: number;
  };
  metadata: Record<string, any>;
}

export interface GISDataset {
  id: string;
  name: string;
  description?: string;
  crs: string;
  features: GISFeature[];
  bounds: [number, number, number, number]; // [minX, minY, maxX, maxY]
  metadata: Record<string, any>;
}

export interface ExportOptions {
  format: 'DXF' | 'SHP' | 'KML' | 'GeoJSON' | 'CSV';
  coordinateSystem?: string;
  layers?: string[];
  includeAttributes?: boolean;
  precision?: number;
}

export interface ImportResult {
  success: boolean;
  data?: CADDrawing | GISDataset;
  errors?: string[];
  warnings?: string[];
}

class CADGISService {
  private supportedImportFormats = ['.dxf', '.shp', '.kml', '.geojson', '.json', '.csv'];
  private supportedExportFormats = ['DXF', 'SHP', 'KML', 'GeoJSON', 'CSV'];

  /**
   * استيراد ملف CAD/GIS
   */
  async importFile(): Promise<ImportResult> {
    try {
      // فتح منتقي الملفات
      const result = await DocumentPicker.pick({
        type: [
          DocumentPicker.types.allFiles,
        ],
        allowMultiSelection: false,
      });

      const file = result[0];
      const fileExtension = this.getFileExtension(file.name);

      if (!this.supportedImportFormats.includes(fileExtension.toLowerCase())) {
        return {
          success: false,
          errors: [`تنسيق الملف ${fileExtension} غير مدعوم`],
        };
      }

      // قراءة محتوى الملف
      const fileContent = await RNFS.readFile(file.uri, 'utf8');

      // معالجة الملف حسب نوعه
      switch (fileExtension.toLowerCase()) {
        case '.dxf':
          return await this.parseDXF(fileContent, file.name);
        case '.shp':
          return await this.parseShapefile(file.uri, file.name);
        case '.kml':
          return await this.parseKML(fileContent, file.name);
        case '.geojson':
        case '.json':
          return await this.parseGeoJSON(fileContent, file.name);
        case '.csv':
          return await this.parseCSV(fileContent, file.name);
        default:
          return {
            success: false,
            errors: ['تنسيق الملف غير مدعوم'],
          };
      }
    } catch (error) {
      if (DocumentPicker.isCancel(error)) {
        return {
          success: false,
          errors: ['تم إلغاء اختيار الملف'],
        };
      }

      return {
        success: false,
        errors: [`خطأ في استيراد الملف: ${error.message}`],
      };
    }
  }

  /**
   * تصدير البيانات إلى ملف
   */
  async exportData(
    data: CADDrawing | GISDataset,
    options: ExportOptions
  ): Promise<boolean> {
    try {
      let fileContent: string;
      let fileName: string;
      let mimeType: string;

      // تحديد اسم الملف ونوع MIME
      const baseName = data.name.replace(/[^a-zA-Z0-9\u0600-\u06FF]/g, '_');
      
      switch (options.format) {
        case 'DXF':
          fileContent = this.generateDXF(data as CADDrawing, options);
          fileName = `${baseName}.dxf`;
          mimeType = 'application/dxf';
          break;
        case 'SHP':
          // Shapefile يتطلب معالجة خاصة لأنه يتكون من عدة ملفات
          return await this.exportShapefile(data as GISDataset, baseName, options);
        case 'KML':
          fileContent = this.generateKML(data as GISDataset, options);
          fileName = `${baseName}.kml`;
          mimeType = 'application/vnd.google-earth.kml+xml';
          break;
        case 'GeoJSON':
          fileContent = this.generateGeoJSON(data as GISDataset, options);
          fileName = `${baseName}.geojson`;
          mimeType = 'application/geo+json';
          break;
        case 'CSV':
          fileContent = this.generateCSV(data, options);
          fileName = `${baseName}.csv`;
          mimeType = 'text/csv';
          break;
        default:
          throw new Error('تنسيق التصدير غير مدعوم');
      }

      // حفظ الملف في مجلد مؤقت
      const filePath = `${RNFS.CachesDirectoryPath}/${fileName}`;
      await RNFS.writeFile(filePath, fileContent, 'utf8');

      // مشاركة الملف
      await Share.open({
        url: `file://${filePath}`,
        type: mimeType,
        filename: fileName,
        title: 'تصدير بيانات المسح',
        message: `ملف ${options.format} يحتوي على بيانات المسح`,
      });

      return true;
    } catch (error) {
      Alert.alert('خطأ في التصدير', error.message);
      return false;
    }
  }

  /**
   * تحويل نقاط المسح إلى تنسيق CAD
   */
  convertSurveyPointsToCAD(
    surveyPoints: any[],
    name: string = 'مسح جديد'
  ): CADDrawing {
    const cadPoints: CADPoint[] = surveyPoints.map((point, index) => ({
      id: point.id || `point_${index}`,
      x: point.longitude || point.x || 0,
      y: point.latitude || point.y || 0,
      z: point.altitude || point.z || 0,
      code: point.code || point.type || 'SURVEY',
      description: point.description || point.label || `نقطة ${index + 1}`,
      layer: point.layer || 'SURVEY_POINTS',
      attributes: {
        accuracy: point.accuracy,
        timestamp: point.timestamp,
        ...point.attributes,
      },
    }));

    // حساب الحدود
    const bounds = this.calculateBounds(cadPoints);

    return {
      id: `survey_${Date.now()}`,
      name,
      description: 'بيانات مسح مستوردة من تطبيق المساح',
      units: 'meters',
      coordinateSystem: 'WGS84',
      points: cadPoints,
      lines: [],
      polygons: [],
      layers: ['SURVEY_POINTS'],
      bounds,
      metadata: {
        source: 'Surveyor App',
        created: new Date().toISOString(),
        pointCount: cadPoints.length,
      },
    };
  }

  /**
   * تحويل بيانات CAD إلى نقاط مسح
   */
  convertCADToSurveyPoints(cadDrawing: CADDrawing): any[] {
    return cadDrawing.points.map(point => ({
      id: point.id,
      latitude: point.y,
      longitude: point.x,
      altitude: point.z || 0,
      label: point.description || point.code || 'نقطة مستوردة',
      type: point.code || 'imported',
      layer: point.layer,
      accuracy: point.attributes?.accuracy || 1,
      timestamp: point.attributes?.timestamp || new Date().toISOString(),
      source: 'CAD Import',
      attributes: point.attributes,
    }));
  }

  /**
   * معالجة ملف DXF
   */
  private async parseDXF(content: string, fileName: string): Promise<ImportResult> {
    try {
      // تحليل مبسط لملف DXF
      const lines = content.split('\n');
      const points: CADPoint[] = [];
      const cadLines: CADLine[] = [];
      const layers: string[] = [];

      let currentEntity: any = {};
      let entityType = '';

      for (let i = 0; i < lines.length; i++) {
        const line = lines[i].trim();
        
        if (line === '0') {
          // بداية كيان جديد
          if (entityType === 'POINT' && currentEntity.x !== undefined) {
            points.push({
              id: `point_${points.length}`,
              x: currentEntity.x,
              y: currentEntity.y,
              z: currentEntity.z || 0,
              layer: currentEntity.layer || 'DEFAULT',
            });
          }
          
          currentEntity = {};
          entityType = lines[i + 1]?.trim() || '';
        } else if (line === '10') {
          // إحداثي X
          currentEntity.x = parseFloat(lines[i + 1]?.trim() || '0');
        } else if (line === '20') {
          // إحداثي Y
          currentEntity.y = parseFloat(lines[i + 1]?.trim() || '0');
        } else if (line === '30') {
          // إحداثي Z
          currentEntity.z = parseFloat(lines[i + 1]?.trim() || '0');
        } else if (line === '8') {
          // اسم الطبقة
          const layerName = lines[i + 1]?.trim() || 'DEFAULT';
          currentEntity.layer = layerName;
          if (!layers.includes(layerName)) {
            layers.push(layerName);
          }
        }
      }

      const bounds = this.calculateBounds(points);

      const cadDrawing: CADDrawing = {
        id: `import_${Date.now()}`,
        name: fileName.replace('.dxf', ''),
        units: 'meters',
        points,
        lines: cadLines,
        polygons: [],
        layers,
        bounds,
        metadata: {
          source: 'DXF Import',
          originalFileName: fileName,
          imported: new Date().toISOString(),
        },
      };

      return {
        success: true,
        data: cadDrawing,
        warnings: points.length === 0 ? ['لم يتم العثور على نقاط في الملف'] : undefined,
      };
    } catch (error) {
      return {
        success: false,
        errors: [`خطأ في تحليل ملف DXF: ${error.message}`],
      };
    }
  }

  /**
   * معالجة ملف GeoJSON
   */
  private async parseGeoJSON(content: string, fileName: string): Promise<ImportResult> {
    try {
      const geoJson = JSON.parse(content);
      
      if (!geoJson.type || geoJson.type !== 'FeatureCollection') {
        return {
          success: false,
          errors: ['ملف GeoJSON غير صالح - يجب أن يكون من نوع FeatureCollection'],
        };
      }

      const features: GISFeature[] = geoJson.features.map((feature: any, index: number) => ({
        id: feature.id || `feature_${index}`,
        type: feature.geometry.type,
        coordinates: feature.geometry.coordinates,
        properties: feature.properties || {},
        crs: geoJson.crs?.properties?.name || 'WGS84',
      }));

      // حساب الحدود
      const bounds = this.calculateGISBounds(features);

      const gisDataset: GISDataset = {
        id: `import_${Date.now()}`,
        name: fileName.replace(/\.(geojson|json)$/, ''),
        crs: geoJson.crs?.properties?.name || 'WGS84',
        features,
        bounds,
        metadata: {
          source: 'GeoJSON Import',
          originalFileName: fileName,
          imported: new Date().toISOString(),
          featureCount: features.length,
        },
      };

      return {
        success: true,
        data: gisDataset,
      };
    } catch (error) {
      return {
        success: false,
        errors: [`خطأ في تحليل ملف GeoJSON: ${error.message}`],
      };
    }
  }

  /**
   * معالجة ملف KML
   */
  private async parseKML(content: string, fileName: string): Promise<ImportResult> {
    try {
      // تحليل مبسط لملف KML
      const features: GISFeature[] = [];
      
      // البحث عن نقاط Placemark
      const placemarkRegex = /<Placemark[^>]*>(.*?)<\/Placemark>/gs;
      let match;

      while ((match = placemarkRegex.exec(content)) !== null) {
        const placemarkContent = match[1];
        
        // استخراج الاسم
        const nameMatch = placemarkContent.match(/<name[^>]*>(.*?)<\/name>/s);
        const name = nameMatch ? nameMatch[1].trim() : '';

        // استخراج الوصف
        const descMatch = placemarkContent.match(/<description[^>]*>(.*?)<\/description>/s);
        const description = descMatch ? descMatch[1].trim() : '';

        // استخراج الإحداثيات
        const coordMatch = placemarkContent.match(/<coordinates[^>]*>(.*?)<\/coordinates>/s);
        if (coordMatch) {
          const coordString = coordMatch[1].trim();
          const coords = coordString.split(',').map(c => parseFloat(c.trim()));
          
          if (coords.length >= 2) {
            features.push({
              id: `feature_${features.length}`,
              type: 'Point',
              coordinates: [coords[0], coords[1], coords[2] || 0],
              properties: {
                name,
                description,
              },
              crs: 'WGS84',
            });
          }
        }
      }

      const bounds = this.calculateGISBounds(features);

      const gisDataset: GISDataset = {
        id: `import_${Date.now()}`,
        name: fileName.replace('.kml', ''),
        crs: 'WGS84',
        features,
        bounds,
        metadata: {
          source: 'KML Import',
          originalFileName: fileName,
          imported: new Date().toISOString(),
          featureCount: features.length,
        },
      };

      return {
        success: true,
        data: gisDataset,
        warnings: features.length === 0 ? ['لم يتم العثور على نقاط في الملف'] : undefined,
      };
    } catch (error) {
      return {
        success: false,
        errors: [`خطأ في تحليل ملف KML: ${error.message}`],
      };
    }
  }

  /**
   * معالجة ملف CSV
   */
  private async parseCSV(content: string, fileName: string): Promise<ImportResult> {
    try {
      const lines = content.split('\n').filter(line => line.trim());
      if (lines.length < 2) {
        return {
          success: false,
          errors: ['ملف CSV فارغ أو لا يحتوي على بيانات كافية'],
        };
      }

      // تحليل العنوان
      const headers = lines[0].split(',').map(h => h.trim().toLowerCase());
      
      // البحث عن أعمدة الإحداثيات
      const xIndex = this.findColumnIndex(headers, ['x', 'longitude', 'long', 'lng', 'طول']);
      const yIndex = this.findColumnIndex(headers, ['y', 'latitude', 'lat', 'عرض']);
      const zIndex = this.findColumnIndex(headers, ['z', 'elevation', 'altitude', 'ارتفاع']);
      const nameIndex = this.findColumnIndex(headers, ['name', 'label', 'description', 'اسم', 'وصف']);

      if (xIndex === -1 || yIndex === -1) {
        return {
          success: false,
          errors: ['لم يتم العثور على أعمدة الإحداثيات (X/Longitude و Y/Latitude)'],
        };
      }

      const points: CADPoint[] = [];

      for (let i = 1; i < lines.length; i++) {
        const values = lines[i].split(',').map(v => v.trim());
        
        if (values.length < Math.max(xIndex, yIndex) + 1) continue;

        const x = parseFloat(values[xIndex]);
        const y = parseFloat(values[yIndex]);
        
        if (isNaN(x) || isNaN(y)) continue;

        points.push({
          id: `point_${i}`,
          x,
          y,
          z: zIndex !== -1 ? parseFloat(values[zIndex]) || 0 : 0,
          description: nameIndex !== -1 ? values[nameIndex] : `نقطة ${i}`,
          layer: 'CSV_IMPORT',
          attributes: headers.reduce((attrs, header, index) => {
            if (index < values.length && header !== 'x' && header !== 'y' && header !== 'z') {
              attrs[header] = values[index];
            }
            return attrs;
          }, {} as Record<string, any>),
        });
      }

      const bounds = this.calculateBounds(points);

      const cadDrawing: CADDrawing = {
        id: `import_${Date.now()}`,
        name: fileName.replace('.csv', ''),
        units: 'meters',
        points,
        lines: [],
        polygons: [],
        layers: ['CSV_IMPORT'],
        bounds,
        metadata: {
          source: 'CSV Import',
          originalFileName: fileName,
          imported: new Date().toISOString(),
          headers,
        },
      };

      return {
        success: true,
        data: cadDrawing,
      };
    } catch (error) {
      return {
        success: false,
        errors: [`خطأ في تحليل ملف CSV: ${error.message}`],
      };
    }
  }

  /**
   * معالجة ملف Shapefile (مبسط)
   */
  private async parseShapefile(fileUri: string, fileName: string): Promise<ImportResult> {
    // Shapefile يتطلب مكتبات متخصصة لقراءة البيانات الثنائية
    // هنا نقدم تنفيذ مبسط
    return {
      success: false,
      errors: ['قراءة ملفات Shapefile تتطلب مكتبات إضافية'],
      warnings: ['يمكنك تحويل ملف Shapefile إلى GeoJSON أو KML واستيراده بدلاً من ذلك'],
    };
  }

  /**
   * توليد ملف DXF
   */
  private generateDXF(drawing: CADDrawing, options: ExportOptions): string {
    let dxf = '';
    
    // رأس الملف
    dxf += '0\nSECTION\n2\nHEADER\n';
    dxf += '9\n$ACADVER\n1\nAC1015\n'; // AutoCAD 2000
    dxf += '0\nENDSEC\n';
    
    // قسم الجداول
    dxf += '0\nSECTION\n2\nTABLES\n';
    
    // جدول الطبقات
    dxf += '0\nTABLE\n2\nLAYER\n70\n' + drawing.layers.length + '\n';
    drawing.layers.forEach(layer => {
      dxf += '0\nLAYER\n2\n' + layer + '\n70\n0\n62\n7\n6\nCONTINUOUS\n';
    });
    dxf += '0\nENDTAB\n';
    dxf += '0\nENDSEC\n';
    
    // قسم الكيانات
    dxf += '0\nSECTION\n2\nENTITIES\n';
    
    // إضافة النقاط
    drawing.points.forEach(point => {
      if (!options.layers || options.layers.includes(point.layer || 'DEFAULT')) {
        dxf += '0\nPOINT\n';
        dxf += '8\n' + (point.layer || 'DEFAULT') + '\n';
        dxf += '10\n' + point.x.toFixed(options.precision || 6) + '\n';
        dxf += '20\n' + point.y.toFixed(options.precision || 6) + '\n';
        if (point.z !== undefined) {
          dxf += '30\n' + point.z.toFixed(options.precision || 6) + '\n';
        }
      }
    });
    
    // إضافة الخطوط
    drawing.lines.forEach(line => {
      if (!options.layers || options.layers.includes(line.layer || 'DEFAULT')) {
        dxf += '0\nLINE\n';
        dxf += '8\n' + (line.layer || 'DEFAULT') + '\n';
        dxf += '10\n' + line.startPoint.x.toFixed(options.precision || 6) + '\n';
        dxf += '20\n' + line.startPoint.y.toFixed(options.precision || 6) + '\n';
        dxf += '11\n' + line.endPoint.x.toFixed(options.precision || 6) + '\n';
        dxf += '21\n' + line.endPoint.y.toFixed(options.precision || 6) + '\n';
      }
    });
    
    dxf += '0\nENDSEC\n';
    dxf += '0\nEOF\n';
    
    return dxf;
  }

  /**
   * توليد ملف GeoJSON
   */
  private generateGeoJSON(dataset: GISDataset, options: ExportOptions): string {
    const geoJson = {
      type: 'FeatureCollection',
      crs: {
        type: 'name',
        properties: {
          name: options.coordinateSystem || dataset.crs || 'WGS84',
        },
      },
      features: dataset.features.map(feature => ({
        type: 'Feature',
        id: feature.id,
        geometry: {
          type: feature.type,
          coordinates: feature.coordinates,
        },
        properties: options.includeAttributes !== false ? feature.properties : {},
      })),
    };

    return JSON.stringify(geoJson, null, 2);
  }

  /**
   * توليد ملف KML
   */
  private generateKML(dataset: GISDataset, options: ExportOptions): string {
    let kml = '<?xml version="1.0" encoding="UTF-8"?>\n';
    kml += '<kml xmlns="http://www.opengis.net/kml/2.2">\n';
    kml += '<Document>\n';
    kml += `<name>${dataset.name}</name>\n`;
    if (dataset.description) {
      kml += `<description>${dataset.description}</description>\n`;
    }

    dataset.features.forEach(feature => {
      if (feature.type === 'Point') {
        kml += '<Placemark>\n';
        kml += `<name>${feature.properties.name || feature.id}</name>\n`;
        if (feature.properties.description) {
          kml += `<description>${feature.properties.description}</description>\n`;
        }
        kml += '<Point>\n';
        const coords = feature.coordinates as number[];
        kml += `<coordinates>${coords[0]},${coords[1]},${coords[2] || 0}</coordinates>\n`;
        kml += '</Point>\n';
        kml += '</Placemark>\n';
      }
    });

    kml += '</Document>\n';
    kml += '</kml>\n';

    return kml;
  }

  /**
   * توليد ملف CSV
   */
  private generateCSV(data: CADDrawing | GISDataset, options: ExportOptions): string {
    let csv = '';
    
    if ('points' in data) {
      // بيانات CAD
      const headers = ['ID', 'X', 'Y', 'Z', 'Code', 'Description', 'Layer'];
      if (options.includeAttributes !== false) {
        // إضافة أعمدة الخصائص الإضافية
        const allAttributes = new Set<string>();
        data.points.forEach(point => {
          if (point.attributes) {
            Object.keys(point.attributes).forEach(key => allAttributes.add(key));
          }
        });
        headers.push(...Array.from(allAttributes));
      }
      
      csv += headers.join(',') + '\n';
      
      data.points.forEach(point => {
        const row = [
          point.id,
          point.x.toFixed(options.precision || 6),
          point.y.toFixed(options.precision || 6),
          (point.z || 0).toFixed(options.precision || 6),
          point.code || '',
          point.description || '',
          point.layer || '',
        ];
        
        if (options.includeAttributes !== false && point.attributes) {
          headers.slice(7).forEach(attr => {
            row.push(point.attributes?.[attr] || '');
          });
        }
        
        csv += row.join(',') + '\n';
      });
    } else {
      // بيانات GIS
      const headers = ['ID', 'Type', 'Longitude', 'Latitude', 'Altitude'];
      if (options.includeAttributes !== false) {
        const allProperties = new Set<string>();
        data.features.forEach(feature => {
          Object.keys(feature.properties).forEach(key => allProperties.add(key));
        });
        headers.push(...Array.from(allProperties));
      }
      
      csv += headers.join(',') + '\n';
      
      data.features.forEach(feature => {
        if (feature.type === 'Point') {
          const coords = feature.coordinates as number[];
          const row = [
            feature.id,
            feature.type,
            coords[0].toFixed(options.precision || 6),
            coords[1].toFixed(options.precision || 6),
            (coords[2] || 0).toFixed(options.precision || 6),
          ];
          
          if (options.includeAttributes !== false) {
            headers.slice(5).forEach(prop => {
              row.push(feature.properties[prop] || '');
            });
          }
          
          csv += row.join(',') + '\n';
        }
      });
    }
    
    return csv;
  }

  /**
   * تصدير Shapefile (مبسط)
   */
  private async exportShapefile(
    dataset: GISDataset,
    baseName: string,
    options: ExportOptions
  ): Promise<boolean> {
    // تصدير Shapefile يتطلب مكتبات متخصصة
    Alert.alert(
      'تصدير Shapefile',
      'تصدير ملفات Shapefile غير مدعوم حالياً. يمكنك استخدام تنسيق GeoJSON بدلاً من ذلك.',
      [{ text: 'موافق' }]
    );
    return false;
  }

  /**
   * حساب حدود النقاط
   */
  private calculateBounds(points: CADPoint[]): {
    minX: number;
    minY: number;
    maxX: number;
    maxY: number;
  } {
    if (points.length === 0) {
      return { minX: 0, minY: 0, maxX: 0, maxY: 0 };
    }

    let minX = points[0].x;
    let minY = points[0].y;
    let maxX = points[0].x;
    let maxY = points[0].y;

    points.forEach(point => {
      minX = Math.min(minX, point.x);
      minY = Math.min(minY, point.y);
      maxX = Math.max(maxX, point.x);
      maxY = Math.max(maxY, point.y);
    });

    return { minX, minY, maxX, maxY };
  }

  /**
   * حساب حدود بيانات GIS
   */
  private calculateGISBounds(features: GISFeature[]): [number, number, number, number] {
    if (features.length === 0) {
      return [0, 0, 0, 0];
    }

    let minX = Infinity;
    let minY = Infinity;
    let maxX = -Infinity;
    let maxY = -Infinity;

    features.forEach(feature => {
      if (feature.type === 'Point') {
        const coords = feature.coordinates as number[];
        minX = Math.min(minX, coords[0]);
        minY = Math.min(minY, coords[1]);
        maxX = Math.max(maxX, coords[0]);
        maxY = Math.max(maxY, coords[1]);
      }
    });

    return [minX, minY, maxX, maxY];
  }

  /**
   * الحصول على امتداد الملف
   */
  private getFileExtension(fileName: string): string {
    const lastDot = fileName.lastIndexOf('.');
    return lastDot !== -1 ? fileName.substring(lastDot) : '';
  }

  /**
   * البحث عن فهرس العمود
   */
  private findColumnIndex(headers: string[], possibleNames: string[]): number {
    for (const name of possibleNames) {
      const index = headers.findIndex(h => h.includes(name));
      if (index !== -1) return index;
    }
    return -1;
  }

  /**
   * الحصول على التنسيقات المدعومة للاستيراد
   */
  getSupportedImportFormats(): string[] {
    return [...this.supportedImportFormats];
  }

  /**
   * الحصول على التنسيقات المدعومة للتصدير
   */
  getSupportedExportFormats(): string[] {
    return [...this.supportedExportFormats];
  }
}

export default new CADGISService();

