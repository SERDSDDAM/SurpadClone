import RNFS from 'react-native-fs';
import SQLite from 'react-native-sqlite-storage';
import { Alert } from 'react-native';

export interface MapTile {
  id: string;
  x: number;
  y: number;
  z: number; // zoom level
  url: string;
  localPath?: string;
  size: number;
  downloadedAt: Date;
  lastAccessed: Date;
}

export interface MapRegion {
  id: string;
  name: string;
  description?: string;
  bounds: {
    north: number;
    south: number;
    east: number;
    west: number;
  };
  minZoom: number;
  maxZoom: number;
  tileCount: number;
  downloadedTiles: number;
  totalSize: number;
  downloadedSize: number;
  status: 'pending' | 'downloading' | 'completed' | 'paused' | 'error';
  createdAt: Date;
  updatedAt: Date;
  expiresAt?: Date;
}

export interface DownloadProgress {
  regionId: string;
  totalTiles: number;
  downloadedTiles: number;
  failedTiles: number;
  currentTile?: MapTile;
  bytesDownloaded: number;
  totalBytes: number;
  speed: number; // bytes per second
  estimatedTimeRemaining: number; // seconds
}

export interface MapProvider {
  id: string;
  name: string;
  urlTemplate: string;
  attribution: string;
  maxZoom: number;
  tileSize: number;
  format: 'png' | 'jpg';
  requiresApiKey: boolean;
}

class OfflineMapService {
  private db: SQLite.SQLiteDatabase | null = null;
  private mapDirectory: string;
  private downloadQueue: MapTile[] = [];
  private isDownloading = false;
  private downloadProgressListeners: Map<string, (progress: DownloadProgress) => void> = new Map();
  private maxConcurrentDownloads = 3;
  private activeDownloads = 0;
  private downloadStats: Map<string, DownloadProgress> = new Map();

  // مقدمي الخرائط المدعومين
  private mapProviders: MapProvider[] = [
    {
      id: 'osm',
      name: 'OpenStreetMap',
      urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
      attribution: '© OpenStreetMap contributors',
      maxZoom: 19,
      tileSize: 256,
      format: 'png',
      requiresApiKey: false,
    },
    {
      id: 'satellite',
      name: 'Satellite',
      urlTemplate: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
      attribution: '© Esri',
      maxZoom: 18,
      tileSize: 256,
      format: 'jpg',
      requiresApiKey: false,
    },
    {
      id: 'terrain',
      name: 'Terrain',
      urlTemplate: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Topo_Map/MapServer/tile/{z}/{y}/{x}',
      attribution: '© Esri',
      maxZoom: 16,
      tileSize: 256,
      format: 'jpg',
      requiresApiKey: false,
    },
  ];

  constructor() {
    this.mapDirectory = `${RNFS.DocumentDirectoryPath}/offline_maps`;
    this.initializeService();
  }

  /**
   * تهيئة خدمة الخرائط غير المتصلة
   */
  private async initializeService(): Promise<void> {
    try {
      // إنشاء مجلد الخرائط
      const exists = await RNFS.exists(this.mapDirectory);
      if (!exists) {
        await RNFS.mkdir(this.mapDirectory);
      }

      // تهيئة قاعدة البيانات
      await this.initializeDatabase();
      
      // تنظيف الملفات القديمة
      await this.cleanupExpiredTiles();
      
      console.log('تم تهيئة خدمة الخرائط غير المتصلة');
    } catch (error) {
      console.error('خطأ في تهيئة خدمة الخرائط:', error);
    }
  }

  /**
   * تهيئة قاعدة البيانات
   */
  private async initializeDatabase(): Promise<void> {
    return new Promise((resolve, reject) => {
      this.db = SQLite.openDatabase(
        {
          name: 'offline_maps.db',
          location: 'Documents',
        },
        () => {
          this.createTables().then(resolve).catch(reject);
        },
        (error) => {
          console.error('خطأ في فتح قاعدة البيانات:', error);
          reject(error);
        }
      );
    });
  }

  /**
   * إنشاء جداول قاعدة البيانات
   */
  private async createTables(): Promise<void> {
    if (!this.db) throw new Error('قاعدة البيانات غير مهيأة');

    return new Promise((resolve, reject) => {
      this.db!.transaction((tx) => {
        // جدول المناطق
        tx.executeSql(`
          CREATE TABLE IF NOT EXISTS regions (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            description TEXT,
            bounds_north REAL NOT NULL,
            bounds_south REAL NOT NULL,
            bounds_east REAL NOT NULL,
            bounds_west REAL NOT NULL,
            min_zoom INTEGER NOT NULL,
            max_zoom INTEGER NOT NULL,
            tile_count INTEGER NOT NULL,
            downloaded_tiles INTEGER DEFAULT 0,
            total_size INTEGER DEFAULT 0,
            downloaded_size INTEGER DEFAULT 0,
            status TEXT DEFAULT 'pending',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            expires_at TEXT
          )
        `);

        // جدول البلاطات
        tx.executeSql(`
          CREATE TABLE IF NOT EXISTS tiles (
            id TEXT PRIMARY KEY,
            region_id TEXT NOT NULL,
            x INTEGER NOT NULL,
            y INTEGER NOT NULL,
            z INTEGER NOT NULL,
            url TEXT NOT NULL,
            local_path TEXT,
            size INTEGER DEFAULT 0,
            downloaded_at TEXT,
            last_accessed TEXT,
            FOREIGN KEY (region_id) REFERENCES regions (id) ON DELETE CASCADE
          )
        `);

        // فهارس لتحسين الأداء
        tx.executeSql('CREATE INDEX IF NOT EXISTS idx_tiles_region ON tiles (region_id)');
        tx.executeSql('CREATE INDEX IF NOT EXISTS idx_tiles_xyz ON tiles (x, y, z)');
        tx.executeSql('CREATE INDEX IF NOT EXISTS idx_tiles_accessed ON tiles (last_accessed)');
      }, reject, resolve);
    });
  }

  /**
   * إنشاء منطقة خريطة جديدة للتنزيل
   */
  async createMapRegion(
    name: string,
    bounds: { north: number; south: number; east: number; west: number },
    minZoom: number,
    maxZoom: number,
    providerId: string = 'osm',
    description?: string
  ): Promise<MapRegion> {
    const provider = this.mapProviders.find(p => p.id === providerId);
    if (!provider) {
      throw new Error('مقدم الخرائط غير مدعوم');
    }

    // التحقق من صحة المستويات
    if (minZoom < 0 || maxZoom > provider.maxZoom || minZoom > maxZoom) {
      throw new Error('مستويات التكبير غير صالحة');
    }

    // حساب عدد البلاطات
    const tileCount = this.calculateTileCount(bounds, minZoom, maxZoom);
    
    if (tileCount > 10000) {
      throw new Error('المنطقة كبيرة جداً. يرجى تقليل المساحة أو مستوى التكبير');
    }

    const region: MapRegion = {
      id: `region_${Date.now()}`,
      name,
      description,
      bounds,
      minZoom,
      maxZoom,
      tileCount,
      downloadedTiles: 0,
      totalSize: tileCount * 15000, // تقدير متوسط حجم البلاطة
      downloadedSize: 0,
      status: 'pending',
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    // حفظ المنطقة في قاعدة البيانات
    await this.saveRegion(region);

    // إنشاء قائمة البلاطات
    await this.generateTileList(region, provider);

    return region;
  }

  /**
   * بدء تنزيل منطقة خريطة
   */
  async startDownload(regionId: string): Promise<void> {
    const region = await this.getRegion(regionId);
    if (!region) {
      throw new Error('المنطقة غير موجودة');
    }

    if (region.status === 'downloading') {
      throw new Error('التنزيل قيد التشغيل بالفعل');
    }

    // تحديث حالة المنطقة
    await this.updateRegionStatus(regionId, 'downloading');

    // بدء عملية التنزيل
    this.processDownloadQueue(regionId);
  }

  /**
   * إيقاف تنزيل منطقة مؤقتاً
   */
  async pauseDownload(regionId: string): Promise<void> {
    await this.updateRegionStatus(regionId, 'paused');
    // إزالة بلاطات هذه المنطقة من قائمة الانتظار
    this.downloadQueue = this.downloadQueue.filter(tile => 
      !tile.id.startsWith(regionId)
    );
  }

  /**
   * استئناف تنزيل منطقة
   */
  async resumeDownload(regionId: string): Promise<void> {
    const region = await this.getRegion(regionId);
    if (!region || region.status !== 'paused') {
      throw new Error('لا يمكن استئناف التنزيل');
    }

    await this.updateRegionStatus(regionId, 'downloading');
    this.processDownloadQueue(regionId);
  }

  /**
   * حذف منطقة خريطة
   */
  async deleteRegion(regionId: string): Promise<void> {
    if (!this.db) throw new Error('قاعدة البيانات غير مهيأة');

    // إيقاف التنزيل إذا كان قيد التشغيل
    await this.pauseDownload(regionId);

    // حذف ملفات البلاطات
    const tiles = await this.getRegionTiles(regionId);
    for (const tile of tiles) {
      if (tile.localPath && await RNFS.exists(tile.localPath)) {
        await RNFS.unlink(tile.localPath);
      }
    }

    // حذف من قاعدة البيانات
    return new Promise((resolve, reject) => {
      this.db!.transaction((tx) => {
        tx.executeSql('DELETE FROM regions WHERE id = ?', [regionId]);
        tx.executeSql('DELETE FROM tiles WHERE region_id = ?', [regionId]);
      }, reject, resolve);
    });
  }

  /**
   * الحصول على بلاطة محلية
   */
  async getOfflineTile(x: number, y: number, z: number): Promise<string | null> {
    if (!this.db) return null;

    return new Promise((resolve) => {
      this.db!.executeSql(
        'SELECT local_path FROM tiles WHERE x = ? AND y = ? AND z = ? AND local_path IS NOT NULL',
        [x, y, z],
        (tx, results) => {
          if (results.rows.length > 0) {
            const localPath = results.rows.item(0).local_path;
            // تحديث وقت آخر وصول
            this.updateTileAccess(x, y, z);
            resolve(localPath);
          } else {
            resolve(null);
          }
        },
        () => resolve(null)
      );
    });
  }

  /**
   * الحصول على جميع المناطق
   */
  async getAllRegions(): Promise<MapRegion[]> {
    if (!this.db) return [];

    return new Promise((resolve, reject) => {
      this.db!.executeSql(
        'SELECT * FROM regions ORDER BY created_at DESC',
        [],
        (tx, results) => {
          const regions: MapRegion[] = [];
          for (let i = 0; i < results.rows.length; i++) {
            const row = results.rows.item(i);
            regions.push(this.parseRegionFromRow(row));
          }
          resolve(regions);
        },
        reject
      );
    });
  }

  /**
   * الحصول على منطقة محددة
   */
  async getRegion(regionId: string): Promise<MapRegion | null> {
    if (!this.db) return null;

    return new Promise((resolve, reject) => {
      this.db!.executeSql(
        'SELECT * FROM regions WHERE id = ?',
        [regionId],
        (tx, results) => {
          if (results.rows.length > 0) {
            resolve(this.parseRegionFromRow(results.rows.item(0)));
          } else {
            resolve(null);
          }
        },
        reject
      );
    });
  }

  /**
   * الحصول على إحصائيات التخزين
   */
  async getStorageStats(): Promise<{
    totalRegions: number;
    totalTiles: number;
    totalSize: number;
    availableSpace: number;
  }> {
    if (!this.db) {
      return { totalRegions: 0, totalTiles: 0, totalSize: 0, availableSpace: 0 };
    }

    const regions = await this.getAllRegions();
    const totalSize = regions.reduce((sum, region) => sum + region.downloadedSize, 0);
    
    // حساب المساحة المتاحة
    const freeSpace = await RNFS.getFSInfo();
    
    return {
      totalRegions: regions.length,
      totalTiles: regions.reduce((sum, region) => sum + region.downloadedTiles, 0),
      totalSize,
      availableSpace: freeSpace.freeSpace,
    };
  }

  /**
   * تنظيف البلاطات المنتهية الصلاحية
   */
  async cleanupExpiredTiles(): Promise<void> {
    if (!this.db) return;

    const now = new Date().toISOString();
    
    return new Promise((resolve, reject) => {
      this.db!.executeSql(
        'SELECT local_path FROM tiles WHERE expires_at IS NOT NULL AND expires_at < ?',
        [now],
        async (tx, results) => {
          try {
            // حذف الملفات
            for (let i = 0; i < results.rows.length; i++) {
              const localPath = results.rows.item(i).local_path;
              if (localPath && await RNFS.exists(localPath)) {
                await RNFS.unlink(localPath);
              }
            }
            
            // حذف من قاعدة البيانات
            this.db!.executeSql(
              'DELETE FROM tiles WHERE expires_at IS NOT NULL AND expires_at < ?',
              [now],
              () => resolve(),
              reject
            );
          } catch (error) {
            reject(error);
          }
        },
        reject
      );
    });
  }

  /**
   * تسجيل مستمع لتقدم التنزيل
   */
  registerProgressListener(id: string, listener: (progress: DownloadProgress) => void): void {
    this.downloadProgressListeners.set(id, listener);
  }

  /**
   * إلغاء تسجيل مستمع التقدم
   */
  unregisterProgressListener(id: string): void {
    this.downloadProgressListeners.delete(id);
  }

  /**
   * الحصول على مقدمي الخرائط المدعومين
   */
  getMapProviders(): MapProvider[] {
    return [...this.mapProviders];
  }

  /**
   * حساب عدد البلاطات المطلوبة
   */
  private calculateTileCount(
    bounds: { north: number; south: number; east: number; west: number },
    minZoom: number,
    maxZoom: number
  ): number {
    let totalTiles = 0;
    
    for (let z = minZoom; z <= maxZoom; z++) {
      const n = Math.pow(2, z);
      const minX = Math.floor((bounds.west + 180) / 360 * n);
      const maxX = Math.floor((bounds.east + 180) / 360 * n);
      const minY = Math.floor((1 - Math.log(Math.tan(bounds.north * Math.PI / 180) + 1 / Math.cos(bounds.north * Math.PI / 180)) / Math.PI) / 2 * n);
      const maxY = Math.floor((1 - Math.log(Math.tan(bounds.south * Math.PI / 180) + 1 / Math.cos(bounds.south * Math.PI / 180)) / Math.PI) / 2 * n);
      
      totalTiles += (maxX - minX + 1) * (maxY - minY + 1);
    }
    
    return totalTiles;
  }

  /**
   * إنشاء قائمة البلاطات للمنطقة
   */
  private async generateTileList(region: MapRegion, provider: MapProvider): Promise<void> {
    if (!this.db) throw new Error('قاعدة البيانات غير مهيأة');

    const tiles: MapTile[] = [];
    
    for (let z = region.minZoom; z <= region.maxZoom; z++) {
      const n = Math.pow(2, z);
      const minX = Math.floor((region.bounds.west + 180) / 360 * n);
      const maxX = Math.floor((region.bounds.east + 180) / 360 * n);
      const minY = Math.floor((1 - Math.log(Math.tan(region.bounds.north * Math.PI / 180) + 1 / Math.cos(region.bounds.north * Math.PI / 180)) / Math.PI) / 2 * n);
      const maxY = Math.floor((1 - Math.log(Math.tan(region.bounds.south * Math.PI / 180) + 1 / Math.cos(region.bounds.south * Math.PI / 180)) / Math.PI) / 2 * n);
      
      for (let x = minX; x <= maxX; x++) {
        for (let y = minY; y <= maxY; y++) {
          const url = provider.urlTemplate
            .replace('{x}', x.toString())
            .replace('{y}', y.toString())
            .replace('{z}', z.toString());
          
          tiles.push({
            id: `${region.id}_${z}_${x}_${y}`,
            x,
            y,
            z,
            url,
            size: 0,
            downloadedAt: new Date(),
            lastAccessed: new Date(),
          });
        }
      }
    }

    // حفظ البلاطات في قاعدة البيانات
    await this.saveTiles(region.id, tiles);
  }

  /**
   * حفظ المنطقة في قاعدة البيانات
   */
  private async saveRegion(region: MapRegion): Promise<void> {
    if (!this.db) throw new Error('قاعدة البيانات غير مهيأة');

    return new Promise((resolve, reject) => {
      this.db!.executeSql(
        `INSERT INTO regions (
          id, name, description, bounds_north, bounds_south, bounds_east, bounds_west,
          min_zoom, max_zoom, tile_count, downloaded_tiles, total_size, downloaded_size,
          status, created_at, updated_at, expires_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          region.id, region.name, region.description || null,
          region.bounds.north, region.bounds.south, region.bounds.east, region.bounds.west,
          region.minZoom, region.maxZoom, region.tileCount, region.downloadedTiles,
          region.totalSize, region.downloadedSize, region.status,
          region.createdAt.toISOString(), region.updatedAt.toISOString(),
          region.expiresAt?.toISOString() || null
        ],
        () => resolve(),
        reject
      );
    });
  }

  /**
   * حفظ البلاطات في قاعدة البيانات
   */
  private async saveTiles(regionId: string, tiles: MapTile[]): Promise<void> {
    if (!this.db) throw new Error('قاعدة البيانات غير مهيأة');

    return new Promise((resolve, reject) => {
      this.db!.transaction((tx) => {
        tiles.forEach(tile => {
          tx.executeSql(
            `INSERT INTO tiles (
              id, region_id, x, y, z, url, local_path, size, downloaded_at, last_accessed
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [
              tile.id, regionId, tile.x, tile.y, tile.z, tile.url,
              tile.localPath || null, tile.size,
              tile.downloadedAt.toISOString(), tile.lastAccessed.toISOString()
            ]
          );
        });
      }, reject, resolve);
    });
  }

  /**
   * معالجة قائمة انتظار التنزيل
   */
  private async processDownloadQueue(regionId: string): Promise<void> {
    if (this.isDownloading) return;
    
    this.isDownloading = true;
    const tiles = await this.getRegionTiles(regionId, false); // البلاطات غير المحملة فقط
    
    for (const tile of tiles) {
      if (this.activeDownloads >= this.maxConcurrentDownloads) {
        await new Promise(resolve => setTimeout(resolve, 100));
        continue;
      }
      
      this.downloadTile(tile, regionId);
    }
  }

  /**
   * تنزيل بلاطة واحدة
   */
  private async downloadTile(tile: MapTile, regionId: string): Promise<void> {
    this.activeDownloads++;
    
    try {
      const fileName = `${tile.z}_${tile.x}_${tile.y}.png`;
      const localPath = `${this.mapDirectory}/${regionId}/${fileName}`;
      
      // إنشاء مجلد المنطقة إذا لم يكن موجوداً
      const regionDir = `${this.mapDirectory}/${regionId}`;
      if (!await RNFS.exists(regionDir)) {
        await RNFS.mkdir(regionDir);
      }
      
      // تنزيل البلاطة
      const downloadResult = await RNFS.downloadFile({
        fromUrl: tile.url,
        toFile: localPath,
      }).promise;
      
      if (downloadResult.statusCode === 200) {
        // تحديث معلومات البلاطة
        const fileInfo = await RNFS.stat(localPath);
        await this.updateTileInfo(tile.id, localPath, fileInfo.size);
        
        // تحديث إحصائيات المنطقة
        await this.updateRegionProgress(regionId);
        
        // إشعار المستمعين
        this.notifyProgressListeners(regionId);
      }
    } catch (error) {
      console.error('خطأ في تنزيل البلاطة:', error);
    } finally {
      this.activeDownloads--;
    }
  }

  /**
   * تحديث معلومات البلاطة
   */
  private async updateTileInfo(tileId: string, localPath: string, size: number): Promise<void> {
    if (!this.db) return;

    return new Promise((resolve, reject) => {
      this.db!.executeSql(
        'UPDATE tiles SET local_path = ?, size = ?, downloaded_at = ? WHERE id = ?',
        [localPath, size, new Date().toISOString(), tileId],
        () => resolve(),
        reject
      );
    });
  }

  /**
   * تحديث تقدم المنطقة
   */
  private async updateRegionProgress(regionId: string): Promise<void> {
    if (!this.db) return;

    return new Promise((resolve, reject) => {
      this.db!.executeSql(
        `UPDATE regions SET 
          downloaded_tiles = (SELECT COUNT(*) FROM tiles WHERE region_id = ? AND local_path IS NOT NULL),
          downloaded_size = (SELECT COALESCE(SUM(size), 0) FROM tiles WHERE region_id = ? AND local_path IS NOT NULL),
          updated_at = ?
        WHERE id = ?`,
        [regionId, regionId, new Date().toISOString(), regionId],
        () => resolve(),
        reject
      );
    });
  }

  /**
   * تحديث حالة المنطقة
   */
  private async updateRegionStatus(regionId: string, status: string): Promise<void> {
    if (!this.db) return;

    return new Promise((resolve, reject) => {
      this.db!.executeSql(
        'UPDATE regions SET status = ?, updated_at = ? WHERE id = ?',
        [status, new Date().toISOString(), regionId],
        () => resolve(),
        reject
      );
    });
  }

  /**
   * الحصول على بلاطات المنطقة
   */
  private async getRegionTiles(regionId: string, downloadedOnly: boolean = true): Promise<MapTile[]> {
    if (!this.db) return [];

    const whereClause = downloadedOnly 
      ? 'WHERE region_id = ? AND local_path IS NOT NULL'
      : 'WHERE region_id = ? AND local_path IS NULL';

    return new Promise((resolve, reject) => {
      this.db!.executeSql(
        `SELECT * FROM tiles ${whereClause}`,
        [regionId],
        (tx, results) => {
          const tiles: MapTile[] = [];
          for (let i = 0; i < results.rows.length; i++) {
            const row = results.rows.item(i);
            tiles.push({
              id: row.id,
              x: row.x,
              y: row.y,
              z: row.z,
              url: row.url,
              localPath: row.local_path,
              size: row.size,
              downloadedAt: new Date(row.downloaded_at),
              lastAccessed: new Date(row.last_accessed),
            });
          }
          resolve(tiles);
        },
        reject
      );
    });
  }

  /**
   * تحديث وقت آخر وصول للبلاطة
   */
  private async updateTileAccess(x: number, y: number, z: number): Promise<void> {
    if (!this.db) return;

    this.db.executeSql(
      'UPDATE tiles SET last_accessed = ? WHERE x = ? AND y = ? AND z = ?',
      [new Date().toISOString(), x, y, z]
    );
  }

  /**
   * تحويل صف قاعدة البيانات إلى كائن منطقة
   */
  private parseRegionFromRow(row: any): MapRegion {
    return {
      id: row.id,
      name: row.name,
      description: row.description,
      bounds: {
        north: row.bounds_north,
        south: row.bounds_south,
        east: row.bounds_east,
        west: row.bounds_west,
      },
      minZoom: row.min_zoom,
      maxZoom: row.max_zoom,
      tileCount: row.tile_count,
      downloadedTiles: row.downloaded_tiles,
      totalSize: row.total_size,
      downloadedSize: row.downloaded_size,
      status: row.status,
      createdAt: new Date(row.created_at),
      updatedAt: new Date(row.updated_at),
      expiresAt: row.expires_at ? new Date(row.expires_at) : undefined,
    };
  }

  /**
   * إشعار مستمعي التقدم
   */
  private notifyProgressListeners(regionId: string): void {
    // تحديث إحصائيات التنزيل وإشعار المستمعين
    // يمكن تنفيذ هذا بشكل أكثر تفصيلاً حسب الحاجة
  }
}

export default new OfflineMapService();

