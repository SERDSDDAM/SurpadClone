import { Platform, PermissionsAndroid } from 'react-native';
import { accelerometer, gyroscope, magnetometer } from 'react-native-sensors';

export interface ARPoint {
  id: string;
  latitude: number;
  longitude: number;
  altitude: number;
  label: string;
  type: 'survey_point' | 'boundary' | 'reference' | 'building';
  color: string;
  size: number;
  visible: boolean;
  distance?: number;
  bearing?: number;
}

export interface DeviceOrientation {
  azimuth: number; // الاتجاه (0-360 درجة)
  pitch: number;   // الميل للأمام/الخلف (-90 إلى 90 درجة)
  roll: number;    // الميل لليسار/اليمين (-180 إلى 180 درجة)
}

export interface DeviceLocation {
  latitude: number;
  longitude: number;
  altitude: number;
  accuracy: number;
}

class ARService {
  private isInitialized = false;
  private deviceOrientation: DeviceOrientation = { azimuth: 0, pitch: 0, roll: 0 };
  private deviceLocation: DeviceLocation | null = null;
  private arPoints: ARPoint[] = [];
  private orientationSubscription: any = null;
  private accelerometerSubscription: any = null;
  private gyroscopeSubscription: any = null;
  private magnetometerSubscription: any = null;

  /**
   * تهيئة خدمة الواقع المعزز
   */
  async initialize(): Promise<boolean> {
    try {
      // طلب الصلاحيات المطلوبة
      const hasPermissions = await this.requestPermissions();
      if (!hasPermissions) {
        throw new Error('لا توجد صلاحيات مطلوبة للواقع المعزز');
      }

      // بدء مراقبة اتجاه الجهاز
      this.startOrientationTracking();

      this.isInitialized = true;
      return true;
    } catch (error) {
      console.error('خطأ في تهيئة خدمة الواقع المعزز:', error);
      return false;
    }
  }

  /**
   * طلب الصلاحيات المطلوبة
   */
  private async requestPermissions(): Promise<boolean> {
    try {
      if (Platform.OS === 'android') {
        const permissions = [
          PermissionsAndroid.PERMISSIONS.CAMERA,
          PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
        ];

        const granted = await PermissionsAndroid.requestMultiple(permissions);
        
        return Object.values(granted).every(
          permission => permission === PermissionsAndroid.RESULTS.GRANTED
        );
      }
      return true; // iOS handles permissions automatically
    } catch (error) {
      console.error('خطأ في طلب الصلاحيات:', error);
      return false;
    }
  }

  /**
   * بدء مراقبة اتجاه الجهاز
   */
  private startOrientationTracking(): void {
    // مراقبة مقياس التسارع
    this.accelerometerSubscription = accelerometer.subscribe(({ x, y, z }) => {
      // حساب الميل (pitch) والدوران (roll)
      const pitch = Math.atan2(-x, Math.sqrt(y * y + z * z)) * (180 / Math.PI);
      const roll = Math.atan2(y, z) * (180 / Math.PI);
      
      this.deviceOrientation.pitch = pitch;
      this.deviceOrientation.roll = roll;
    });

    // مراقبة الجيروسكوب
    this.gyroscopeSubscription = gyroscope.subscribe(({ x, y, z }) => {
      // يمكن استخدام بيانات الجيروسكوب لتحسين دقة الاتجاه
      // هنا يمكن إضافة خوارزميات تصفية للحصول على قراءات أكثر استقرارًا
    });

    // مراقبة المغناطيس (البوصلة)
    this.magnetometerSubscription = magnetometer.subscribe(({ x, y, z }) => {
      // حساب الاتجاه المغناطيسي (azimuth)
      const azimuth = Math.atan2(y, x) * (180 / Math.PI);
      this.deviceOrientation.azimuth = azimuth < 0 ? azimuth + 360 : azimuth;
    });
  }

  /**
   * إيقاف مراقبة اتجاه الجهاز
   */
  private stopOrientationTracking(): void {
    if (this.accelerometerSubscription) {
      this.accelerometerSubscription.unsubscribe();
      this.accelerometerSubscription = null;
    }
    
    if (this.gyroscopeSubscription) {
      this.gyroscopeSubscription.unsubscribe();
      this.gyroscopeSubscription = null;
    }
    
    if (this.magnetometerSubscription) {
      this.magnetometerSubscription.unsubscribe();
      this.magnetometerSubscription = null;
    }
  }

  /**
   * تحديث موقع الجهاز
   */
  updateDeviceLocation(location: DeviceLocation): void {
    this.deviceLocation = location;
    this.updatePointsVisibility();
  }

  /**
   * إضافة نقطة AR
   */
  addARPoint(point: ARPoint): void {
    const existingIndex = this.arPoints.findIndex(p => p.id === point.id);
    
    if (existingIndex >= 0) {
      this.arPoints[existingIndex] = point;
    } else {
      this.arPoints.push(point);
    }
    
    this.updatePointsVisibility();
  }

  /**
   * إزالة نقطة AR
   */
  removeARPoint(pointId: string): void {
    this.arPoints = this.arPoints.filter(p => p.id !== pointId);
  }

  /**
   * مسح جميع نقاط AR
   */
  clearARPoints(): void {
    this.arPoints = [];
  }

  /**
   * حساب المسافة بين نقطتين جغرافيتين
   */
  private calculateDistance(
    lat1: number, lon1: number, alt1: number,
    lat2: number, lon2: number, alt2: number
  ): number {
    const R = 6371000; // نصف قطر الأرض بالمتر
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
      Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    const horizontalDistance = R * c;
    
    // إضافة المسافة الرأسية
    const verticalDistance = Math.abs(alt2 - alt1);
    
    return Math.sqrt(horizontalDistance * horizontalDistance + verticalDistance * verticalDistance);
  }

  /**
   * حساب الاتجاه إلى نقطة
   */
  private calculateBearing(
    lat1: number, lon1: number,
    lat2: number, lon2: number
  ): number {
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const lat1Rad = lat1 * Math.PI / 180;
    const lat2Rad = lat2 * Math.PI / 180;
    
    const y = Math.sin(dLon) * Math.cos(lat2Rad);
    const x = Math.cos(lat1Rad) * Math.sin(lat2Rad) - 
              Math.sin(lat1Rad) * Math.cos(lat2Rad) * Math.cos(dLon);
    
    let bearing = Math.atan2(y, x) * 180 / Math.PI;
    return bearing < 0 ? bearing + 360 : bearing;
  }

  /**
   * تحديث رؤية النقاط بناءً على الموقع والاتجاه
   */
  private updatePointsVisibility(): void {
    if (!this.deviceLocation) return;

    const maxVisibleDistance = 1000; // أقصى مسافة للعرض (1 كم)
    const fieldOfView = 60; // زاوية الرؤية (درجة)

    this.arPoints.forEach(point => {
      // حساب المسافة
      const distance = this.calculateDistance(
        this.deviceLocation!.latitude, this.deviceLocation!.longitude, this.deviceLocation!.altitude,
        point.latitude, point.longitude, point.altitude
      );

      // حساب الاتجاه
      const bearing = this.calculateBearing(
        this.deviceLocation!.latitude, this.deviceLocation!.longitude,
        point.latitude, point.longitude
      );

      // تحديث بيانات النقطة
      point.distance = distance;
      point.bearing = bearing;

      // تحديد الرؤية بناءً على المسافة والاتجاه
      const withinDistance = distance <= maxVisibleDistance;
      const withinFieldOfView = this.isWithinFieldOfView(bearing, fieldOfView);
      
      point.visible = withinDistance && withinFieldOfView;
    });
  }

  /**
   * التحقق من وجود النقطة ضمن مجال الرؤية
   */
  private isWithinFieldOfView(bearing: number, fieldOfView: number): boolean {
    const deviceAzimuth = this.deviceOrientation.azimuth;
    const halfFOV = fieldOfView / 2;
    
    let angleDiff = Math.abs(bearing - deviceAzimuth);
    if (angleDiff > 180) {
      angleDiff = 360 - angleDiff;
    }
    
    return angleDiff <= halfFOV;
  }

  /**
   * حساب الموضع على الشاشة لنقطة AR
   */
  calculateScreenPosition(
    point: ARPoint,
    screenWidth: number,
    screenHeight: number
  ): { x: number; y: number; scale: number } | null {
    if (!point.visible || !this.deviceLocation || !point.distance || point.bearing === undefined) {
      return null;
    }

    // حساب الموضع الأفقي بناءً على الاتجاه
    const deviceAzimuth = this.deviceOrientation.azimuth;
    const fieldOfView = 60; // زاوية الرؤية الأفقية
    
    let bearingDiff = point.bearing - deviceAzimuth;
    if (bearingDiff > 180) bearingDiff -= 360;
    if (bearingDiff < -180) bearingDiff += 360;
    
    const x = screenWidth / 2 + (bearingDiff / fieldOfView) * screenWidth;

    // حساب الموضع الرأسي بناءً على الارتفاع والميل
    const altitudeDiff = point.altitude - this.deviceLocation.altitude;
    const verticalAngle = Math.atan2(altitudeDiff, point.distance) * (180 / Math.PI);
    const adjustedVerticalAngle = verticalAngle - this.deviceOrientation.pitch;
    
    const verticalFOV = 45; // زاوية الرؤية الرأسية
    const y = screenHeight / 2 - (adjustedVerticalAngle / verticalFOV) * screenHeight;

    // حساب المقياس بناءً على المسافة
    const maxDistance = 1000;
    const minScale = 0.3;
    const maxScale = 1.0;
    const scale = maxScale - ((point.distance / maxDistance) * (maxScale - minScale));

    return {
      x: Math.max(0, Math.min(screenWidth, x)),
      y: Math.max(0, Math.min(screenHeight, y)),
      scale: Math.max(minScale, Math.min(maxScale, scale))
    };
  }

  /**
   * الحصول على النقاط المرئية
   */
  getVisiblePoints(): ARPoint[] {
    return this.arPoints.filter(point => point.visible);
  }

  /**
   * الحصول على اتجاه الجهاز الحالي
   */
  getDeviceOrientation(): DeviceOrientation {
    return { ...this.deviceOrientation };
  }

  /**
   * الحصول على جميع النقاط
   */
  getAllPoints(): ARPoint[] {
    return [...this.arPoints];
  }

  /**
   * التحقق من حالة التهيئة
   */
  isReady(): boolean {
    return this.isInitialized;
  }

  /**
   * تنظيف الموارد
   */
  cleanup(): void {
    this.stopOrientationTracking();
    this.arPoints = [];
    this.deviceLocation = null;
    this.isInitialized = false;
  }

  /**
   * معايرة البوصلة
   */
  calibrateCompass(): void {
    // يمكن إضافة خوارزمية معايرة البوصلة هنا
    // عادة ما تتطلب من المستخدم تحريك الجهاز في شكل رقم 8
    console.log('بدء معايرة البوصلة...');
  }

  /**
   * تصفية البيانات للحصول على قراءات أكثر استقرارًا
   */
  private filterOrientation(newOrientation: DeviceOrientation): DeviceOrientation {
    const alpha = 0.8; // عامل التصفية (0-1)
    
    return {
      azimuth: alpha * this.deviceOrientation.azimuth + (1 - alpha) * newOrientation.azimuth,
      pitch: alpha * this.deviceOrientation.pitch + (1 - alpha) * newOrientation.pitch,
      roll: alpha * this.deviceOrientation.roll + (1 - alpha) * newOrientation.roll,
    };
  }
}

export default new ARService();

