import RNFS from 'react-native-fs';
import Share from 'react-native-share';
import { Alert } from 'react-native';

export interface ReportData {
  id: string;
  title: string;
  subtitle?: string;
  date: Date;
  author: string;
  organization?: string;
  surveyPoints: SurveyPoint[];
  measurements: Measurement[];
  images: ReportImage[];
  notes: string[];
  metadata: Record<string, any>;
}

export interface SurveyPoint {
  id: string;
  name: string;
  latitude: number;
  longitude: number;
  altitude?: number;
  accuracy?: number;
  type: string;
  description?: string;
  timestamp: Date;
  attributes: Record<string, any>;
}

export interface Measurement {
  id: string;
  type: 'distance' | 'area' | 'angle' | 'elevation';
  value: number;
  unit: string;
  points: string[]; // IDs of related points
  description?: string;
  accuracy?: number;
  timestamp: Date;
}

export interface ReportImage {
  id: string;
  path: string;
  caption?: string;
  location?: {
    latitude: number;
    longitude: number;
  };
  timestamp: Date;
  size: {
    width: number;
    height: number;
  };
}

export interface ReportTemplate {
  id: string;
  name: string;
  description?: string;
  sections: ReportSection[];
  style: ReportStyle;
  isDefault: boolean;
}

export interface ReportSection {
  id: string;
  title: string;
  type: 'header' | 'summary' | 'points' | 'measurements' | 'images' | 'map' | 'notes' | 'custom';
  content?: string;
  includeData: boolean;
  options: Record<string, any>;
}

export interface ReportStyle {
  fontSize: number;
  fontFamily: string;
  primaryColor: string;
  secondaryColor: string;
  headerStyle: 'simple' | 'detailed' | 'logo';
  pageLayout: 'portrait' | 'landscape';
  margins: {
    top: number;
    bottom: number;
    left: number;
    right: number;
  };
  includePageNumbers: boolean;
  includeWatermark: boolean;
  watermarkText?: string;
}

export interface ReportOptions {
  format: 'PDF' | 'HTML' | 'DOCX' | 'CSV';
  template: string;
  includeImages: boolean;
  includeMap: boolean;
  includeCoordinates: boolean;
  coordinateFormat: 'decimal' | 'dms';
  language: 'ar' | 'en';
  customSections?: ReportSection[];
}

class ReportService {
  private templates: ReportTemplate[] = [];
  private reportsDirectory: string;

  constructor() {
    this.reportsDirectory = `${RNFS.DocumentDirectoryPath}/reports`;
    this.initializeService();
  }

  /**
   * تهيئة خدمة التقارير
   */
  private async initializeService(): Promise<void> {
    try {
      // إنشاء مجلد التقارير
      const exists = await RNFS.exists(this.reportsDirectory);
      if (!exists) {
        await RNFS.mkdir(this.reportsDirectory);
      }

      // تحميل القوالب الافتراضية
      this.loadDefaultTemplates();
      
      console.log('تم تهيئة خدمة التقارير');
    } catch (error) {
      console.error('خطأ في تهيئة خدمة التقارير:', error);
    }
  }

  /**
   * تحميل القوالب الافتراضية
   */
  private loadDefaultTemplates(): void {
    this.templates = [
      {
        id: 'basic_survey',
        name: 'تقرير مسح أساسي',
        description: 'قالب أساسي لتقارير المسح يتضمن النقاط والقياسات',
        isDefault: true,
        sections: [
          {
            id: 'header',
            title: 'رأس التقرير',
            type: 'header',
            includeData: true,
            options: { includeDate: true, includeAuthor: true },
          },
          {
            id: 'summary',
            title: 'ملخص المشروع',
            type: 'summary',
            includeData: true,
            options: { includeStats: true },
          },
          {
            id: 'points',
            title: 'نقاط المسح',
            type: 'points',
            includeData: true,
            options: { includeCoordinates: true, includeAccuracy: true },
          },
          {
            id: 'measurements',
            title: 'القياسات',
            type: 'measurements',
            includeData: true,
            options: { groupByType: true },
          },
          {
            id: 'map',
            title: 'خريطة الموقع',
            type: 'map',
            includeData: true,
            options: { showScale: true, showNorth: true },
          },
        ],
        style: {
          fontSize: 12,
          fontFamily: 'Arial',
          primaryColor: '#2196F3',
          secondaryColor: '#757575',
          headerStyle: 'detailed',
          pageLayout: 'portrait',
          margins: { top: 20, bottom: 20, left: 20, right: 20 },
          includePageNumbers: true,
          includeWatermark: false,
        },
      },
      {
        id: 'detailed_survey',
        name: 'تقرير مسح مفصل',
        description: 'قالب شامل يتضمن جميع البيانات والصور',
        isDefault: false,
        sections: [
          {
            id: 'header',
            title: 'رأس التقرير',
            type: 'header',
            includeData: true,
            options: { includeDate: true, includeAuthor: true, includeLogo: true },
          },
          {
            id: 'summary',
            title: 'ملخص تنفيذي',
            type: 'summary',
            includeData: true,
            options: { includeStats: true, includeObjectives: true },
          },
          {
            id: 'points',
            title: 'تفاصيل نقاط المسح',
            type: 'points',
            includeData: true,
            options: { 
              includeCoordinates: true, 
              includeAccuracy: true,
              includeAttributes: true,
              groupByType: true 
            },
          },
          {
            id: 'measurements',
            title: 'القياسات والحسابات',
            type: 'measurements',
            includeData: true,
            options: { groupByType: true, includeFormulas: true },
          },
          {
            id: 'images',
            title: 'الصور والوثائق',
            type: 'images',
            includeData: true,
            options: { includeLocation: true, includeTimestamp: true },
          },
          {
            id: 'map',
            title: 'الخرائط والرسوم',
            type: 'map',
            includeData: true,
            options: { 
              showScale: true, 
              showNorth: true,
              showGrid: true,
              showLabels: true 
            },
          },
          {
            id: 'notes',
            title: 'ملاحظات وتوصيات',
            type: 'notes',
            includeData: true,
            options: { includeRecommendations: true },
          },
        ],
        style: {
          fontSize: 11,
          fontFamily: 'Arial',
          primaryColor: '#1976D2',
          secondaryColor: '#424242',
          headerStyle: 'logo',
          pageLayout: 'portrait',
          margins: { top: 25, bottom: 25, left: 25, right: 25 },
          includePageNumbers: true,
          includeWatermark: true,
          watermarkText: 'تقرير مسح - سري',
        },
      },
      {
        id: 'summary_report',
        name: 'تقرير ملخص',
        description: 'تقرير مختصر للعرض السريع',
        isDefault: false,
        sections: [
          {
            id: 'header',
            title: 'رأس التقرير',
            type: 'header',
            includeData: true,
            options: { includeDate: true },
          },
          {
            id: 'summary',
            title: 'الملخص',
            type: 'summary',
            includeData: true,
            options: { includeStats: true },
          },
          {
            id: 'map',
            title: 'نظرة عامة',
            type: 'map',
            includeData: true,
            options: { showScale: false, showNorth: true },
          },
        ],
        style: {
          fontSize: 14,
          fontFamily: 'Arial',
          primaryColor: '#4CAF50',
          secondaryColor: '#666666',
          headerStyle: 'simple',
          pageLayout: 'landscape',
          margins: { top: 15, bottom: 15, left: 15, right: 15 },
          includePageNumbers: false,
          includeWatermark: false,
        },
      },
    ];
  }

  /**
   * إنشاء تقرير جديد
   */
  async generateReport(
    data: ReportData,
    options: ReportOptions
  ): Promise<string> {
    try {
      const template = this.getTemplate(options.template);
      if (!template) {
        throw new Error('القالب غير موجود');
      }

      let reportContent: string;
      
      switch (options.format) {
        case 'PDF':
          reportContent = await this.generatePDFReport(data, template, options);
          break;
        case 'HTML':
          reportContent = await this.generateHTMLReport(data, template, options);
          break;
        case 'DOCX':
          reportContent = await this.generateDOCXReport(data, template, options);
          break;
        case 'CSV':
          reportContent = await this.generateCSVReport(data, options);
          break;
        default:
          throw new Error('تنسيق التقرير غير مدعوم');
      }

      // حفظ التقرير
      const fileName = this.generateFileName(data.title, options.format);
      const filePath = `${this.reportsDirectory}/${fileName}`;
      
      await RNFS.writeFile(filePath, reportContent, 'utf8');
      
      return filePath;
    } catch (error) {
      throw new Error(`فشل في إنشاء التقرير: ${error.message}`);
    }
  }

  /**
   * مشاركة التقرير
   */
  async shareReport(filePath: string, title: string): Promise<void> {
    try {
      const fileExists = await RNFS.exists(filePath);
      if (!fileExists) {
        throw new Error('ملف التقرير غير موجود');
      }

      await Share.open({
        url: `file://${filePath}`,
        title: `مشاركة تقرير: ${title}`,
        message: `تقرير المسح: ${title}`,
      });
    } catch (error) {
      if (error.message !== 'User did not share') {
        throw new Error(`فشل في مشاركة التقرير: ${error.message}`);
      }
    }
  }

  /**
   * إنشاء تقرير PDF
   */
  private async generatePDFReport(
    data: ReportData,
    template: ReportTemplate,
    options: ReportOptions
  ): Promise<string> {
    // هنا يمكن استخدام مكتبة لإنشاء PDF
    // للتبسيط، سنقوم بإنشاء HTML ثم تحويله
    const htmlContent = await this.generateHTMLReport(data, template, options);
    
    // في التطبيق الحقيقي، يمكن استخدام مكتبة مثل react-native-html-to-pdf
    // أو إرسال HTML إلى خدمة ويب لتحويله إلى PDF
    
    return htmlContent; // مؤقتاً نعيد HTML
  }

  /**
   * إنشاء تقرير HTML
   */
  private async generateHTMLReport(
    data: ReportData,
    template: ReportTemplate,
    options: ReportOptions
  ): Promise<string> {
    const style = template.style;
    const isRTL = options.language === 'ar';
    
    let html = `
<!DOCTYPE html>
<html dir="${isRTL ? 'rtl' : 'ltr'}" lang="${options.language}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${data.title}</title>
    <style>
        body {
            font-family: ${style.fontFamily}, sans-serif;
            font-size: ${style.fontSize}px;
            color: #333;
            line-height: 1.6;
            margin: ${style.margins.top}mm ${style.margins.right}mm ${style.margins.bottom}mm ${style.margins.left}mm;
            direction: ${isRTL ? 'rtl' : 'ltr'};
        }
        
        .header {
            text-align: center;
            border-bottom: 2px solid ${style.primaryColor};
            padding-bottom: 20px;
            margin-bottom: 30px;
        }
        
        .header h1 {
            color: ${style.primaryColor};
            font-size: ${style.fontSize + 8}px;
            margin: 0;
        }
        
        .header h2 {
            color: ${style.secondaryColor};
            font-size: ${style.fontSize + 4}px;
            margin: 5px 0;
            font-weight: normal;
        }
        
        .header .meta {
            color: ${style.secondaryColor};
            font-size: ${style.fontSize - 1}px;
            margin-top: 10px;
        }
        
        .section {
            margin-bottom: 30px;
            page-break-inside: avoid;
        }
        
        .section-title {
            color: ${style.primaryColor};
            font-size: ${style.fontSize + 4}px;
            font-weight: bold;
            border-bottom: 1px solid ${style.primaryColor};
            padding-bottom: 5px;
            margin-bottom: 15px;
        }
        
        .summary-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin: 20px 0;
        }
        
        .stat-card {
            background: #f8f9fa;
            border: 1px solid #e9ecef;
            border-radius: 8px;
            padding: 15px;
            text-align: center;
        }
        
        .stat-number {
            font-size: ${style.fontSize + 6}px;
            font-weight: bold;
            color: ${style.primaryColor};
            display: block;
        }
        
        .stat-label {
            color: ${style.secondaryColor};
            font-size: ${style.fontSize - 1}px;
        }
        
        .points-table, .measurements-table {
            width: 100%;
            border-collapse: collapse;
            margin: 15px 0;
        }
        
        .points-table th, .points-table td,
        .measurements-table th, .measurements-table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: ${isRTL ? 'right' : 'left'};
        }
        
        .points-table th, .measurements-table th {
            background-color: ${style.primaryColor};
            color: white;
            font-weight: bold;
        }
        
        .points-table tr:nth-child(even),
        .measurements-table tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        
        .image-gallery {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin: 20px 0;
        }
        
        .image-item {
            text-align: center;
            page-break-inside: avoid;
        }
        
        .image-item img {
            max-width: 100%;
            height: auto;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        
        .image-caption {
            font-size: ${style.fontSize - 1}px;
            color: ${style.secondaryColor};
            margin-top: 5px;
        }
        
        .notes-list {
            list-style-type: disc;
            padding-${isRTL ? 'right' : 'left'}: 20px;
        }
        
        .notes-list li {
            margin-bottom: 8px;
        }
        
        .map-placeholder {
            width: 100%;
            height: 400px;
            background: #f0f0f0;
            border: 2px dashed #ccc;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #666;
            font-size: ${style.fontSize + 2}px;
        }
        
        .footer {
            margin-top: 50px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
            text-align: center;
            color: ${style.secondaryColor};
            font-size: ${style.fontSize - 1}px;
        }
        
        ${style.includeWatermark ? `
        .watermark {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%) rotate(-45deg);
            font-size: 48px;
            color: rgba(0, 0, 0, 0.1);
            z-index: -1;
            pointer-events: none;
        }
        ` : ''}
        
        @media print {
            body { margin: 0; }
            .section { page-break-inside: avoid; }
            .image-item { page-break-inside: avoid; }
        }
    </style>
</head>
<body>
`;

    // إضافة العلامة المائية
    if (style.includeWatermark && style.watermarkText) {
      html += `<div class="watermark">${style.watermarkText}</div>\n`;
    }

    // إنشاء محتوى كل قسم
    for (const section of template.sections) {
      if (!section.includeData) continue;
      
      html += await this.generateSectionHTML(section, data, options, style);
    }

    // إضافة التذييل
    html += `
    <div class="footer">
        <p>تم إنشاء هذا التقرير بواسطة تطبيق المساح في ${new Date().toLocaleDateString('ar-SA')}</p>
        ${style.includePageNumbers ? '<p>صفحة <span class="page-number"></span></p>' : ''}
    </div>
</body>
</html>`;

    return html;
  }

  /**
   * إنشاء HTML لقسم معين
   */
  private async generateSectionHTML(
    section: ReportSection,
    data: ReportData,
    options: ReportOptions,
    style: ReportStyle
  ): Promise<string> {
    let html = `<div class="section">\n`;
    html += `<h2 class="section-title">${section.title}</h2>\n`;

    switch (section.type) {
      case 'header':
        html += this.generateHeaderHTML(data, section.options);
        break;
      case 'summary':
        html += this.generateSummaryHTML(data, section.options);
        break;
      case 'points':
        html += this.generatePointsHTML(data, section.options, options);
        break;
      case 'measurements':
        html += this.generateMeasurementsHTML(data, section.options);
        break;
      case 'images':
        if (options.includeImages) {
          html += this.generateImagesHTML(data, section.options);
        }
        break;
      case 'map':
        if (options.includeMap) {
          html += this.generateMapHTML(data, section.options);
        }
        break;
      case 'notes':
        html += this.generateNotesHTML(data, section.options);
        break;
      case 'custom':
        html += section.content || '';
        break;
    }

    html += `</div>\n`;
    return html;
  }

  /**
   * إنشاء HTML لرأس التقرير
   */
  private generateHeaderHTML(data: ReportData, options: any): string {
    let html = '<div class="header">\n';
    html += `<h1>${data.title}</h1>\n`;
    
    if (data.subtitle) {
      html += `<h2>${data.subtitle}</h2>\n`;
    }
    
    html += '<div class="meta">\n';
    
    if (options.includeDate) {
      html += `<p><strong>التاريخ:</strong> ${data.date.toLocaleDateString('ar-SA')}</p>\n`;
    }
    
    if (options.includeAuthor) {
      html += `<p><strong>المساح:</strong> ${data.author}</p>\n`;
    }
    
    if (data.organization) {
      html += `<p><strong>المؤسسة:</strong> ${data.organization}</p>\n`;
    }
    
    html += '</div>\n';
    html += '</div>\n';
    
    return html;
  }

  /**
   * إنشاء HTML لملخص التقرير
   */
  private generateSummaryHTML(data: ReportData, options: any): string {
    let html = '';
    
    if (options.includeStats) {
      html += '<div class="summary-stats">\n';
      
      html += `
        <div class="stat-card">
          <span class="stat-number">${data.surveyPoints.length}</span>
          <span class="stat-label">نقاط المسح</span>
        </div>
      `;
      
      html += `
        <div class="stat-card">
          <span class="stat-number">${data.measurements.length}</span>
          <span class="stat-label">القياسات</span>
        </div>
      `;
      
      html += `
        <div class="stat-card">
          <span class="stat-number">${data.images.length}</span>
          <span class="stat-label">الصور</span>
        </div>
      `;
      
      // حساب المساحة الإجمالية
      const totalArea = data.measurements
        .filter(m => m.type === 'area')
        .reduce((sum, m) => sum + m.value, 0);
      
      if (totalArea > 0) {
        html += `
          <div class="stat-card">
            <span class="stat-number">${totalArea.toFixed(2)}</span>
            <span class="stat-label">المساحة الإجمالية (م²)</span>
          </div>
        `;
      }
      
      html += '</div>\n';
    }
    
    return html;
  }

  /**
   * إنشاء HTML لنقاط المسح
   */
  private generatePointsHTML(data: ReportData, sectionOptions: any, reportOptions: ReportOptions): string {
    let html = '<table class="points-table">\n';
    
    // رأس الجدول
    html += '<thead><tr>\n';
    html += '<th>الرقم</th>\n';
    html += '<th>الاسم</th>\n';
    html += '<th>النوع</th>\n';
    
    if (sectionOptions.includeCoordinates && reportOptions.includeCoordinates) {
      if (reportOptions.coordinateFormat === 'dms') {
        html += '<th>خط الطول</th>\n';
        html += '<th>خط العرض</th>\n';
      } else {
        html += '<th>خط الطول (عشري)</th>\n';
        html += '<th>خط العرض (عشري)</th>\n';
      }
      html += '<th>الارتفاع (م)</th>\n';
    }
    
    if (sectionOptions.includeAccuracy) {
      html += '<th>الدقة (م)</th>\n';
    }
    
    html += '<th>الوصف</th>\n';
    html += '</tr></thead>\n';
    
    // محتوى الجدول
    html += '<tbody>\n';
    
    data.surveyPoints.forEach((point, index) => {
      html += '<tr>\n';
      html += `<td>${index + 1}</td>\n`;
      html += `<td>${point.name}</td>\n`;
      html += `<td>${point.type}</td>\n`;
      
      if (sectionOptions.includeCoordinates && reportOptions.includeCoordinates) {
        if (reportOptions.coordinateFormat === 'dms') {
          html += `<td>${this.decimalToDMS(point.longitude, 'longitude')}</td>\n`;
          html += `<td>${this.decimalToDMS(point.latitude, 'latitude')}</td>\n`;
        } else {
          html += `<td>${point.longitude.toFixed(6)}</td>\n`;
          html += `<td>${point.latitude.toFixed(6)}</td>\n`;
        }
        html += `<td>${point.altitude?.toFixed(2) || 'غير محدد'}</td>\n`;
      }
      
      if (sectionOptions.includeAccuracy) {
        html += `<td>${point.accuracy?.toFixed(2) || 'غير محدد'}</td>\n`;
      }
      
      html += `<td>${point.description || ''}</td>\n`;
      html += '</tr>\n';
    });
    
    html += '</tbody>\n';
    html += '</table>\n';
    
    return html;
  }

  /**
   * إنشاء HTML للقياسات
   */
  private generateMeasurementsHTML(data: ReportData, options: any): string {
    let html = '<table class="measurements-table">\n';
    
    // رأس الجدول
    html += '<thead><tr>\n';
    html += '<th>الرقم</th>\n';
    html += '<th>النوع</th>\n';
    html += '<th>القيمة</th>\n';
    html += '<th>الوحدة</th>\n';
    html += '<th>الدقة</th>\n';
    html += '<th>الوصف</th>\n';
    html += '</tr></thead>\n';
    
    // محتوى الجدول
    html += '<tbody>\n';
    
    data.measurements.forEach((measurement, index) => {
      html += '<tr>\n';
      html += `<td>${index + 1}</td>\n`;
      html += `<td>${this.getMeasurementTypeText(measurement.type)}</td>\n`;
      html += `<td>${measurement.value.toFixed(3)}</td>\n`;
      html += `<td>${measurement.unit}</td>\n`;
      html += `<td>${measurement.accuracy?.toFixed(3) || 'غير محدد'}</td>\n`;
      html += `<td>${measurement.description || ''}</td>\n`;
      html += '</tr>\n';
    });
    
    html += '</tbody>\n';
    html += '</table>\n';
    
    return html;
  }

  /**
   * إنشاء HTML للصور
   */
  private generateImagesHTML(data: ReportData, options: any): string {
    if (data.images.length === 0) {
      return '<p>لا توجد صور مرفقة.</p>\n';
    }
    
    let html = '<div class="image-gallery">\n';
    
    data.images.forEach((image, index) => {
      html += '<div class="image-item">\n';
      html += `<img src="${image.path}" alt="صورة ${index + 1}" />\n`;
      
      let caption = `صورة ${index + 1}`;
      if (image.caption) {
        caption += `: ${image.caption}`;
      }
      
      if (options.includeTimestamp) {
        caption += ` (${image.timestamp.toLocaleDateString('ar-SA')})`;
      }
      
      if (options.includeLocation && image.location) {
        caption += ` - الموقع: ${image.location.latitude.toFixed(6)}, ${image.location.longitude.toFixed(6)}`;
      }
      
      html += `<div class="image-caption">${caption}</div>\n`;
      html += '</div>\n';
    });
    
    html += '</div>\n';
    
    return html;
  }

  /**
   * إنشاء HTML للخريطة
   */
  private generateMapHTML(data: ReportData, options: any): string {
    // في التطبيق الحقيقي، يمكن إنشاء صورة خريطة أو استخدام خدمة خرائط
    let html = '<div class="map-placeholder">\n';
    html += 'خريطة الموقع\n';
    html += `<br>عدد النقاط: ${data.surveyPoints.length}\n`;
    html += '</div>\n';
    
    if (options.showScale) {
      html += '<p><strong>مقياس الرسم:</strong> 1:1000</p>\n';
    }
    
    if (options.showNorth) {
      html += '<p><strong>الاتجاه:</strong> الشمال في الأعلى</p>\n';
    }
    
    return html;
  }

  /**
   * إنشاء HTML للملاحظات
   */
  private generateNotesHTML(data: ReportData, options: any): string {
    if (data.notes.length === 0) {
      return '<p>لا توجد ملاحظات.</p>\n';
    }
    
    let html = '<ul class="notes-list">\n';
    
    data.notes.forEach(note => {
      html += `<li>${note}</li>\n`;
    });
    
    html += '</ul>\n';
    
    return html;
  }

  /**
   * إنشاء تقرير DOCX
   */
  private async generateDOCXReport(
    data: ReportData,
    template: ReportTemplate,
    options: ReportOptions
  ): Promise<string> {
    // في التطبيق الحقيقي، يمكن استخدام مكتبة لإنشاء DOCX
    // للتبسيط، سنقوم بإنشاء HTML
    return await this.generateHTMLReport(data, template, options);
  }

  /**
   * إنشاء تقرير CSV
   */
  private async generateCSVReport(data: ReportData, options: ReportOptions): Promise<string> {
    let csv = '';
    
    // رأس CSV
    const headers = ['الرقم', 'الاسم', 'النوع', 'خط الطول', 'خط العرض', 'الارتفاع', 'الدقة', 'الوصف', 'التاريخ'];
    csv += headers.join(',') + '\n';
    
    // بيانات النقاط
    data.surveyPoints.forEach((point, index) => {
      const row = [
        index + 1,
        `"${point.name}"`,
        `"${point.type}"`,
        point.longitude.toFixed(6),
        point.latitude.toFixed(6),
        point.altitude?.toFixed(2) || '',
        point.accuracy?.toFixed(2) || '',
        `"${point.description || ''}"`,
        point.timestamp.toISOString(),
      ];
      csv += row.join(',') + '\n';
    });
    
    return csv;
  }

  /**
   * الحصول على قالب
   */
  private getTemplate(templateId: string): ReportTemplate | null {
    return this.templates.find(t => t.id === templateId) || null;
  }

  /**
   * إنشاء اسم الملف
   */
  private generateFileName(title: string, format: string): string {
    const cleanTitle = title.replace(/[^a-zA-Z0-9\u0600-\u06FF]/g, '_');
    const timestamp = new Date().toISOString().slice(0, 19).replace(/:/g, '-');
    return `${cleanTitle}_${timestamp}.${format.toLowerCase()}`;
  }

  /**
   * تحويل الإحداثيات العشرية إلى درجات ودقائق وثوان
   */
  private decimalToDMS(decimal: number, type: 'latitude' | 'longitude'): string {
    const abs = Math.abs(decimal);
    const degrees = Math.floor(abs);
    const minutes = Math.floor((abs - degrees) * 60);
    const seconds = ((abs - degrees) * 60 - minutes) * 60;
    
    const direction = type === 'latitude' 
      ? (decimal >= 0 ? 'شمال' : 'جنوب')
      : (decimal >= 0 ? 'شرق' : 'غرب');
    
    return `${degrees}° ${minutes}' ${seconds.toFixed(2)}" ${direction}`;
  }

  /**
   * الحصول على نص نوع القياس
   */
  private getMeasurementTypeText(type: string): string {
    switch (type) {
      case 'distance': return 'مسافة';
      case 'area': return 'مساحة';
      case 'angle': return 'زاوية';
      case 'elevation': return 'ارتفاع';
      default: return type;
    }
  }

  /**
   * الحصول على القوالب المتاحة
   */
  getAvailableTemplates(): ReportTemplate[] {
    return [...this.templates];
  }

  /**
   * إضافة قالب جديد
   */
  addTemplate(template: ReportTemplate): void {
    this.templates.push(template);
  }

  /**
   * تحديث قالب موجود
   */
  updateTemplate(templateId: string, updates: Partial<ReportTemplate>): boolean {
    const index = this.templates.findIndex(t => t.id === templateId);
    if (index !== -1) {
      this.templates[index] = { ...this.templates[index], ...updates };
      return true;
    }
    return false;
  }

  /**
   * حذف قالب
   */
  deleteTemplate(templateId: string): boolean {
    const index = this.templates.findIndex(t => t.id === templateId);
    if (index !== -1 && !this.templates[index].isDefault) {
      this.templates.splice(index, 1);
      return true;
    }
    return false;
  }

  /**
   * الحصول على التقارير المحفوظة
   */
  async getSavedReports(): Promise<string[]> {
    try {
      const files = await RNFS.readDir(this.reportsDirectory);
      return files
        .filter(file => file.isFile())
        .map(file => file.path)
        .sort((a, b) => b.localeCompare(a)); // ترتيب حسب التاريخ (الأحدث أولاً)
    } catch (error) {
      console.error('خطأ في قراءة التقارير المحفوظة:', error);
      return [];
    }
  }

  /**
   * حذف تقرير محفوظ
   */
  async deleteReport(filePath: string): Promise<void> {
    try {
      const exists = await RNFS.exists(filePath);
      if (exists) {
        await RNFS.unlink(filePath);
      }
    } catch (error) {
      throw new Error(`فشل في حذف التقرير: ${error.message}`);
    }
  }
}

export default new ReportService();

