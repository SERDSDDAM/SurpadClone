import { NativeModules, Platform, PermissionsAndroid } from 'react-native';
import BluetoothClassic from 'react-native-bluetooth-classic';

export interface BluetoothDevice {
  id: string;
  name: string;
  address: string;
  type: 'GNSS' | 'LASER' | 'UNKNOWN';
  connected: boolean;
  rssi?: number;
}

export interface GNSSData {
  latitude: number;
  longitude: number;
  altitude: number;
  accuracy: number;
  timestamp: Date;
  satellites: number;
  hdop: number; // Horizontal Dilution of Precision
  vdop: number; // Vertical Dilution of Precision
}

export interface LaserMeasurement {
  distance: number;
  angle?: number;
  timestamp: Date;
  accuracy: number;
  unit: 'meters' | 'feet';
}

class BluetoothService {
  private connectedDevices: Map<string, BluetoothDevice> = new Map();
  private dataListeners: Map<string, (data: any) => void> = new Map();

  /**
   * طلب صلاحيات البلوتوث
   */
  async requestBluetoothPermissions(): Promise<boolean> {
    try {
      if (Platform.OS === 'android') {
        const permissions = [
          PermissionsAndroid.PERMISSIONS.BLUETOOTH_SCAN,
          PermissionsAndroid.PERMISSIONS.BLUETOOTH_CONNECT,
          PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
        ];

        const granted = await PermissionsAndroid.requestMultiple(permissions);
        
        return Object.values(granted).every(
          permission => permission === PermissionsAndroid.RESULTS.GRANTED
        );
      }
      return true; // iOS handles permissions automatically
    } catch (error) {
      console.error('خطأ في طلب صلاحيات البلوتوث:', error);
      return false;
    }
  }

  /**
   * تفعيل البلوتوث
   */
  async enableBluetooth(): Promise<boolean> {
    try {
      const isEnabled = await BluetoothClassic.isBluetoothEnabled();
      if (!isEnabled) {
        return await BluetoothClassic.requestBluetoothEnabled();
      }
      return true;
    } catch (error) {
      console.error('خطأ في تفعيل البلوتوث:', error);
      return false;
    }
  }

  /**
   * البحث عن الأجهزة المتاحة
   */
  async scanForDevices(): Promise<BluetoothDevice[]> {
    try {
      const hasPermissions = await this.requestBluetoothPermissions();
      if (!hasPermissions) {
        throw new Error('لا توجد صلاحيات البلوتوث المطلوبة');
      }

      const isEnabled = await this.enableBluetooth();
      if (!isEnabled) {
        throw new Error('البلوتوث غير مفعل');
      }

      // البحث عن الأجهزة المقترنة
      const pairedDevices = await BluetoothClassic.getBondedDevices();
      
      // البحث عن أجهزة جديدة
      const discoveredDevices = await BluetoothClassic.startDiscovery();

      const allDevices = [...pairedDevices, ...discoveredDevices];
      
      return allDevices.map(device => ({
        id: device.id,
        name: device.name || 'جهاز غير معروف',
        address: device.address,
        type: this.detectDeviceType(device.name || ''),
        connected: false,
        rssi: device.rssi,
      }));
    } catch (error) {
      console.error('خطأ في البحث عن الأجهزة:', error);
      throw error;
    }
  }

  /**
   * تحديد نوع الجهاز بناءً على الاسم
   */
  private detectDeviceType(deviceName: string): 'GNSS' | 'LASER' | 'UNKNOWN' {
    const name = deviceName.toLowerCase();
    
    if (name.includes('gnss') || name.includes('gps') || name.includes('trimble') || 
        name.includes('leica') || name.includes('topcon')) {
      return 'GNSS';
    }
    
    if (name.includes('laser') || name.includes('disto') || name.includes('range')) {
      return 'LASER';
    }
    
    return 'UNKNOWN';
  }

  /**
   * الاتصال بجهاز
   */
  async connectToDevice(deviceId: string): Promise<boolean> {
    try {
      const device = await BluetoothClassic.connectToDevice(deviceId);
      
      if (device) {
        const bluetoothDevice: BluetoothDevice = {
          id: device.id,
          name: device.name || 'جهاز غير معروف',
          address: device.address,
          type: this.detectDeviceType(device.name || ''),
          connected: true,
        };
        
        this.connectedDevices.set(deviceId, bluetoothDevice);
        
        // بدء استقبال البيانات
        this.startDataReception(deviceId);
        
        return true;
      }
      
      return false;
    } catch (error) {
      console.error('خطأ في الاتصال بالجهاز:', error);
      return false;
    }
  }

  /**
   * قطع الاتصال مع جهاز
   */
  async disconnectFromDevice(deviceId: string): Promise<boolean> {
    try {
      await BluetoothClassic.disconnectFromDevice(deviceId);
      
      const device = this.connectedDevices.get(deviceId);
      if (device) {
        device.connected = false;
        this.connectedDevices.delete(deviceId);
      }
      
      // إيقاف استقبال البيانات
      this.dataListeners.delete(deviceId);
      
      return true;
    } catch (error) {
      console.error('خطأ في قطع الاتصال:', error);
      return false;
    }
  }

  /**
   * بدء استقبال البيانات من الجهاز
   */
  private startDataReception(deviceId: string): void {
    const device = this.connectedDevices.get(deviceId);
    if (!device) return;

    // إعداد مستمع البيانات
    BluetoothClassic.onDeviceRead(deviceId, (data: string) => {
      try {
        const parsedData = this.parseDeviceData(device.type, data);
        
        // إشعار المستمعين
        const listener = this.dataListeners.get(deviceId);
        if (listener) {
          listener(parsedData);
        }
      } catch (error) {
        console.error('خطأ في تحليل البيانات:', error);
      }
    });
  }

  /**
   * تحليل البيانات الواردة من الجهاز
   */
  private parseDeviceData(deviceType: string, rawData: string): GNSSData | LaserMeasurement | null {
    switch (deviceType) {
      case 'GNSS':
        return this.parseGNSSData(rawData);
      case 'LASER':
        return this.parseLaserData(rawData);
      default:
        return null;
    }
  }

  /**
   * تحليل بيانات GNSS (NMEA format)
   */
  private parseGNSSData(nmeaData: string): GNSSData | null {
    try {
      // تحليل جملة GPGGA (Global Positioning System Fix Data)
      const lines = nmeaData.split('\n');
      
      for (const line of lines) {
        if (line.startsWith('$GPGGA') || line.startsWith('$GNGGA')) {
          const parts = line.split(',');
          
          if (parts.length >= 15) {
            const latitude = this.parseCoordinate(parts[2], parts[3]);
            const longitude = this.parseCoordinate(parts[4], parts[5]);
            const altitude = parseFloat(parts[9]) || 0;
            const satellites = parseInt(parts[7]) || 0;
            const hdop = parseFloat(parts[8]) || 0;
            
            return {
              latitude,
              longitude,
              altitude,
              accuracy: hdop * 3, // تقدير تقريبي للدقة
              timestamp: new Date(),
              satellites,
              hdop,
              vdop: 0, // يحتاج جملة GPGSA للحصول على VDOP
            };
          }
        }
      }
      
      return null;
    } catch (error) {
      console.error('خطأ في تحليل بيانات GNSS:', error);
      return null;
    }
  }

  /**
   * تحويل الإحداثيات من تنسيق NMEA إلى عشري
   */
  private parseCoordinate(coordinate: string, direction: string): number {
    if (!coordinate || !direction) return 0;
    
    const degrees = parseInt(coordinate.substring(0, coordinate.indexOf('.') - 2));
    const minutes = parseFloat(coordinate.substring(coordinate.indexOf('.') - 2));
    
    let decimal = degrees + (minutes / 60);
    
    if (direction === 'S' || direction === 'W') {
      decimal = -decimal;
    }
    
    return decimal;
  }

  /**
   * تحليل بيانات جهاز قياس المسافات بالليزر
   */
  private parseLaserData(laserData: string): LaserMeasurement | null {
    try {
      // تنسيق افتراضي: "DIST:1.234m"
      const distanceMatch = laserData.match(/DIST:([\d.]+)([mf])/i);
      
      if (distanceMatch) {
        const distance = parseFloat(distanceMatch[1]);
        const unit = distanceMatch[2].toLowerCase() === 'm' ? 'meters' : 'feet';
        
        return {
          distance,
          timestamp: new Date(),
          accuracy: 0.001, // دقة 1 مم
          unit,
        };
      }
      
      return null;
    } catch (error) {
      console.error('خطأ في تحليل بيانات الليزر:', error);
      return null;
    }
  }

  /**
   * إرسال أمر إلى الجهاز
   */
  async sendCommand(deviceId: string, command: string): Promise<boolean> {
    try {
      const device = this.connectedDevices.get(deviceId);
      if (!device || !device.connected) {
        throw new Error('الجهاز غير متصل');
      }
      
      await BluetoothClassic.writeToDevice(deviceId, command);
      return true;
    } catch (error) {
      console.error('خطأ في إرسال الأمر:', error);
      return false;
    }
  }

  /**
   * تسجيل مستمع للبيانات
   */
  registerDataListener(deviceId: string, listener: (data: any) => void): void {
    this.dataListeners.set(deviceId, listener);
  }

  /**
   * إلغاء تسجيل مستمع البيانات
   */
  unregisterDataListener(deviceId: string): void {
    this.dataListeners.delete(deviceId);
  }

  /**
   * الحصول على الأجهزة المتصلة
   */
  getConnectedDevices(): BluetoothDevice[] {
    return Array.from(this.connectedDevices.values());
  }

  /**
   * التحقق من حالة اتصال جهاز
   */
  isDeviceConnected(deviceId: string): boolean {
    const device = this.connectedDevices.get(deviceId);
    return device ? device.connected : false;
  }

  /**
   * تنظيف الموارد
   */
  cleanup(): void {
    // قطع الاتصال مع جميع الأجهزة
    this.connectedDevices.forEach(async (device) => {
      if (device.connected) {
        await this.disconnectFromDevice(device.id);
      }
    });
    
    this.connectedDevices.clear();
    this.dataListeners.clear();
  }
}

export default new BluetoothService();

