/**
 * خدمة الاتصال بالواجهة الخلفية
 * Backend API Service
 */

import AsyncStorage from '@react-native-async-storage/async-storage';
import { Alert } from 'react-native';

export interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  message?: string;
  error?: string;
}

export interface LoginCredentials {
  username: string;
  password: string;
}

export interface UserProfile {
  id: string;
  username: string;
  email: string;
  fullName: string;
  role: string;
  permissions: string[];
  isActive: boolean;
}

export interface SurveyRequestData {
  title: string;
  location: string;
  description: string;
  coordinates?: {
    latitude: number;
    longitude: number;
  };
  priority: 'low' | 'medium' | 'high';
}

export interface SurveyRequestResponse {
  id: string;
  title: string;
  location: string;
  description: string;
  status: 'pending' | 'assigned' | 'in_progress' | 'completed' | 'rejected';
  priority: 'low' | 'medium' | 'high';
  createdAt: string;
  updatedAt: string;
  assignedSurveyor?: string;
  coordinates?: {
    latitude: number;
    longitude: number;
  };
}

class ApiService {
  private baseURL: string = 'http://localhost:5000/api'; // يجب تغييرها للإنتاج
  private authToken: string | null = null;
  private isOnline: boolean = true;

  constructor() {
    this.loadAuthToken();
  }

  /**
   * تحميل رمز المصادقة من التخزين المحلي
   */
  private async loadAuthToken(): Promise<void> {
    try {
      const token = await AsyncStorage.getItem('auth_token');
      this.authToken = token;
    } catch (error) {
      console.error('خطأ في تحميل رمز المصادقة:', error);
    }
  }

  /**
   * حفظ رمز المصادقة في التخزين المحلي
   */
  private async saveAuthToken(token: string): Promise<void> {
    try {
      this.authToken = token;
      await AsyncStorage.setItem('auth_token', token);
    } catch (error) {
      console.error('خطأ في حفظ رمز المصادقة:', error);
    }
  }

  /**
   * حذف رمز المصادقة
   */
  private async clearAuthToken(): Promise<void> {
    try {
      this.authToken = null;
      await AsyncStorage.removeItem('auth_token');
    } catch (error) {
      console.error('خطأ في حذف رمز المصادقة:', error);
    }
  }

  /**
   * إعداد رؤوس الطلب
   */
  private getHeaders(): HeadersInit {
    const headers: HeadersInit = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    };

    if (this.authToken) {
      headers['Authorization'] = `Bearer ${this.authToken}`;
    }

    return headers;
  }

  /**
   * إجراء طلب HTTP
   */
  private async makeRequest<T>(
    endpoint: string,
    options: RequestInit = {}
  ): Promise<ApiResponse<T>> {
    try {
      const url = `${this.baseURL}${endpoint}`;
      const response = await fetch(url, {
        ...options,
        headers: {
          ...this.getHeaders(),
          ...options.headers,
        },
        timeout: 30000, // 30 ثانية
      });

      const data = await response.json();

      if (!response.ok) {
        return {
          success: false,
          error: data.message || `HTTP ${response.status}: ${response.statusText}`,
        };
      }

      return {
        success: true,
        data: data.data || data,
        message: data.message,
      };
    } catch (error: any) {
      console.error('خطأ في الطلب:', error);
      
      // التحقق من حالة الاتصال
      if (error.name === 'TypeError' && error.message.includes('Network request failed')) {
        this.isOnline = false;
        return {
          success: false,
          error: 'لا يوجد اتصال بالإنترنت',
        };
      }

      return {
        success: false,
        error: error.message || 'حدث خطأ غير متوقع',
      };
    }
  }

  /**
   * تسجيل الدخول
   */
  async login(credentials: LoginCredentials): Promise<ApiResponse<{ user: UserProfile; token: string }>> {
    const response = await this.makeRequest<{ user: UserProfile; token: string }>('/auth/login', {
      method: 'POST',
      body: JSON.stringify(credentials),
    });

    if (response.success && response.data?.token) {
      await this.saveAuthToken(response.data.token);
      this.isOnline = true;
    }

    return response;
  }

  /**
   * تسجيل الخروج
   */
  async logout(): Promise<ApiResponse> {
    const response = await this.makeRequest('/auth/logout', {
      method: 'POST',
    });

    await this.clearAuthToken();
    return response;
  }

  /**
   * الحصول على الملف الشخصي
   */
  async getProfile(): Promise<ApiResponse<UserProfile>> {
    return this.makeRequest<UserProfile>('/auth/profile');
  }

  /**
   * الحصول على طلبات المسح
   */
  async getSurveyRequests(): Promise<ApiResponse<SurveyRequestResponse[]>> {
    return this.makeRequest<SurveyRequestResponse[]>('/surveys/requests');
  }

  /**
   * إنشاء طلب مسح جديد
   */
  async createSurveyRequest(data: SurveyRequestData): Promise<ApiResponse<SurveyRequestResponse>> {
    return this.makeRequest<SurveyRequestResponse>('/surveys/requests', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  /**
   * تحديث طلب مسح
   */
  async updateSurveyRequest(
    id: string,
    data: Partial<SurveyRequestData>
  ): Promise<ApiResponse<SurveyRequestResponse>> {
    return this.makeRequest<SurveyRequestResponse>(`/surveys/requests/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  }

  /**
   * الحصول على طلب مسح محدد
   */
  async getSurveyRequest(id: string): Promise<ApiResponse<SurveyRequestResponse>> {
    return this.makeRequest<SurveyRequestResponse>(`/surveys/requests/${id}`);
  }

  /**
   * رفع بيانات المسح
   */
  async uploadSurveyData(requestId: string, surveyData: any): Promise<ApiResponse> {
    return this.makeRequest(`/surveys/requests/${requestId}/data`, {
      method: 'POST',
      body: JSON.stringify(surveyData),
    });
  }

  /**
   * رفع صورة
   */
  async uploadImage(file: any, metadata?: any): Promise<ApiResponse<{ url: string }>> {
    const formData = new FormData();
    formData.append('image', file);
    
    if (metadata) {
      formData.append('metadata', JSON.stringify(metadata));
    }

    return this.makeRequest<{ url: string }>('/uploads/image', {
      method: 'POST',
      body: formData,
      headers: {
        'Authorization': this.authToken ? `Bearer ${this.authToken}` : '',
        // لا نضع Content-Type للـ FormData
      },
    });
  }

  /**
   * الحصول على الإحصائيات
   */
  async getStatistics(): Promise<ApiResponse<any>> {
    return this.makeRequest('/surveys/stats');
  }

  /**
   * فحص حالة الاتصال
   */
  async checkConnection(): Promise<boolean> {
    try {
      const response = await this.makeRequest('/health');
      this.isOnline = response.success;
      return response.success;
    } catch (error) {
      this.isOnline = false;
      return false;
    }
  }

  /**
   * الحصول على حالة الاتصال
   */
  getConnectionStatus(): boolean {
    return this.isOnline;
  }

  /**
   * التحقق من صحة رمز المصادقة
   */
  async validateToken(): Promise<boolean> {
    if (!this.authToken) return false;

    const response = await this.getProfile();
    return response.success;
  }

  /**
   * إعادة المحاولة مع التحقق من الاتصال
   */
  async retryWithConnectionCheck<T>(
    operation: () => Promise<ApiResponse<T>>,
    maxRetries: number = 3
  ): Promise<ApiResponse<T>> {
    let lastError: string = '';

    for (let i = 0; i < maxRetries; i++) {
      const isConnected = await this.checkConnection();
      
      if (!isConnected) {
        lastError = 'لا يوجد اتصال بالإنترنت';
        await new Promise(resolve => setTimeout(resolve, 2000)); // انتظار ثانيتين
        continue;
      }

      const result = await operation();
      if (result.success) {
        return result;
      }

      lastError = result.error || 'حدث خطأ غير متوقع';
      
      // إذا كان الخطأ متعلق بالمصادقة، لا نعيد المحاولة
      if (result.error?.includes('401') || result.error?.includes('Unauthorized')) {
        break;
      }

      await new Promise(resolve => setTimeout(resolve, 1000 * (i + 1))); // انتظار متزايد
    }

    return {
      success: false,
      error: lastError,
    };
  }

  /**
   * تحديث عنوان الخادم
   */
  setBaseURL(url: string): void {
    this.baseURL = url;
  }

  /**
   * الحصول على عنوان الخادم
   */
  getBaseURL(): string {
    return this.baseURL;
  }
}

export default new ApiService();

