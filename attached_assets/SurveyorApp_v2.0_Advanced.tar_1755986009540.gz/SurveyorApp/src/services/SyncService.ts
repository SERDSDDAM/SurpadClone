/**
 * خدمة المزامنة بين التطبيق والخادم
 * Synchronization Service
 */

import AsyncStorage from '@react-native-async-storage/async-storage';
import { Alert } from 'react-native';
import ApiService from './ApiService';
import DataCollectionService, { SurveyProject } from './DataCollectionService';

export interface SyncStatus {
  isOnline: boolean;
  lastSyncTime: Date | null;
  pendingUploads: number;
  pendingDownloads: number;
  isSyncing: boolean;
  syncErrors: string[];
}

export interface PendingUpload {
  id: string;
  type: 'project' | 'point' | 'photo' | 'note';
  projectId: string;
  data: any;
  timestamp: Date;
  retryCount: number;
}

class SyncService {
  private readonly SYNC_STATUS_KEY = 'sync_status';
  private readonly PENDING_UPLOADS_KEY = 'pending_uploads';
  private readonly LAST_SYNC_KEY = 'last_sync_time';
  
  private syncStatus: SyncStatus = {
    isOnline: false,
    lastSyncTime: null,
    pendingUploads: 0,
    pendingDownloads: 0,
    isSyncing: false,
    syncErrors: [],
  };

  private syncCallbacks: ((status: SyncStatus) => void)[] = [];
  private autoSyncInterval: NodeJS.Timeout | null = null;

  constructor() {
    this.loadSyncStatus();
    this.startAutoSync();
  }

  /**
   * تحميل حالة المزامنة من التخزين المحلي
   */
  private async loadSyncStatus(): Promise<void> {
    try {
      const statusData = await AsyncStorage.getItem(this.SYNC_STATUS_KEY);
      const lastSyncData = await AsyncStorage.getItem(this.LAST_SYNC_KEY);
      
      if (statusData) {
        const status = JSON.parse(statusData);
        this.syncStatus = {
          ...this.syncStatus,
          ...status,
          lastSyncTime: lastSyncData ? new Date(lastSyncData) : null,
        };
      }

      await this.updatePendingCounts();
    } catch (error) {
      console.error('خطأ في تحميل حالة المزامنة:', error);
    }
  }

  /**
   * حفظ حالة المزامنة
   */
  private async saveSyncStatus(): Promise<void> {
    try {
      await AsyncStorage.setItem(this.SYNC_STATUS_KEY, JSON.stringify({
        isOnline: this.syncStatus.isOnline,
        pendingUploads: this.syncStatus.pendingUploads,
        pendingDownloads: this.syncStatus.pendingDownloads,
        syncErrors: this.syncStatus.syncErrors,
      }));

      if (this.syncStatus.lastSyncTime) {
        await AsyncStorage.setItem(this.LAST_SYNC_KEY, this.syncStatus.lastSyncTime.toISOString());
      }
    } catch (error) {
      console.error('خطأ في حفظ حالة المزامنة:', error);
    }
  }

  /**
   * تحديث عدد العمليات المعلقة
   */
  private async updatePendingCounts(): Promise<void> {
    try {
      const pendingUploadsData = await AsyncStorage.getItem(this.PENDING_UPLOADS_KEY);
      const pendingUploads = pendingUploadsData ? JSON.parse(pendingUploadsData) : [];
      
      this.syncStatus.pendingUploads = pendingUploads.length;
      this.syncStatus.pendingDownloads = 0; // سيتم تحديثها لاحقاً
      
      this.notifyCallbacks();
    } catch (error) {
      console.error('خطأ في تحديث عدد العمليات المعلقة:', error);
    }
  }

  /**
   * إضافة عملية رفع معلقة
   */
  async addPendingUpload(upload: Omit<PendingUpload, 'id' | 'timestamp' | 'retryCount'>): Promise<void> {
    try {
      const pendingUploadsData = await AsyncStorage.getItem(this.PENDING_UPLOADS_KEY);
      const pendingUploads: PendingUpload[] = pendingUploadsData ? JSON.parse(pendingUploadsData) : [];
      
      const newUpload: PendingUpload = {
        ...upload,
        id: Date.now().toString(),
        timestamp: new Date(),
        retryCount: 0,
      };

      pendingUploads.push(newUpload);
      await AsyncStorage.setItem(this.PENDING_UPLOADS_KEY, JSON.stringify(pendingUploads));
      await this.updatePendingCounts();
    } catch (error) {
      console.error('خطأ في إضافة عملية رفع معلقة:', error);
    }
  }

  /**
   * إزالة عملية رفع معلقة
   */
  private async removePendingUpload(uploadId: string): Promise<void> {
    try {
      const pendingUploadsData = await AsyncStorage.getItem(this.PENDING_UPLOADS_KEY);
      const pendingUploads: PendingUpload[] = pendingUploadsData ? JSON.parse(pendingUploadsData) : [];
      
      const filteredUploads = pendingUploads.filter(upload => upload.id !== uploadId);
      await AsyncStorage.setItem(this.PENDING_UPLOADS_KEY, JSON.stringify(filteredUploads));
      await this.updatePendingCounts();
    } catch (error) {
      console.error('خطأ في إزالة عملية رفع معلقة:', error);
    }
  }

  /**
   * فحص حالة الاتصال
   */
  async checkConnectionStatus(): Promise<boolean> {
    const isOnline = await ApiService.checkConnection();
    this.syncStatus.isOnline = isOnline;
    this.notifyCallbacks();
    return isOnline;
  }

  /**
   * بدء المزامنة التلقائية
   */
  private startAutoSync(): void {
    // مزامنة كل 5 دقائق
    this.autoSyncInterval = setInterval(async () => {
      if (!this.syncStatus.isSyncing) {
        await this.syncAll();
      }
    }, 5 * 60 * 1000);
  }

  /**
   * إيقاف المزامنة التلقائية
   */
  stopAutoSync(): void {
    if (this.autoSyncInterval) {
      clearInterval(this.autoSyncInterval);
      this.autoSyncInterval = null;
    }
  }

  /**
   * مزامنة جميع البيانات
   */
  async syncAll(): Promise<boolean> {
    if (this.syncStatus.isSyncing) {
      return false;
    }

    this.syncStatus.isSyncing = true;
    this.syncStatus.syncErrors = [];
    this.notifyCallbacks();

    try {
      const isOnline = await this.checkConnectionStatus();
      if (!isOnline) {
        throw new Error('لا يوجد اتصال بالإنترنت');
      }

      // رفع البيانات المعلقة
      await this.uploadPendingData();

      // تنزيل البيانات الجديدة
      await this.downloadNewData();

      this.syncStatus.lastSyncTime = new Date();
      await this.saveSyncStatus();

      return true;
    } catch (error: any) {
      console.error('خطأ في المزامنة:', error);
      this.syncStatus.syncErrors.push(error.message || 'حدث خطأ في المزامنة');
      return false;
    } finally {
      this.syncStatus.isSyncing = false;
      this.notifyCallbacks();
    }
  }

  /**
   * رفع البيانات المعلقة
   */
  private async uploadPendingData(): Promise<void> {
    try {
      const pendingUploadsData = await AsyncStorage.getItem(this.PENDING_UPLOADS_KEY);
      const pendingUploads: PendingUpload[] = pendingUploadsData ? JSON.parse(pendingUploadsData) : [];

      for (const upload of pendingUploads) {
        try {
          await this.processUpload(upload);
          await this.removePendingUpload(upload.id);
        } catch (error: any) {
          console.error(`خطأ في رفع ${upload.type}:`, error);
          
          // زيادة عدد المحاولات
          upload.retryCount++;
          
          // إذا فشلت المحاولات أكثر من 3 مرات، احذف العملية
          if (upload.retryCount >= 3) {
            await this.removePendingUpload(upload.id);
            this.syncStatus.syncErrors.push(`فشل في رفع ${upload.type} بعد 3 محاولات`);
          }
        }
      }
    } catch (error) {
      console.error('خطأ في رفع البيانات المعلقة:', error);
    }
  }

  /**
   * معالجة عملية رفع واحدة
   */
  private async processUpload(upload: PendingUpload): Promise<void> {
    switch (upload.type) {
      case 'project':
        await this.uploadProject(upload.data);
        break;
      case 'point':
        await this.uploadSurveyPoint(upload.projectId, upload.data);
        break;
      case 'photo':
        await this.uploadPhoto(upload.projectId, upload.data);
        break;
      case 'note':
        await this.uploadNote(upload.projectId, upload.data);
        break;
      default:
        throw new Error(`نوع رفع غير مدعوم: ${upload.type}`);
    }
  }

  /**
   * رفع مشروع
   */
  private async uploadProject(projectData: SurveyProject): Promise<void> {
    const response = await ApiService.createSurveyRequest({
      title: projectData.name,
      location: projectData.location,
      description: projectData.description,
      priority: 'medium',
    });

    if (!response.success) {
      throw new Error(response.error || 'فشل في رفع المشروع');
    }
  }

  /**
   * رفع نقطة مسح
   */
  private async uploadSurveyPoint(projectId: string, pointData: any): Promise<void> {
    const response = await ApiService.uploadSurveyData(projectId, {
      type: 'point',
      data: pointData,
    });

    if (!response.success) {
      throw new Error(response.error || 'فشل في رفع النقطة');
    }
  }

  /**
   * رفع صورة
   */
  private async uploadPhoto(projectId: string, photoData: any): Promise<void> {
    const response = await ApiService.uploadImage(photoData.file, {
      projectId,
      location: photoData.location,
      description: photoData.description,
    });

    if (!response.success) {
      throw new Error(response.error || 'فشل في رفع الصورة');
    }
  }

  /**
   * رفع ملاحظة
   */
  private async uploadNote(projectId: string, noteData: any): Promise<void> {
    const response = await ApiService.uploadSurveyData(projectId, {
      type: 'note',
      data: noteData,
    });

    if (!response.success) {
      throw new Error(response.error || 'فشل في رفع الملاحظة');
    }
  }

  /**
   * تنزيل البيانات الجديدة
   */
  private async downloadNewData(): Promise<void> {
    try {
      // تنزيل طلبات المسح الجديدة
      const requestsResponse = await ApiService.getSurveyRequests();
      if (requestsResponse.success && requestsResponse.data) {
        // معالجة الطلبات الجديدة
        // يمكن إضافة منطق لحفظ الطلبات محلياً
      }

      // تنزيل الإحصائيات
      const statsResponse = await ApiService.getStatistics();
      if (statsResponse.success && statsResponse.data) {
        // حفظ الإحصائيات محلياً
        await AsyncStorage.setItem('server_stats', JSON.stringify(statsResponse.data));
      }
    } catch (error) {
      console.error('خطأ في تنزيل البيانات الجديدة:', error);
    }
  }

  /**
   * مزامنة مشروع محدد
   */
  async syncProject(projectId: string): Promise<boolean> {
    try {
      const project = await DataCollectionService.getProject(projectId);
      if (!project) {
        throw new Error('المشروع غير موجود');
      }

      const isOnline = await this.checkConnectionStatus();
      if (!isOnline) {
        // إضافة إلى قائمة الانتظار
        await this.addPendingUpload({
          type: 'project',
          projectId: project.id,
          data: project,
        });
        return false;
      }

      await this.uploadProject(project);
      return true;
    } catch (error: any) {
      console.error('خطأ في مزامنة المشروع:', error);
      this.syncStatus.syncErrors.push(error.message || 'فشل في مزامنة المشروع');
      return false;
    }
  }

  /**
   * إضافة مستمع لتغييرات حالة المزامنة
   */
  addSyncStatusListener(callback: (status: SyncStatus) => void): void {
    this.syncCallbacks.push(callback);
  }

  /**
   * إزالة مستمع تغييرات حالة المزامنة
   */
  removeSyncStatusListener(callback: (status: SyncStatus) => void): void {
    const index = this.syncCallbacks.indexOf(callback);
    if (index > -1) {
      this.syncCallbacks.splice(index, 1);
    }
  }

  /**
   * إشعار المستمعين بتغيير الحالة
   */
  private notifyCallbacks(): void {
    this.syncCallbacks.forEach(callback => {
      try {
        callback({ ...this.syncStatus });
      } catch (error) {
        console.error('خطأ في إشعار مستمع المزامنة:', error);
      }
    });
  }

  /**
   * الحصول على حالة المزامنة الحالية
   */
  getSyncStatus(): SyncStatus {
    return { ...this.syncStatus };
  }

  /**
   * مسح أخطاء المزامنة
   */
  clearSyncErrors(): void {
    this.syncStatus.syncErrors = [];
    this.notifyCallbacks();
  }

  /**
   * إعادة تعيين المزامنة
   */
  async resetSync(): Promise<void> {
    try {
      await AsyncStorage.removeItem(this.PENDING_UPLOADS_KEY);
      await AsyncStorage.removeItem(this.SYNC_STATUS_KEY);
      await AsyncStorage.removeItem(this.LAST_SYNC_KEY);
      
      this.syncStatus = {
        isOnline: false,
        lastSyncTime: null,
        pendingUploads: 0,
        pendingDownloads: 0,
        isSyncing: false,
        syncErrors: [],
      };
      
      this.notifyCallbacks();
    } catch (error) {
      console.error('خطأ في إعادة تعيين المزامنة:', error);
    }
  }
}

export default new SyncService();

