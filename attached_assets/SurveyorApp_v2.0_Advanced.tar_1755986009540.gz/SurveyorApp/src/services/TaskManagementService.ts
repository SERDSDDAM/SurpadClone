import AsyncStorage from '@react-native-async-storage/async-storage';
import { Alert } from 'react-native';

export interface Task {
  id: string;
  title: string;
  description?: string;
  type: TaskType;
  status: TaskStatus;
  priority: TaskPriority;
  projectId?: string;
  assignedTo?: string;
  assignedBy?: string;
  createdAt: Date;
  updatedAt: Date;
  dueDate?: Date;
  startDate?: Date;
  completedAt?: Date;
  estimatedDuration?: number; // in minutes
  actualDuration?: number; // in minutes
  location?: TaskLocation;
  attachments: TaskAttachment[];
  subtasks: SubTask[];
  dependencies: string[]; // Task IDs that must be completed first
  tags: string[];
  notes: TaskNote[];
  progress: number; // 0-100
  metadata: Record<string, any>;
}

export interface SubTask {
  id: string;
  title: string;
  description?: string;
  status: TaskStatus;
  assignedTo?: string;
  dueDate?: Date;
  completedAt?: Date;
  progress: number;
}

export interface TaskNote {
  id: string;
  content: string;
  author: string;
  createdAt: Date;
  type: 'note' | 'comment' | 'update';
}

export interface TaskAttachment {
  id: string;
  name: string;
  path: string;
  type: 'image' | 'document' | 'audio' | 'video' | 'other';
  size: number;
  uploadedAt: Date;
  uploadedBy: string;
}

export interface TaskLocation {
  latitude: number;
  longitude: number;
  address?: string;
  radius?: number; // meters
}

export interface Project {
  id: string;
  name: string;
  description?: string;
  status: ProjectStatus;
  priority: TaskPriority;
  clientName?: string;
  clientContact?: string;
  startDate: Date;
  endDate?: Date;
  estimatedDuration?: number; // in days
  budget?: number;
  currency?: string;
  location?: TaskLocation;
  teamMembers: TeamMember[];
  tasks: string[]; // Task IDs
  tags: string[];
  createdAt: Date;
  updatedAt: Date;
  metadata: Record<string, any>;
}

export interface TeamMember {
  id: string;
  name: string;
  email?: string;
  phone?: string;
  role: string;
  permissions: string[];
  joinedAt: Date;
  isActive: boolean;
}

export interface TaskTemplate {
  id: string;
  name: string;
  description?: string;
  type: TaskType;
  estimatedDuration?: number;
  subtasks: Omit<SubTask, 'id' | 'status' | 'progress' | 'completedAt'>[];
  defaultTags: string[];
  requiredFields: string[];
  isDefault: boolean;
}

export interface WorkflowRule {
  id: string;
  name: string;
  description?: string;
  trigger: WorkflowTrigger;
  conditions: WorkflowCondition[];
  actions: WorkflowAction[];
  isActive: boolean;
}

export interface WorkflowTrigger {
  type: 'task_created' | 'task_updated' | 'task_completed' | 'due_date_approaching' | 'overdue';
  parameters?: Record<string, any>;
}

export interface WorkflowCondition {
  field: string;
  operator: 'equals' | 'not_equals' | 'contains' | 'greater_than' | 'less_than';
  value: any;
}

export interface WorkflowAction {
  type: 'assign_task' | 'send_notification' | 'update_status' | 'create_subtask' | 'set_reminder';
  parameters: Record<string, any>;
}

export type TaskType = 
  | 'survey_planning'
  | 'field_survey'
  | 'data_processing'
  | 'report_generation'
  | 'client_meeting'
  | 'equipment_check'
  | 'quality_control'
  | 'documentation'
  | 'other';

export type TaskStatus = 
  | 'not_started'
  | 'in_progress'
  | 'on_hold'
  | 'completed'
  | 'cancelled'
  | 'overdue';

export type TaskPriority = 'low' | 'medium' | 'high' | 'urgent';

export type ProjectStatus = 
  | 'planning'
  | 'active'
  | 'on_hold'
  | 'completed'
  | 'cancelled';

export interface TaskFilter {
  status?: TaskStatus[];
  priority?: TaskPriority[];
  type?: TaskType[];
  assignedTo?: string[];
  projectId?: string;
  dueDateFrom?: Date;
  dueDateTo?: Date;
  tags?: string[];
  searchText?: string;
}

export interface TaskStatistics {
  totalTasks: number;
  completedTasks: number;
  overdueTasks: number;
  inProgressTasks: number;
  tasksByStatus: Record<TaskStatus, number>;
  tasksByPriority: Record<TaskPriority, number>;
  tasksByType: Record<TaskType, number>;
  averageCompletionTime: number; // in minutes
  productivityScore: number; // 0-100
}

class TaskManagementService {
  private tasks: Task[] = [];
  private projects: Project[] = [];
  private templates: TaskTemplate[] = [];
  private workflowRules: WorkflowRule[] = [];
  private currentUser: string = 'المساح الحالي';

  constructor() {
    this.initializeService();
  }

  /**
   * تهيئة خدمة إدارة المهام
   */
  private async initializeService(): Promise<void> {
    try {
      await this.loadData();
      this.loadDefaultTemplates();
      this.setupDefaultWorkflowRules();
      
      console.log('تم تهيئة خدمة إدارة المهام');
    } catch (error) {
      console.error('خطأ في تهيئة خدمة إدارة المهام:', error);
    }
  }

  /**
   * تحميل البيانات من التخزين المحلي
   */
  private async loadData(): Promise<void> {
    try {
      const [tasksData, projectsData, templatesData, rulesData] = await Promise.all([
        AsyncStorage.getItem('tasks'),
        AsyncStorage.getItem('projects'),
        AsyncStorage.getItem('task_templates'),
        AsyncStorage.getItem('workflow_rules'),
      ]);

      this.tasks = tasksData ? JSON.parse(tasksData).map(this.parseTaskDates) : [];
      this.projects = projectsData ? JSON.parse(projectsData).map(this.parseProjectDates) : [];
      this.templates = templatesData ? JSON.parse(templatesData) : [];
      this.workflowRules = rulesData ? JSON.parse(rulesData) : [];
    } catch (error) {
      console.error('خطأ في تحميل البيانات:', error);
    }
  }

  /**
   * حفظ البيانات في التخزين المحلي
   */
  private async saveData(): Promise<void> {
    try {
      await Promise.all([
        AsyncStorage.setItem('tasks', JSON.stringify(this.tasks)),
        AsyncStorage.setItem('projects', JSON.stringify(this.projects)),
        AsyncStorage.setItem('task_templates', JSON.stringify(this.templates)),
        AsyncStorage.setItem('workflow_rules', JSON.stringify(this.workflowRules)),
      ]);
    } catch (error) {
      console.error('خطأ في حفظ البيانات:', error);
    }
  }

  /**
   * تحليل التواريخ في المهام
   */
  private parseTaskDates(task: any): Task {
    return {
      ...task,
      createdAt: new Date(task.createdAt),
      updatedAt: new Date(task.updatedAt),
      dueDate: task.dueDate ? new Date(task.dueDate) : undefined,
      startDate: task.startDate ? new Date(task.startDate) : undefined,
      completedAt: task.completedAt ? new Date(task.completedAt) : undefined,
      subtasks: task.subtasks?.map((st: any) => ({
        ...st,
        dueDate: st.dueDate ? new Date(st.dueDate) : undefined,
        completedAt: st.completedAt ? new Date(st.completedAt) : undefined,
      })) || [],
      notes: task.notes?.map((note: any) => ({
        ...note,
        createdAt: new Date(note.createdAt),
      })) || [],
      attachments: task.attachments?.map((att: any) => ({
        ...att,
        uploadedAt: new Date(att.uploadedAt),
      })) || [],
    };
  }

  /**
   * تحليل التواريخ في المشاريع
   */
  private parseProjectDates(project: any): Project {
    return {
      ...project,
      startDate: new Date(project.startDate),
      endDate: project.endDate ? new Date(project.endDate) : undefined,
      createdAt: new Date(project.createdAt),
      updatedAt: new Date(project.updatedAt),
      teamMembers: project.teamMembers?.map((member: any) => ({
        ...member,
        joinedAt: new Date(member.joinedAt),
      })) || [],
    };
  }

  /**
   * تحميل القوالب الافتراضية
   */
  private loadDefaultTemplates(): void {
    if (this.templates.length === 0) {
      this.templates = [
        {
          id: 'survey_planning_template',
          name: 'تخطيط المسح',
          description: 'قالب لمهام تخطيط أعمال المسح',
          type: 'survey_planning',
          estimatedDuration: 120, // 2 hours
          subtasks: [
            {
              title: 'دراسة الموقع',
              description: 'دراسة أولية للموقع المراد مسحه',
              assignedTo: undefined,
              dueDate: undefined,
              progress: 0,
            },
            {
              title: 'تحديد نقاط المرجع',
              description: 'تحديد النقاط المرجعية للمسح',
              assignedTo: undefined,
              dueDate: undefined,
              progress: 0,
            },
            {
              title: 'إعداد خطة العمل',
              description: 'وضع خطة تفصيلية لتنفيذ المسح',
              assignedTo: undefined,
              dueDate: undefined,
              progress: 0,
            },
          ],
          defaultTags: ['تخطيط', 'مسح'],
          requiredFields: ['location', 'dueDate'],
          isDefault: true,
        },
        {
          id: 'field_survey_template',
          name: 'المسح الميداني',
          description: 'قالب لمهام المسح الميداني',
          type: 'field_survey',
          estimatedDuration: 480, // 8 hours
          subtasks: [
            {
              title: 'إعداد المعدات',
              description: 'فحص وإعداد معدات المسح',
              assignedTo: undefined,
              dueDate: undefined,
              progress: 0,
            },
            {
              title: 'تنفيذ القياسات',
              description: 'تنفيذ القياسات الميدانية',
              assignedTo: undefined,
              dueDate: undefined,
              progress: 0,
            },
            {
              title: 'توثيق البيانات',
              description: 'توثيق وتسجيل البيانات المجمعة',
              assignedTo: undefined,
              dueDate: undefined,
              progress: 0,
            },
          ],
          defaultTags: ['ميداني', 'قياسات'],
          requiredFields: ['location', 'assignedTo', 'startDate'],
          isDefault: true,
        },
        {
          id: 'report_generation_template',
          name: 'إنتاج التقارير',
          description: 'قالب لمهام إنتاج التقارير',
          type: 'report_generation',
          estimatedDuration: 240, // 4 hours
          subtasks: [
            {
              title: 'تحليل البيانات',
              description: 'تحليل ومعالجة البيانات المجمعة',
              assignedTo: undefined,
              dueDate: undefined,
              progress: 0,
            },
            {
              title: 'إعداد التقرير',
              description: 'كتابة وتنسيق التقرير النهائي',
              assignedTo: undefined,
              dueDate: undefined,
              progress: 0,
            },
            {
              title: 'مراجعة وتدقيق',
              description: 'مراجعة التقرير والتأكد من دقته',
              assignedTo: undefined,
              dueDate: undefined,
              progress: 0,
            },
          ],
          defaultTags: ['تقرير', 'تحليل'],
          requiredFields: ['dueDate'],
          isDefault: true,
        },
      ];
    }
  }

  /**
   * إعداد قواعد سير العمل الافتراضية
   */
  private setupDefaultWorkflowRules(): void {
    if (this.workflowRules.length === 0) {
      this.workflowRules = [
        {
          id: 'overdue_notification',
          name: 'تنبيه المهام المتأخرة',
          description: 'إرسال تنبيه عند تأخر المهام',
          trigger: { type: 'overdue' },
          conditions: [],
          actions: [
            {
              type: 'send_notification',
              parameters: {
                message: 'لديك مهام متأخرة تحتاج إلى انتباه',
                priority: 'high',
              },
            },
          ],
          isActive: true,
        },
        {
          id: 'auto_assign_urgent',
          name: 'تعيين المهام العاجلة تلقائياً',
          description: 'تعيين المهام العاجلة للمساح المتاح',
          trigger: { type: 'task_created' },
          conditions: [
            { field: 'priority', operator: 'equals', value: 'urgent' },
          ],
          actions: [
            {
              type: 'assign_task',
              parameters: { assignTo: 'available_surveyor' },
            },
          ],
          isActive: true,
        },
      ];
    }
  }

  /**
   * إنشاء مهمة جديدة
   */
  async createTask(taskData: Omit<Task, 'id' | 'createdAt' | 'updatedAt'>): Promise<Task> {
    const task: Task = {
      ...taskData,
      id: `task_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      createdAt: new Date(),
      updatedAt: new Date(),
      attachments: taskData.attachments || [],
      subtasks: taskData.subtasks || [],
      dependencies: taskData.dependencies || [],
      tags: taskData.tags || [],
      notes: taskData.notes || [],
      progress: taskData.progress || 0,
      metadata: taskData.metadata || {},
    };

    this.tasks.push(task);
    await this.saveData();

    // تطبيق قواعد سير العمل
    await this.executeWorkflowRules('task_created', task);

    return task;
  }

  /**
   * تحديث مهمة موجودة
   */
  async updateTask(taskId: string, updates: Partial<Task>): Promise<Task | null> {
    const taskIndex = this.tasks.findIndex(t => t.id === taskId);
    if (taskIndex === -1) return null;

    const oldTask = { ...this.tasks[taskIndex] };
    this.tasks[taskIndex] = {
      ...this.tasks[taskIndex],
      ...updates,
      updatedAt: new Date(),
    };

    await this.saveData();

    // تطبيق قواعد سير العمل
    await this.executeWorkflowRules('task_updated', this.tasks[taskIndex], oldTask);

    return this.tasks[taskIndex];
  }

  /**
   * حذف مهمة
   */
  async deleteTask(taskId: string): Promise<boolean> {
    const taskIndex = this.tasks.findIndex(t => t.id === taskId);
    if (taskIndex === -1) return false;

    this.tasks.splice(taskIndex, 1);
    await this.saveData();

    return true;
  }

  /**
   * إنشاء مشروع جديد
   */
  async createProject(projectData: Omit<Project, 'id' | 'createdAt' | 'updatedAt' | 'tasks'>): Promise<Project> {
    const project: Project = {
      ...projectData,
      id: `project_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      tasks: [],
      createdAt: new Date(),
      updatedAt: new Date(),
      teamMembers: projectData.teamMembers || [],
      tags: projectData.tags || [],
      metadata: projectData.metadata || {},
    };

    this.projects.push(project);
    await this.saveData();

    return project;
  }

  /**
   * تحديث مشروع موجود
   */
  async updateProject(projectId: string, updates: Partial<Project>): Promise<Project | null> {
    const projectIndex = this.projects.findIndex(p => p.id === projectId);
    if (projectIndex === -1) return null;

    this.projects[projectIndex] = {
      ...this.projects[projectIndex],
      ...updates,
      updatedAt: new Date(),
    };

    await this.saveData();
    return this.projects[projectIndex];
  }

  /**
   * حذف مشروع
   */
  async deleteProject(projectId: string): Promise<boolean> {
    const projectIndex = this.projects.findIndex(p => p.id === projectId);
    if (projectIndex === -1) return false;

    // حذف المهام المرتبطة بالمشروع
    this.tasks = this.tasks.filter(task => task.projectId !== projectId);

    this.projects.splice(projectIndex, 1);
    await this.saveData();

    return true;
  }

  /**
   * إضافة مهمة إلى مشروع
   */
  async addTaskToProject(projectId: string, taskId: string): Promise<boolean> {
    const project = this.projects.find(p => p.id === projectId);
    const task = this.tasks.find(t => t.id === taskId);

    if (!project || !task) return false;

    if (!project.tasks.includes(taskId)) {
      project.tasks.push(taskId);
      task.projectId = projectId;
      await this.saveData();
    }

    return true;
  }

  /**
   * إنشاء مهمة من قالب
   */
  async createTaskFromTemplate(templateId: string, customData: Partial<Task>): Promise<Task | null> {
    const template = this.templates.find(t => t.id === templateId);
    if (!template) return null;

    const subtasks: SubTask[] = template.subtasks.map(st => ({
      ...st,
      id: `subtask_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      status: 'not_started',
      progress: 0,
    }));

    const taskData: Omit<Task, 'id' | 'createdAt' | 'updatedAt'> = {
      title: customData.title || template.name,
      description: customData.description || template.description,
      type: template.type,
      status: 'not_started',
      priority: customData.priority || 'medium',
      estimatedDuration: template.estimatedDuration,
      subtasks,
      tags: [...template.defaultTags, ...(customData.tags || [])],
      progress: 0,
      attachments: [],
      dependencies: [],
      notes: [],
      metadata: {},
      ...customData,
    };

    return await this.createTask(taskData);
  }

  /**
   * الحصول على جميع المهام
   */
  getAllTasks(): Task[] {
    return [...this.tasks];
  }

  /**
   * الحصول على مهمة محددة
   */
  getTask(taskId: string): Task | null {
    return this.tasks.find(t => t.id === taskId) || null;
  }

  /**
   * فلترة المهام
   */
  filterTasks(filter: TaskFilter): Task[] {
    return this.tasks.filter(task => {
      if (filter.status && !filter.status.includes(task.status)) return false;
      if (filter.priority && !filter.priority.includes(task.priority)) return false;
      if (filter.type && !filter.type.includes(task.type)) return false;
      if (filter.assignedTo && !filter.assignedTo.includes(task.assignedTo || '')) return false;
      if (filter.projectId && task.projectId !== filter.projectId) return false;
      if (filter.dueDateFrom && task.dueDate && task.dueDate < filter.dueDateFrom) return false;
      if (filter.dueDateTo && task.dueDate && task.dueDate > filter.dueDateTo) return false;
      if (filter.tags && !filter.tags.some(tag => task.tags.includes(tag))) return false;
      if (filter.searchText) {
        const searchLower = filter.searchText.toLowerCase();
        if (!task.title.toLowerCase().includes(searchLower) &&
            !task.description?.toLowerCase().includes(searchLower)) return false;
      }
      return true;
    });
  }

  /**
   * الحصول على جميع المشاريع
   */
  getAllProjects(): Project[] {
    return [...this.projects];
  }

  /**
   * الحصول على مشروع محدد
   */
  getProject(projectId: string): Project | null {
    return this.projects.find(p => p.id === projectId) || null;
  }

  /**
   * الحصول على مهام مشروع محدد
   */
  getProjectTasks(projectId: string): Task[] {
    return this.tasks.filter(task => task.projectId === projectId);
  }

  /**
   * الحصول على إحصائيات المهام
   */
  getTaskStatistics(): TaskStatistics {
    const now = new Date();
    const completedTasks = this.tasks.filter(t => t.status === 'completed');
    const overdueTasks = this.tasks.filter(t => 
      t.dueDate && t.dueDate < now && t.status !== 'completed'
    );

    const tasksByStatus = this.tasks.reduce((acc, task) => {
      acc[task.status] = (acc[task.status] || 0) + 1;
      return acc;
    }, {} as Record<TaskStatus, number>);

    const tasksByPriority = this.tasks.reduce((acc, task) => {
      acc[task.priority] = (acc[task.priority] || 0) + 1;
      return acc;
    }, {} as Record<TaskPriority, number>);

    const tasksByType = this.tasks.reduce((acc, task) => {
      acc[task.type] = (acc[task.type] || 0) + 1;
      return acc;
    }, {} as Record<TaskType, number>);

    // حساب متوسط وقت الإنجاز
    const completedWithDuration = completedTasks.filter(t => t.actualDuration);
    const averageCompletionTime = completedWithDuration.length > 0
      ? completedWithDuration.reduce((sum, t) => sum + (t.actualDuration || 0), 0) / completedWithDuration.length
      : 0;

    // حساب نقاط الإنتاجية
    const totalTasks = this.tasks.length;
    const completionRate = totalTasks > 0 ? (completedTasks.length / totalTasks) * 100 : 0;
    const onTimeRate = completedTasks.length > 0 
      ? (completedTasks.filter(t => !t.dueDate || (t.completedAt && t.completedAt <= t.dueDate)).length / completedTasks.length) * 100
      : 0;
    const productivityScore = Math.round((completionRate * 0.6) + (onTimeRate * 0.4));

    return {
      totalTasks: this.tasks.length,
      completedTasks: completedTasks.length,
      overdueTasks: overdueTasks.length,
      inProgressTasks: this.tasks.filter(t => t.status === 'in_progress').length,
      tasksByStatus,
      tasksByPriority,
      tasksByType,
      averageCompletionTime,
      productivityScore,
    };
  }

  /**
   * الحصول على القوالب المتاحة
   */
  getAvailableTemplates(): TaskTemplate[] {
    return [...this.templates];
  }

  /**
   * إضافة قالب جديد
   */
  async addTemplate(template: Omit<TaskTemplate, 'id'>): Promise<TaskTemplate> {
    const newTemplate: TaskTemplate = {
      ...template,
      id: `template_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    };

    this.templates.push(newTemplate);
    await this.saveData();

    return newTemplate;
  }

  /**
   * تنفيذ قواعد سير العمل
   */
  private async executeWorkflowRules(trigger: string, task: Task, oldTask?: Task): Promise<void> {
    const applicableRules = this.workflowRules.filter(rule => 
      rule.isActive && rule.trigger.type === trigger
    );

    for (const rule of applicableRules) {
      const conditionsMet = rule.conditions.every(condition => 
        this.evaluateCondition(condition, task, oldTask)
      );

      if (conditionsMet) {
        for (const action of rule.actions) {
          await this.executeWorkflowAction(action, task);
        }
      }
    }
  }

  /**
   * تقييم شرط سير العمل
   */
  private evaluateCondition(condition: WorkflowCondition, task: Task, oldTask?: Task): boolean {
    const taskValue = (task as any)[condition.field];
    
    switch (condition.operator) {
      case 'equals':
        return taskValue === condition.value;
      case 'not_equals':
        return taskValue !== condition.value;
      case 'contains':
        return Array.isArray(taskValue) 
          ? taskValue.includes(condition.value)
          : String(taskValue).includes(String(condition.value));
      case 'greater_than':
        return taskValue > condition.value;
      case 'less_than':
        return taskValue < condition.value;
      default:
        return false;
    }
  }

  /**
   * تنفيذ إجراء سير العمل
   */
  private async executeWorkflowAction(action: WorkflowAction, task: Task): Promise<void> {
    switch (action.type) {
      case 'send_notification':
        // في التطبيق الحقيقي، يمكن إرسال إشعار فعلي
        console.log(`إشعار: ${action.parameters.message} للمهمة: ${task.title}`);
        break;
      
      case 'assign_task':
        if (action.parameters.assignTo) {
          await this.updateTask(task.id, { assignedTo: action.parameters.assignTo });
        }
        break;
      
      case 'update_status':
        if (action.parameters.status) {
          await this.updateTask(task.id, { status: action.parameters.status });
        }
        break;
      
      case 'create_subtask':
        // إنشاء مهمة فرعية جديدة
        const subtask: SubTask = {
          id: `subtask_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          title: action.parameters.title || 'مهمة فرعية جديدة',
          description: action.parameters.description,
          status: 'not_started',
          progress: 0,
          assignedTo: action.parameters.assignedTo,
          dueDate: action.parameters.dueDate ? new Date(action.parameters.dueDate) : undefined,
        };
        
        task.subtasks.push(subtask);
        await this.updateTask(task.id, { subtasks: task.subtasks });
        break;
    }
  }

  /**
   * تحديث تقدم المهمة بناءً على المهام الفرعية
   */
  async updateTaskProgress(taskId: string): Promise<void> {
    const task = this.getTask(taskId);
    if (!task || task.subtasks.length === 0) return;

    const totalProgress = task.subtasks.reduce((sum, subtask) => sum + subtask.progress, 0);
    const averageProgress = Math.round(totalProgress / task.subtasks.length);

    await this.updateTask(taskId, { progress: averageProgress });

    // إذا اكتملت جميع المهام الفرعية، قم بتحديث حالة المهمة الرئيسية
    if (averageProgress === 100 && task.status !== 'completed') {
      await this.updateTask(taskId, { 
        status: 'completed',
        completedAt: new Date(),
        progress: 100,
      });
    }
  }

  /**
   * إضافة ملاحظة لمهمة
   */
  async addTaskNote(taskId: string, content: string, type: 'note' | 'comment' | 'update' = 'note'): Promise<boolean> {
    const task = this.getTask(taskId);
    if (!task) return false;

    const note: TaskNote = {
      id: `note_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      content,
      author: this.currentUser,
      createdAt: new Date(),
      type,
    };

    task.notes.push(note);
    await this.updateTask(taskId, { notes: task.notes });

    return true;
  }

  /**
   * إضافة مرفق لمهمة
   */
  async addTaskAttachment(taskId: string, attachment: Omit<TaskAttachment, 'id' | 'uploadedAt' | 'uploadedBy'>): Promise<boolean> {
    const task = this.getTask(taskId);
    if (!task) return false;

    const newAttachment: TaskAttachment = {
      ...attachment,
      id: `attachment_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      uploadedAt: new Date(),
      uploadedBy: this.currentUser,
    };

    task.attachments.push(newAttachment);
    await this.updateTask(taskId, { attachments: task.attachments });

    return true;
  }

  /**
   * الحصول على المهام المتأخرة
   */
  getOverdueTasks(): Task[] {
    const now = new Date();
    return this.tasks.filter(task => 
      task.dueDate && 
      task.dueDate < now && 
      task.status !== 'completed' && 
      task.status !== 'cancelled'
    );
  }

  /**
   * الحصول على المهام المستحقة قريباً
   */
  getUpcomingTasks(days: number = 7): Task[] {
    const now = new Date();
    const futureDate = new Date(now.getTime() + (days * 24 * 60 * 60 * 1000));
    
    return this.tasks.filter(task => 
      task.dueDate && 
      task.dueDate >= now && 
      task.dueDate <= futureDate &&
      task.status !== 'completed' && 
      task.status !== 'cancelled'
    );
  }

  /**
   * تعيين المستخدم الحالي
   */
  setCurrentUser(username: string): void {
    this.currentUser = username;
  }
}

export default new TaskManagementService();

