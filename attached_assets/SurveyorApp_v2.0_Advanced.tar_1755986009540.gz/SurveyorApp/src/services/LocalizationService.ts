import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import * as RNLocalize from 'react-native-localize';
import AsyncStorage from '@react-native-async-storage/async-storage';

// ترجمات العربية
const arabicTranslations = {
  // التنقل والقوائم
  navigation: {
    dashboard: 'لوحة التحكم',
    surveys: 'طلبات المسح',
    map: 'الخريطة',
    settings: 'الإعدادات',
    bluetooth: 'البلوتوث',
    ar: 'الواقع المعزز',
    collaboration: 'التعاون',
    cadgis: 'CAD/GIS',
    offlineMaps: 'الخرائط غير المتصلة',
    reports: 'التقارير',
    taskManagement: 'إدارة المهام',
  },

  // العناوين والأقسام
  titles: {
    welcome: 'مرحباً بك في تطبيق المساح',
    surveyRequests: 'طلبات المسح',
    activeRequests: 'الطلبات النشطة',
    completedRequests: 'الطلبات المكتملة',
    mapView: 'عرض الخريطة',
    bluetoothDevices: 'أجهزة البلوتوث',
    arView: 'عرض الواقع المعزز',
    collaboration: 'التعاون في الوقت الفعلي',
    cadgisIntegration: 'تكامل CAD/GIS',
    offlineMapManagement: 'إدارة الخرائط غير المتصلة',
    reportGeneration: 'إنشاء التقارير',
    taskManagement: 'إدارة المهام',
    statistics: 'الإحصائيات',
    settings: 'الإعدادات',
  },

  // الأزرار والإجراءات
  buttons: {
    login: 'تسجيل الدخول',
    logout: 'تسجيل الخروج',
    save: 'حفظ',
    cancel: 'إلغاء',
    delete: 'حذف',
    edit: 'تحرير',
    create: 'إنشاء',
    update: 'تحديث',
    submit: 'إرسال',
    close: 'إغلاق',
    back: 'رجوع',
    next: 'التالي',
    previous: 'السابق',
    confirm: 'تأكيد',
    start: 'بدء',
    stop: 'إيقاف',
    pause: 'إيقاف مؤقت',
    resume: 'استئناف',
    complete: 'إكمال',
    share: 'مشاركة',
    download: 'تنزيل',
    upload: 'رفع',
    connect: 'اتصال',
    disconnect: 'قطع الاتصال',
    scan: 'مسح',
    refresh: 'تحديث',
    search: 'بحث',
    filter: 'فلترة',
    sort: 'ترتيب',
    export: 'تصدير',
    import: 'استيراد',
    sync: 'مزامنة',
  },

  // النماذج والحقول
  forms: {
    username: 'اسم المستخدم',
    password: 'كلمة المرور',
    email: 'البريد الإلكتروني',
    name: 'الاسم',
    title: 'العنوان',
    description: 'الوصف',
    location: 'الموقع',
    date: 'التاريخ',
    time: 'الوقت',
    status: 'الحالة',
    priority: 'الأولوية',
    type: 'النوع',
    category: 'الفئة',
    notes: 'الملاحظات',
    comments: 'التعليقات',
    attachments: 'المرفقات',
    coordinates: 'الإحداثيات',
    latitude: 'خط العرض',
    longitude: 'خط الطول',
    altitude: 'الارتفاع',
    accuracy: 'الدقة',
    address: 'العنوان',
    phone: 'الهاتف',
    organization: 'المؤسسة',
    client: 'العميل',
    surveyor: 'المساح',
    project: 'المشروع',
    task: 'المهمة',
    subtask: 'المهمة الفرعية',
    template: 'القالب',
    language: 'اللغة',
    theme: 'المظهر',
    units: 'الوحدات',
    format: 'التنسيق',
  },

  // الحالات والأولويات
  status: {
    active: 'نشط',
    inactive: 'غير نشط',
    pending: 'معلق',
    approved: 'موافق عليه',
    rejected: 'مرفوض',
    completed: 'مكتمل',
    inProgress: 'قيد التنفيذ',
    notStarted: 'لم يبدأ',
    onHold: 'معلق',
    cancelled: 'ملغى',
    overdue: 'متأخر',
    draft: 'مسودة',
    published: 'منشور',
    archived: 'مؤرشف',
  },

  priority: {
    low: 'منخفض',
    medium: 'متوسط',
    high: 'عالي',
    urgent: 'عاجل',
    critical: 'حرج',
  },

  // أنواع المهام والمسح
  taskTypes: {
    surveyPlanning: 'تخطيط المسح',
    fieldSurvey: 'مسح ميداني',
    dataProcessing: 'معالجة البيانات',
    reportGeneration: 'إنتاج التقارير',
    clientMeeting: 'اجتماع عميل',
    equipmentCheck: 'فحص المعدات',
    qualityControl: 'مراقبة الجودة',
    documentation: 'توثيق',
    other: 'أخرى',
  },

  surveyTypes: {
    topographic: 'مسح طبوغرافي',
    cadastral: 'مسح عقاري',
    engineering: 'مسح هندسي',
    construction: 'مسح إنشائي',
    boundary: 'مسح حدود',
    asBuilt: 'مسح تنفيذي',
    monitoring: 'مسح مراقبة',
    hydrographic: 'مسح هيدروغرافي',
  },

  // الرسائل والإشعارات
  messages: {
    success: {
      loginSuccess: 'تم تسجيل الدخول بنجاح',
      saveSuccess: 'تم الحفظ بنجاح',
      deleteSuccess: 'تم الحذف بنجاح',
      updateSuccess: 'تم التحديث بنجاح',
      createSuccess: 'تم الإنشاء بنجاح',
      uploadSuccess: 'تم الرفع بنجاح',
      downloadSuccess: 'تم التنزيل بنجاح',
      syncSuccess: 'تم التزامن بنجاح',
      connectSuccess: 'تم الاتصال بنجاح',
      disconnectSuccess: 'تم قطع الاتصال بنجاح',
    },
    error: {
      loginFailed: 'فشل في تسجيل الدخول',
      saveFailed: 'فشل في الحفظ',
      deleteFailed: 'فشل في الحذف',
      updateFailed: 'فشل في التحديث',
      createFailed: 'فشل في الإنشاء',
      uploadFailed: 'فشل في الرفع',
      downloadFailed: 'فشل في التنزيل',
      syncFailed: 'فشل في التزامن',
      connectFailed: 'فشل في الاتصال',
      networkError: 'خطأ في الشبكة',
      serverError: 'خطأ في الخادم',
      validationError: 'خطأ في التحقق',
      permissionDenied: 'تم رفض الإذن',
      fileNotFound: 'الملف غير موجود',
      invalidFormat: 'تنسيق غير صحيح',
      insufficientStorage: 'مساحة تخزين غير كافية',
    },
    warning: {
      unsavedChanges: 'لديك تغييرات غير محفوظة',
      lowBattery: 'البطارية منخفضة',
      lowStorage: 'مساحة التخزين منخفضة',
      noInternet: 'لا يوجد اتصال بالإنترنت',
      locationDisabled: 'خدمة الموقع معطلة',
      bluetoothDisabled: 'البلوتوث معطل',
      gpsInaccurate: 'دقة GPS منخفضة',
      dataOutdated: 'البيانات قديمة',
    },
    info: {
      loading: 'جاري التحميل...',
      saving: 'جاري الحفظ...',
      uploading: 'جاري الرفع...',
      downloading: 'جاري التنزيل...',
      syncing: 'جاري التزامن...',
      connecting: 'جاري الاتصال...',
      processing: 'جاري المعالجة...',
      searching: 'جاري البحث...',
      noData: 'لا توجد بيانات',
      noResults: 'لا توجد نتائج',
      emptyList: 'القائمة فارغة',
      selectItem: 'اختر عنصر',
      tapToRetry: 'اضغط للمحاولة مرة أخرى',
    },
  },

  // التأكيدات والحوارات
  dialogs: {
    confirmDelete: 'هل أنت متأكد من الحذف؟',
    confirmLogout: 'هل تريد تسجيل الخروج؟',
    confirmCancel: 'هل تريد إلغاء التغييرات؟',
    confirmOverwrite: 'هل تريد استبدال الملف الموجود؟',
    confirmSync: 'هل تريد مزامنة البيانات؟',
    confirmReset: 'هل تريد إعادة تعيين الإعدادات؟',
    selectLanguage: 'اختر اللغة',
    selectTheme: 'اختر المظهر',
    selectUnits: 'اختر الوحدات',
    enterPassword: 'أدخل كلمة المرور',
    enterName: 'أدخل الاسم',
    enterDescription: 'أدخل الوصف',
  },

  // الإعدادات والتفضيلات
  settings: {
    general: 'عام',
    account: 'الحساب',
    appearance: 'المظهر',
    language: 'اللغة',
    units: 'الوحدات',
    location: 'الموقع',
    bluetooth: 'البلوتوث',
    sync: 'المزامنة',
    storage: 'التخزين',
    security: 'الأمان',
    privacy: 'الخصوصية',
    notifications: 'الإشعارات',
    about: 'حول التطبيق',
    help: 'المساعدة',
    feedback: 'التعليقات',
    version: 'الإصدار',
    buildNumber: 'رقم البناء',
    developer: 'المطور',
    license: 'الترخيص',
    termsOfService: 'شروط الخدمة',
    privacyPolicy: 'سياسة الخصوصية',
  },

  // الوحدات والقياسات
  units: {
    metric: 'متري',
    imperial: 'إمبراطوري',
    meters: 'متر',
    feet: 'قدم',
    kilometers: 'كيلومتر',
    miles: 'ميل',
    degrees: 'درجة',
    radians: 'راديان',
    squareMeters: 'متر مربع',
    squareFeet: 'قدم مربع',
    hectares: 'هكتار',
    acres: 'فدان',
    celsius: 'مئوية',
    fahrenheit: 'فهرنهايت',
  },

  // التقارير والإحصائيات
  reports: {
    surveyReport: 'تقرير المسح',
    progressReport: 'تقرير التقدم',
    summaryReport: 'تقرير ملخص',
    detailedReport: 'تقرير مفصل',
    statisticsReport: 'تقرير إحصائي',
    qualityReport: 'تقرير الجودة',
    timeReport: 'تقرير الوقت',
    costReport: 'تقرير التكلفة',
    clientReport: 'تقرير العميل',
    technicalReport: 'تقرير تقني',
    executiveSummary: 'ملخص تنفيذي',
    recommendations: 'التوصيات',
    conclusions: 'الخلاصة',
    methodology: 'المنهجية',
    limitations: 'القيود',
    references: 'المراجع',
    appendices: 'الملاحق',
  },

  // البلوتوث والأجهزة
  bluetooth: {
    scanning: 'جاري البحث عن الأجهزة...',
    connecting: 'جاري الاتصال...',
    connected: 'متصل',
    disconnected: 'غير متصل',
    pairing: 'جاري الإقران...',
    paired: 'مقترن',
    unpaired: 'غير مقترن',
    available: 'متاح',
    unavailable: 'غير متاح',
    deviceName: 'اسم الجهاز',
    deviceType: 'نوع الجهاز',
    signalStrength: 'قوة الإشارة',
    batteryLevel: 'مستوى البطارية',
    lastSeen: 'آخر ظهور',
    gpsReceiver: 'مستقبل GPS',
    laserMeter: 'جهاز قياس بالليزر',
    totalStation: 'محطة شاملة',
    level: 'ميزان',
    compass: 'بوصلة',
    unknown: 'غير معروف',
  },

  // الواقع المعزز
  ar: {
    startAR: 'بدء الواقع المعزز',
    stopAR: 'إيقاف الواقع المعزز',
    calibrating: 'جاري المعايرة...',
    calibrated: 'تم المعايرة',
    trackingLost: 'فقدان التتبع',
    trackingRestored: 'استعادة التتبع',
    placingMarker: 'وضع علامة',
    markerPlaced: 'تم وضع العلامة',
    selectPoint: 'اختر نقطة',
    measureDistance: 'قياس المسافة',
    measureArea: 'قياس المساحة',
    measureAngle: 'قياس الزاوية',
    viewBoundaries: 'عرض الحدود',
    viewPoints: 'عرض النقاط',
    viewLines: 'عرض الخطوط',
    viewAreas: 'عرض المناطق',
    cameraPermission: 'إذن الكاميرا مطلوب',
    arNotSupported: 'الواقع المعزز غير مدعوم',
  },

  // التعاون
  collaboration: {
    online: 'متصل',
    offline: 'غير متصل',
    connecting: 'جاري الاتصال...',
    reconnecting: 'جاري إعادة الاتصال...',
    connected: 'متصل',
    disconnected: 'منقطع',
    joinProject: 'انضمام للمشروع',
    leaveProject: 'مغادرة المشروع',
    inviteUser: 'دعوة مستخدم',
    removeUser: 'إزالة مستخدم',
    shareLocation: 'مشاركة الموقع',
    shareData: 'مشاركة البيانات',
    sendMessage: 'إرسال رسالة',
    receiveMessage: 'استقبال رسالة',
    typing: 'يكتب...',
    lastSeen: 'آخر ظهور',
    activeUsers: 'المستخدمون النشطون',
    recentActivity: 'النشاط الأخير',
    chatHistory: 'تاريخ المحادثة',
    notifications: 'الإشعارات',
    permissions: 'الصلاحيات',
    moderator: 'مشرف',
    participant: 'مشارك',
    viewer: 'مشاهد',
  },

  // الخرائط غير المتصلة
  offlineMaps: {
    downloadMap: 'تنزيل خريطة',
    deleteMap: 'حذف خريطة',
    mapDownloaded: 'تم تنزيل الخريطة',
    mapDeleted: 'تم حذف الخريطة',
    downloading: 'جاري التنزيل...',
    downloadProgress: 'تقدم التنزيل',
    downloadComplete: 'اكتمل التنزيل',
    downloadFailed: 'فشل التنزيل',
    downloadCancelled: 'تم إلغاء التنزيل',
    mapSize: 'حجم الخريطة',
    storageUsed: 'المساحة المستخدمة',
    storageAvailable: 'المساحة المتاحة',
    selectArea: 'اختر المنطقة',
    zoomLevel: 'مستوى التكبير',
    tileCount: 'عدد البلاطات',
    estimatedSize: 'الحجم المقدر',
    mapProvider: 'مقدم الخريطة',
    satellite: 'أقمار صناعية',
    terrain: 'تضاريس',
    street: 'شوارع',
    hybrid: 'مختلط',
  },

  // CAD/GIS
  cadgis: {
    importFile: 'استيراد ملف',
    exportFile: 'تصدير ملف',
    fileImported: 'تم استيراد الملف',
    fileExported: 'تم تصدير الملف',
    importFailed: 'فشل الاستيراد',
    exportFailed: 'فشل التصدير',
    unsupportedFormat: 'تنسيق غير مدعوم',
    fileSize: 'حجم الملف',
    fileType: 'نوع الملف',
    fileName: 'اسم الملف',
    filePath: 'مسار الملف',
    lastModified: 'آخر تعديل',
    layers: 'الطبقات',
    features: 'المعالم',
    attributes: 'الخصائص',
    coordinates: 'الإحداثيات',
    projection: 'الإسقاط',
    datum: 'المرجع',
    units: 'الوحدات',
    scale: 'المقياس',
    precision: 'الدقة',
    tolerance: 'التسامح',
    validation: 'التحقق',
    conversion: 'التحويل',
    transformation: 'التحويل الهندسي',
  },

  // التواريخ والأوقات
  dateTime: {
    today: 'اليوم',
    yesterday: 'أمس',
    tomorrow: 'غداً',
    thisWeek: 'هذا الأسبوع',
    lastWeek: 'الأسبوع الماضي',
    nextWeek: 'الأسبوع القادم',
    thisMonth: 'هذا الشهر',
    lastMonth: 'الشهر الماضي',
    nextMonth: 'الشهر القادم',
    thisYear: 'هذا العام',
    lastYear: 'العام الماضي',
    nextYear: 'العام القادم',
    now: 'الآن',
    soon: 'قريباً',
    later: 'لاحقاً',
    never: 'أبداً',
    always: 'دائماً',
    morning: 'صباح',
    afternoon: 'بعد الظهر',
    evening: 'مساء',
    night: 'ليل',
    dawn: 'فجر',
    sunrise: 'شروق',
    sunset: 'غروب',
    midnight: 'منتصف الليل',
    noon: 'ظهر',
  },

  // أيام الأسبوع
  weekdays: {
    sunday: 'الأحد',
    monday: 'الاثنين',
    tuesday: 'الثلاثاء',
    wednesday: 'الأربعاء',
    thursday: 'الخميس',
    friday: 'الجمعة',
    saturday: 'السبت',
  },

  // الشهور
  months: {
    january: 'يناير',
    february: 'فبراير',
    march: 'مارس',
    april: 'أبريل',
    may: 'مايو',
    june: 'يونيو',
    july: 'يوليو',
    august: 'أغسطس',
    september: 'سبتمبر',
    october: 'أكتوبر',
    november: 'نوفمبر',
    december: 'ديسمبر',
  },
};

// ترجمات الإنجليزية
const englishTranslations = {
  // Navigation and menus
  navigation: {
    dashboard: 'Dashboard',
    surveys: 'Survey Requests',
    map: 'Map',
    settings: 'Settings',
    bluetooth: 'Bluetooth',
    ar: 'Augmented Reality',
    collaboration: 'Collaboration',
    cadgis: 'CAD/GIS',
    offlineMaps: 'Offline Maps',
    reports: 'Reports',
    taskManagement: 'Task Management',
  },

  // Titles and sections
  titles: {
    welcome: 'Welcome to Surveyor App',
    surveyRequests: 'Survey Requests',
    activeRequests: 'Active Requests',
    completedRequests: 'Completed Requests',
    mapView: 'Map View',
    bluetoothDevices: 'Bluetooth Devices',
    arView: 'Augmented Reality View',
    collaboration: 'Real-time Collaboration',
    cadgisIntegration: 'CAD/GIS Integration',
    offlineMapManagement: 'Offline Map Management',
    reportGeneration: 'Report Generation',
    taskManagement: 'Task Management',
    statistics: 'Statistics',
    settings: 'Settings',
  },

  // Buttons and actions
  buttons: {
    login: 'Login',
    logout: 'Logout',
    save: 'Save',
    cancel: 'Cancel',
    delete: 'Delete',
    edit: 'Edit',
    create: 'Create',
    update: 'Update',
    submit: 'Submit',
    close: 'Close',
    back: 'Back',
    next: 'Next',
    previous: 'Previous',
    confirm: 'Confirm',
    start: 'Start',
    stop: 'Stop',
    pause: 'Pause',
    resume: 'Resume',
    complete: 'Complete',
    share: 'Share',
    download: 'Download',
    upload: 'Upload',
    connect: 'Connect',
    disconnect: 'Disconnect',
    scan: 'Scan',
    refresh: 'Refresh',
    search: 'Search',
    filter: 'Filter',
    sort: 'Sort',
    export: 'Export',
    import: 'Import',
    sync: 'Sync',
  },

  // Forms and fields
  forms: {
    username: 'Username',
    password: 'Password',
    email: 'Email',
    name: 'Name',
    title: 'Title',
    description: 'Description',
    location: 'Location',
    date: 'Date',
    time: 'Time',
    status: 'Status',
    priority: 'Priority',
    type: 'Type',
    category: 'Category',
    notes: 'Notes',
    comments: 'Comments',
    attachments: 'Attachments',
    coordinates: 'Coordinates',
    latitude: 'Latitude',
    longitude: 'Longitude',
    altitude: 'Altitude',
    accuracy: 'Accuracy',
    address: 'Address',
    phone: 'Phone',
    organization: 'Organization',
    client: 'Client',
    surveyor: 'Surveyor',
    project: 'Project',
    task: 'Task',
    subtask: 'Subtask',
    template: 'Template',
    language: 'Language',
    theme: 'Theme',
    units: 'Units',
    format: 'Format',
  },

  // Status and priorities
  status: {
    active: 'Active',
    inactive: 'Inactive',
    pending: 'Pending',
    approved: 'Approved',
    rejected: 'Rejected',
    completed: 'Completed',
    inProgress: 'In Progress',
    notStarted: 'Not Started',
    onHold: 'On Hold',
    cancelled: 'Cancelled',
    overdue: 'Overdue',
    draft: 'Draft',
    published: 'Published',
    archived: 'Archived',
  },

  priority: {
    low: 'Low',
    medium: 'Medium',
    high: 'High',
    urgent: 'Urgent',
    critical: 'Critical',
  },

  // Task and survey types
  taskTypes: {
    surveyPlanning: 'Survey Planning',
    fieldSurvey: 'Field Survey',
    dataProcessing: 'Data Processing',
    reportGeneration: 'Report Generation',
    clientMeeting: 'Client Meeting',
    equipmentCheck: 'Equipment Check',
    qualityControl: 'Quality Control',
    documentation: 'Documentation',
    other: 'Other',
  },

  surveyTypes: {
    topographic: 'Topographic Survey',
    cadastral: 'Cadastral Survey',
    engineering: 'Engineering Survey',
    construction: 'Construction Survey',
    boundary: 'Boundary Survey',
    asBuilt: 'As-Built Survey',
    monitoring: 'Monitoring Survey',
    hydrographic: 'Hydrographic Survey',
  },

  // Messages and notifications
  messages: {
    success: {
      loginSuccess: 'Login successful',
      saveSuccess: 'Saved successfully',
      deleteSuccess: 'Deleted successfully',
      updateSuccess: 'Updated successfully',
      createSuccess: 'Created successfully',
      uploadSuccess: 'Uploaded successfully',
      downloadSuccess: 'Downloaded successfully',
      syncSuccess: 'Synced successfully',
      connectSuccess: 'Connected successfully',
      disconnectSuccess: 'Disconnected successfully',
    },
    error: {
      loginFailed: 'Login failed',
      saveFailed: 'Save failed',
      deleteFailed: 'Delete failed',
      updateFailed: 'Update failed',
      createFailed: 'Create failed',
      uploadFailed: 'Upload failed',
      downloadFailed: 'Download failed',
      syncFailed: 'Sync failed',
      connectFailed: 'Connection failed',
      networkError: 'Network error',
      serverError: 'Server error',
      validationError: 'Validation error',
      permissionDenied: 'Permission denied',
      fileNotFound: 'File not found',
      invalidFormat: 'Invalid format',
      insufficientStorage: 'Insufficient storage',
    },
    warning: {
      unsavedChanges: 'You have unsaved changes',
      lowBattery: 'Low battery',
      lowStorage: 'Low storage',
      noInternet: 'No internet connection',
      locationDisabled: 'Location service disabled',
      bluetoothDisabled: 'Bluetooth disabled',
      gpsInaccurate: 'GPS accuracy low',
      dataOutdated: 'Data outdated',
    },
    info: {
      loading: 'Loading...',
      saving: 'Saving...',
      uploading: 'Uploading...',
      downloading: 'Downloading...',
      syncing: 'Syncing...',
      connecting: 'Connecting...',
      processing: 'Processing...',
      searching: 'Searching...',
      noData: 'No data',
      noResults: 'No results',
      emptyList: 'Empty list',
      selectItem: 'Select item',
      tapToRetry: 'Tap to retry',
    },
  },

  // Confirmations and dialogs
  dialogs: {
    confirmDelete: 'Are you sure you want to delete?',
    confirmLogout: 'Do you want to logout?',
    confirmCancel: 'Do you want to cancel changes?',
    confirmOverwrite: 'Do you want to overwrite existing file?',
    confirmSync: 'Do you want to sync data?',
    confirmReset: 'Do you want to reset settings?',
    selectLanguage: 'Select Language',
    selectTheme: 'Select Theme',
    selectUnits: 'Select Units',
    enterPassword: 'Enter Password',
    enterName: 'Enter Name',
    enterDescription: 'Enter Description',
  },

  // Settings and preferences
  settings: {
    general: 'General',
    account: 'Account',
    appearance: 'Appearance',
    language: 'Language',
    units: 'Units',
    location: 'Location',
    bluetooth: 'Bluetooth',
    sync: 'Sync',
    storage: 'Storage',
    security: 'Security',
    privacy: 'Privacy',
    notifications: 'Notifications',
    about: 'About',
    help: 'Help',
    feedback: 'Feedback',
    version: 'Version',
    buildNumber: 'Build Number',
    developer: 'Developer',
    license: 'License',
    termsOfService: 'Terms of Service',
    privacyPolicy: 'Privacy Policy',
  },

  // Units and measurements
  units: {
    metric: 'Metric',
    imperial: 'Imperial',
    meters: 'Meters',
    feet: 'Feet',
    kilometers: 'Kilometers',
    miles: 'Miles',
    degrees: 'Degrees',
    radians: 'Radians',
    squareMeters: 'Square Meters',
    squareFeet: 'Square Feet',
    hectares: 'Hectares',
    acres: 'Acres',
    celsius: 'Celsius',
    fahrenheit: 'Fahrenheit',
  },

  // Reports and statistics
  reports: {
    surveyReport: 'Survey Report',
    progressReport: 'Progress Report',
    summaryReport: 'Summary Report',
    detailedReport: 'Detailed Report',
    statisticsReport: 'Statistics Report',
    qualityReport: 'Quality Report',
    timeReport: 'Time Report',
    costReport: 'Cost Report',
    clientReport: 'Client Report',
    technicalReport: 'Technical Report',
    executiveSummary: 'Executive Summary',
    recommendations: 'Recommendations',
    conclusions: 'Conclusions',
    methodology: 'Methodology',
    limitations: 'Limitations',
    references: 'References',
    appendices: 'Appendices',
  },

  // Bluetooth and devices
  bluetooth: {
    scanning: 'Scanning for devices...',
    connecting: 'Connecting...',
    connected: 'Connected',
    disconnected: 'Disconnected',
    pairing: 'Pairing...',
    paired: 'Paired',
    unpaired: 'Unpaired',
    available: 'Available',
    unavailable: 'Unavailable',
    deviceName: 'Device Name',
    deviceType: 'Device Type',
    signalStrength: 'Signal Strength',
    batteryLevel: 'Battery Level',
    lastSeen: 'Last Seen',
    gpsReceiver: 'GPS Receiver',
    laserMeter: 'Laser Meter',
    totalStation: 'Total Station',
    level: 'Level',
    compass: 'Compass',
    unknown: 'Unknown',
  },

  // Augmented Reality
  ar: {
    startAR: 'Start AR',
    stopAR: 'Stop AR',
    calibrating: 'Calibrating...',
    calibrated: 'Calibrated',
    trackingLost: 'Tracking Lost',
    trackingRestored: 'Tracking Restored',
    placingMarker: 'Placing Marker',
    markerPlaced: 'Marker Placed',
    selectPoint: 'Select Point',
    measureDistance: 'Measure Distance',
    measureArea: 'Measure Area',
    measureAngle: 'Measure Angle',
    viewBoundaries: 'View Boundaries',
    viewPoints: 'View Points',
    viewLines: 'View Lines',
    viewAreas: 'View Areas',
    cameraPermission: 'Camera permission required',
    arNotSupported: 'AR not supported',
  },

  // Collaboration
  collaboration: {
    online: 'Online',
    offline: 'Offline',
    connecting: 'Connecting...',
    reconnecting: 'Reconnecting...',
    connected: 'Connected',
    disconnected: 'Disconnected',
    joinProject: 'Join Project',
    leaveProject: 'Leave Project',
    inviteUser: 'Invite User',
    removeUser: 'Remove User',
    shareLocation: 'Share Location',
    shareData: 'Share Data',
    sendMessage: 'Send Message',
    receiveMessage: 'Receive Message',
    typing: 'Typing...',
    lastSeen: 'Last Seen',
    activeUsers: 'Active Users',
    recentActivity: 'Recent Activity',
    chatHistory: 'Chat History',
    notifications: 'Notifications',
    permissions: 'Permissions',
    moderator: 'Moderator',
    participant: 'Participant',
    viewer: 'Viewer',
  },

  // Offline Maps
  offlineMaps: {
    downloadMap: 'Download Map',
    deleteMap: 'Delete Map',
    mapDownloaded: 'Map Downloaded',
    mapDeleted: 'Map Deleted',
    downloading: 'Downloading...',
    downloadProgress: 'Download Progress',
    downloadComplete: 'Download Complete',
    downloadFailed: 'Download Failed',
    downloadCancelled: 'Download Cancelled',
    mapSize: 'Map Size',
    storageUsed: 'Storage Used',
    storageAvailable: 'Storage Available',
    selectArea: 'Select Area',
    zoomLevel: 'Zoom Level',
    tileCount: 'Tile Count',
    estimatedSize: 'Estimated Size',
    mapProvider: 'Map Provider',
    satellite: 'Satellite',
    terrain: 'Terrain',
    street: 'Street',
    hybrid: 'Hybrid',
  },

  // CAD/GIS
  cadgis: {
    importFile: 'Import File',
    exportFile: 'Export File',
    fileImported: 'File Imported',
    fileExported: 'File Exported',
    importFailed: 'Import Failed',
    exportFailed: 'Export Failed',
    unsupportedFormat: 'Unsupported Format',
    fileSize: 'File Size',
    fileType: 'File Type',
    fileName: 'File Name',
    filePath: 'File Path',
    lastModified: 'Last Modified',
    layers: 'Layers',
    features: 'Features',
    attributes: 'Attributes',
    coordinates: 'Coordinates',
    projection: 'Projection',
    datum: 'Datum',
    units: 'Units',
    scale: 'Scale',
    precision: 'Precision',
    tolerance: 'Tolerance',
    validation: 'Validation',
    conversion: 'Conversion',
    transformation: 'Transformation',
  },

  // Date and time
  dateTime: {
    today: 'Today',
    yesterday: 'Yesterday',
    tomorrow: 'Tomorrow',
    thisWeek: 'This Week',
    lastWeek: 'Last Week',
    nextWeek: 'Next Week',
    thisMonth: 'This Month',
    lastMonth: 'Last Month',
    nextMonth: 'Next Month',
    thisYear: 'This Year',
    lastYear: 'Last Year',
    nextYear: 'Next Year',
    now: 'Now',
    soon: 'Soon',
    later: 'Later',
    never: 'Never',
    always: 'Always',
    morning: 'Morning',
    afternoon: 'Afternoon',
    evening: 'Evening',
    night: 'Night',
    dawn: 'Dawn',
    sunrise: 'Sunrise',
    sunset: 'Sunset',
    midnight: 'Midnight',
    noon: 'Noon',
  },

  // Weekdays
  weekdays: {
    sunday: 'Sunday',
    monday: 'Monday',
    tuesday: 'Tuesday',
    wednesday: 'Wednesday',
    thursday: 'Thursday',
    friday: 'Friday',
    saturday: 'Saturday',
  },

  // Months
  months: {
    january: 'January',
    february: 'February',
    march: 'March',
    april: 'April',
    may: 'May',
    june: 'June',
    july: 'July',
    august: 'August',
    september: 'September',
    october: 'October',
    november: 'November',
    december: 'December',
  },
};

// إعدادات i18n
const resources = {
  ar: { translation: arabicTranslations },
  en: { translation: englishTranslations },
};

class LocalizationService {
  private static instance: LocalizationService;
  private currentLanguage: string = 'ar';
  private supportedLanguages = ['ar', 'en'];
  private isRTL: boolean = true;

  constructor() {
    this.initializeI18n();
  }

  static getInstance(): LocalizationService {
    if (!LocalizationService.instance) {
      LocalizationService.instance = new LocalizationService();
    }
    return LocalizationService.instance;
  }

  /**
   * تهيئة نظام الترجمة
   */
  private async initializeI18n(): Promise<void> {
    try {
      // تحميل اللغة المحفوظة
      const savedLanguage = await AsyncStorage.getItem('app_language');
      
      // تحديد اللغة الافتراضية
      let defaultLanguage = 'ar';
      
      if (savedLanguage && this.supportedLanguages.includes(savedLanguage)) {
        defaultLanguage = savedLanguage;
      } else {
        // استخدام لغة النظام إذا كانت مدعومة
        const deviceLanguages = RNLocalize.getLocales();
        const deviceLanguage = deviceLanguages[0]?.languageCode;
        
        if (deviceLanguage && this.supportedLanguages.includes(deviceLanguage)) {
          defaultLanguage = deviceLanguage;
        }
      }

      await i18n
        .use(initReactI18next)
        .init({
          resources,
          lng: defaultLanguage,
          fallbackLng: 'ar',
          interpolation: {
            escapeValue: false,
          },
          react: {
            useSuspense: false,
          },
        });

      this.currentLanguage = defaultLanguage;
      this.isRTL = defaultLanguage === 'ar';

      console.log(`تم تهيئة نظام الترجمة باللغة: ${defaultLanguage}`);
    } catch (error) {
      console.error('خطأ في تهيئة نظام الترجمة:', error);
    }
  }

  /**
   * تغيير اللغة
   */
  async changeLanguage(languageCode: string): Promise<boolean> {
    try {
      if (!this.supportedLanguages.includes(languageCode)) {
        console.warn(`اللغة غير مدعومة: ${languageCode}`);
        return false;
      }

      await i18n.changeLanguage(languageCode);
      await AsyncStorage.setItem('app_language', languageCode);
      
      this.currentLanguage = languageCode;
      this.isRTL = languageCode === 'ar';

      console.log(`تم تغيير اللغة إلى: ${languageCode}`);
      return true;
    } catch (error) {
      console.error('خطأ في تغيير اللغة:', error);
      return false;
    }
  }

  /**
   * الحصول على اللغة الحالية
   */
  getCurrentLanguage(): string {
    return this.currentLanguage;
  }

  /**
   * الحصول على اللغات المدعومة
   */
  getSupportedLanguages(): Array<{code: string, name: string, nativeName: string}> {
    return [
      { code: 'ar', name: 'Arabic', nativeName: 'العربية' },
      { code: 'en', name: 'English', nativeName: 'English' },
    ];
  }

  /**
   * التحقق من اتجاه الكتابة
   */
  isRightToLeft(): boolean {
    return this.isRTL;
  }

  /**
   * الحصول على اتجاه الكتابة
   */
  getTextDirection(): 'ltr' | 'rtl' {
    return this.isRTL ? 'rtl' : 'ltr';
  }

  /**
   * ترجمة نص
   */
  translate(key: string, options?: any): string {
    return i18n.t(key, options);
  }

  /**
   * ترجمة مع دعم المتغيرات
   */
  translateWithParams(key: string, params: Record<string, any>): string {
    return i18n.t(key, params);
  }

  /**
   * التحقق من وجود ترجمة
   */
  hasTranslation(key: string): boolean {
    return i18n.exists(key);
  }

  /**
   * الحصول على جميع الترجمات للغة الحالية
   */
  getCurrentTranslations(): any {
    return i18n.getResourceBundle(this.currentLanguage, 'translation');
  }

  /**
   * تنسيق التاريخ حسب اللغة
   */
  formatDate(date: Date, options?: Intl.DateTimeFormatOptions): string {
    const locale = this.currentLanguage === 'ar' ? 'ar-SA' : 'en-US';
    return date.toLocaleDateString(locale, options);
  }

  /**
   * تنسيق الوقت حسب اللغة
   */
  formatTime(date: Date, options?: Intl.DateTimeFormatOptions): string {
    const locale = this.currentLanguage === 'ar' ? 'ar-SA' : 'en-US';
    return date.toLocaleTimeString(locale, options);
  }

  /**
   * تنسيق الأرقام حسب اللغة
   */
  formatNumber(number: number, options?: Intl.NumberFormatOptions): string {
    const locale = this.currentLanguage === 'ar' ? 'ar-SA' : 'en-US';
    return number.toLocaleString(locale, options);
  }

  /**
   * تنسيق العملة حسب اللغة
   */
  formatCurrency(amount: number, currency: string = 'SAR'): string {
    const locale = this.currentLanguage === 'ar' ? 'ar-SA' : 'en-US';
    return amount.toLocaleString(locale, {
      style: 'currency',
      currency,
    });
  }

  /**
   * الحصول على اسم اللغة
   */
  getLanguageName(code: string): string {
    const language = this.getSupportedLanguages().find(lang => lang.code === code);
    return language ? language.nativeName : code;
  }

  /**
   * إعادة تحميل الترجمات
   */
  async reloadTranslations(): Promise<void> {
    try {
      await i18n.reloadResources();
      console.log('تم إعادة تحميل الترجمات');
    } catch (error) {
      console.error('خطأ في إعادة تحميل الترجمات:', error);
    }
  }

  /**
   * إضافة ترجمات جديدة
   */
  addTranslations(language: string, namespace: string, translations: any): void {
    try {
      i18n.addResourceBundle(language, namespace, translations, true, true);
      console.log(`تم إضافة ترجمات جديدة للغة: ${language}`);
    } catch (error) {
      console.error('خطأ في إضافة الترجمات:', error);
    }
  }

  /**
   * الحصول على معلومات الجهاز المحلية
   */
  getDeviceLocaleInfo(): any {
    return {
      locales: RNLocalize.getLocales(),
      currencies: RNLocalize.getCurrencies(),
      country: RNLocalize.getCountry(),
      timeZone: RNLocalize.getTimeZone(),
      uses24HourClock: RNLocalize.uses24HourClock(),
      usesMetricSystem: RNLocalize.usesMetricSystem(),
    };
  }
}

export default LocalizationService.getInstance();
export { i18n };

