/**
 * خدمة جمع البيانات المساحية
 * Survey Data Collection Service
 */

import AsyncStorage from '@react-native-async-storage/async-storage';
import RNFS from 'react-native-fs';
import { LocationCoordinates, SurveyPoint } from './LocationService';

export interface SurveyProject {
  id: string;
  name: string;
  description: string;
  location: string;
  createdAt: Date;
  updatedAt: Date;
  status: 'draft' | 'active' | 'completed' | 'archived';
  points: SurveyPoint[];
  boundaries: SurveyBoundary[];
  measurements: SurveyMeasurement[];
  photos: SurveyPhoto[];
  notes: SurveyNote[];
}

export interface SurveyBoundary {
  id: string;
  name: string;
  points: LocationCoordinates[];
  area: number;
  perimeter: number;
  type: 'property' | 'building' | 'zone';
  createdAt: Date;
}

export interface SurveyMeasurement {
  id: string;
  type: 'distance' | 'angle' | 'elevation' | 'area';
  value: number;
  unit: string;
  fromPoint?: string;
  toPoint?: string;
  notes?: string;
  createdAt: Date;
}

export interface SurveyPhoto {
  id: string;
  uri: string;
  location?: LocationCoordinates;
  direction?: number;
  description?: string;
  pointId?: string;
  createdAt: Date;
}

export interface SurveyNote {
  id: string;
  content: string;
  location?: LocationCoordinates;
  pointId?: string;
  type: 'general' | 'warning' | 'measurement' | 'observation';
  createdAt: Date;
}

class DataCollectionService {
  private readonly STORAGE_KEY = 'survey_projects';
  private readonly PHOTOS_DIR = `${RNFS.DocumentDirectoryPath}/survey_photos`;

  constructor() {
    this.initializeStorage();
  }

  /**
   * تهيئة التخزين المحلي
   */
  private async initializeStorage(): Promise<void> {
    try {
      // إنشاء مجلد الصور إذا لم يكن موجوداً
      const photosExists = await RNFS.exists(this.PHOTOS_DIR);
      if (!photosExists) {
        await RNFS.mkdir(this.PHOTOS_DIR);
      }
    } catch (error) {
      console.error('خطأ في تهيئة التخزين:', error);
    }
  }

  /**
   * إنشاء مشروع مسح جديد
   */
  async createProject(name: string, description: string, location: string): Promise<SurveyProject> {
    const project: SurveyProject = {
      id: Date.now().toString(),
      name,
      description,
      location,
      createdAt: new Date(),
      updatedAt: new Date(),
      status: 'draft',
      points: [],
      boundaries: [],
      measurements: [],
      photos: [],
      notes: [],
    };

    await this.saveProject(project);
    return project;
  }

  /**
   * حفظ مشروع المسح
   */
  async saveProject(project: SurveyProject): Promise<void> {
    try {
      const projects = await this.getAllProjects();
      const existingIndex = projects.findIndex(p => p.id === project.id);
      
      project.updatedAt = new Date();
      
      if (existingIndex >= 0) {
        projects[existingIndex] = project;
      } else {
        projects.push(project);
      }

      await AsyncStorage.setItem(this.STORAGE_KEY, JSON.stringify(projects));
    } catch (error) {
      console.error('خطأ في حفظ المشروع:', error);
      throw new Error('فشل في حفظ المشروع');
    }
  }

  /**
   * الحصول على جميع المشاريع
   */
  async getAllProjects(): Promise<SurveyProject[]> {
    try {
      const data = await AsyncStorage.getItem(this.STORAGE_KEY);
      if (!data) return [];
      
      const projects = JSON.parse(data);
      return projects.map((p: any) => ({
        ...p,
        createdAt: new Date(p.createdAt),
        updatedAt: new Date(p.updatedAt),
        points: p.points.map((point: any) => ({
          ...point,
          createdAt: new Date(point.createdAt),
          updatedAt: new Date(point.updatedAt),
        })),
        boundaries: p.boundaries.map((boundary: any) => ({
          ...boundary,
          createdAt: new Date(boundary.createdAt),
        })),
        measurements: p.measurements.map((measurement: any) => ({
          ...measurement,
          createdAt: new Date(measurement.createdAt),
        })),
        photos: p.photos.map((photo: any) => ({
          ...photo,
          createdAt: new Date(photo.createdAt),
        })),
        notes: p.notes.map((note: any) => ({
          ...note,
          createdAt: new Date(note.createdAt),
        })),
      }));
    } catch (error) {
      console.error('خطأ في قراءة المشاريع:', error);
      return [];
    }
  }

  /**
   * الحصول على مشروع بالمعرف
   */
  async getProject(id: string): Promise<SurveyProject | null> {
    const projects = await this.getAllProjects();
    return projects.find(p => p.id === id) || null;
  }

  /**
   * إضافة نقطة مسح جديدة
   */
  async addSurveyPoint(
    projectId: string,
    name: string,
    coordinates: LocationCoordinates,
    type: SurveyPoint['type'],
    notes?: string
  ): Promise<SurveyPoint> {
    const project = await this.getProject(projectId);
    if (!project) {
      throw new Error('المشروع غير موجود');
    }

    const point: SurveyPoint = {
      id: Date.now().toString(),
      name,
      coordinates,
      type,
      notes,
      photos: [],
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    project.points.push(point);
    await this.saveProject(project);
    
    return point;
  }

  /**
   * إضافة حدود مساحية
   */
  async addBoundary(
    projectId: string,
    name: string,
    points: LocationCoordinates[],
    type: SurveyBoundary['type']
  ): Promise<SurveyBoundary> {
    const project = await this.getProject(projectId);
    if (!project) {
      throw new Error('المشروع غير موجود');
    }

    // حساب المساحة والمحيط
    const area = this.calculatePolygonArea(points);
    const perimeter = this.calculatePerimeter(points);

    const boundary: SurveyBoundary = {
      id: Date.now().toString(),
      name,
      points,
      area,
      perimeter,
      type,
      createdAt: new Date(),
    };

    project.boundaries.push(boundary);
    await this.saveProject(project);
    
    return boundary;
  }

  /**
   * إضافة قياس
   */
  async addMeasurement(
    projectId: string,
    type: SurveyMeasurement['type'],
    value: number,
    unit: string,
    fromPoint?: string,
    toPoint?: string,
    notes?: string
  ): Promise<SurveyMeasurement> {
    const project = await this.getProject(projectId);
    if (!project) {
      throw new Error('المشروع غير موجود');
    }

    const measurement: SurveyMeasurement = {
      id: Date.now().toString(),
      type,
      value,
      unit,
      fromPoint,
      toPoint,
      notes,
      createdAt: new Date(),
    };

    project.measurements.push(measurement);
    await this.saveProject(project);
    
    return measurement;
  }

  /**
   * إضافة صورة
   */
  async addPhoto(
    projectId: string,
    uri: string,
    location?: LocationCoordinates,
    direction?: number,
    description?: string,
    pointId?: string
  ): Promise<SurveyPhoto> {
    const project = await this.getProject(projectId);
    if (!project) {
      throw new Error('المشروع غير موجود');
    }

    // نسخ الصورة إلى مجلد التطبيق
    const fileName = `${Date.now()}.jpg`;
    const newPath = `${this.PHOTOS_DIR}/${fileName}`;
    await RNFS.copyFile(uri, newPath);

    const photo: SurveyPhoto = {
      id: Date.now().toString(),
      uri: newPath,
      location,
      direction,
      description,
      pointId,
      createdAt: new Date(),
    };

    project.photos.push(photo);
    await this.saveProject(project);
    
    return photo;
  }

  /**
   * إضافة ملاحظة
   */
  async addNote(
    projectId: string,
    content: string,
    type: SurveyNote['type'],
    location?: LocationCoordinates,
    pointId?: string
  ): Promise<SurveyNote> {
    const project = await this.getProject(projectId);
    if (!project) {
      throw new Error('المشروع غير موجود');
    }

    const note: SurveyNote = {
      id: Date.now().toString(),
      content,
      type,
      location,
      pointId,
      createdAt: new Date(),
    };

    project.notes.push(note);
    await this.saveProject(project);
    
    return note;
  }

  /**
   * تصدير بيانات المشروع إلى CSV
   */
  async exportProjectToCSV(projectId: string): Promise<string> {
    const project = await this.getProject(projectId);
    if (!project) {
      throw new Error('المشروع غير موجود');
    }

    let csv = 'نوع البيانات,المعرف,الاسم,خط العرض,خط الطول,الدقة,النوع,الملاحظات,التاريخ\n';

    // إضافة النقاط
    project.points.forEach(point => {
      csv += `نقطة,${point.id},${point.name},${point.coordinates.latitude},${point.coordinates.longitude},${point.coordinates.accuracy},${point.type},${point.notes || ''},${point.createdAt.toISOString()}\n`;
    });

    // إضافة القياسات
    project.measurements.forEach(measurement => {
      csv += `قياس,${measurement.id},${measurement.type},,,${measurement.value},${measurement.unit},${measurement.notes || ''},${measurement.createdAt.toISOString()}\n`;
    });

    const fileName = `survey_${project.id}_${Date.now()}.csv`;
    const filePath = `${RNFS.DocumentDirectoryPath}/${fileName}`;
    
    await RNFS.writeFile(filePath, csv, 'utf8');
    return filePath;
  }

  /**
   * حساب مساحة المضلع
   */
  private calculatePolygonArea(points: LocationCoordinates[]): number {
    if (points.length < 3) return 0;

    let area = 0;
    const n = points.length;

    for (let i = 0; i < n; i++) {
      const j = (i + 1) % n;
      const xi = points[i].longitude;
      const yi = points[i].latitude;
      const xj = points[j].longitude;
      const yj = points[j].latitude;
      area += xi * yj - xj * yi;
    }

    area = Math.abs(area) / 2;
    
    // تحويل من درجات إلى متر مربع (تقريبي)
    const metersPerDegree = 111320;
    return area * metersPerDegree * metersPerDegree;
  }

  /**
   * حساب محيط المضلع
   */
  private calculatePerimeter(points: LocationCoordinates[]): number {
    if (points.length < 2) return 0;

    let perimeter = 0;
    for (let i = 0; i < points.length; i++) {
      const current = points[i];
      const next = points[(i + 1) % points.length];
      perimeter += this.calculateDistance(current, next);
    }

    return perimeter;
  }

  /**
   * حساب المسافة بين نقطتين
   */
  private calculateDistance(
    point1: { latitude: number; longitude: number },
    point2: { latitude: number; longitude: number }
  ): number {
    const R = 6371e3;
    const φ1 = (point1.latitude * Math.PI) / 180;
    const φ2 = (point2.latitude * Math.PI) / 180;
    const Δφ = ((point2.latitude - point1.latitude) * Math.PI) / 180;
    const Δλ = ((point2.longitude - point1.longitude) * Math.PI) / 180;

    const a =
      Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
      Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

    return R * c;
  }

  /**
   * حذف مشروع
   */
  async deleteProject(projectId: string): Promise<void> {
    const projects = await this.getAllProjects();
    const filteredProjects = projects.filter(p => p.id !== projectId);
    await AsyncStorage.setItem(this.STORAGE_KEY, JSON.stringify(filteredProjects));
  }

  /**
   * الحصول على إحصائيات المشروع
   */
  async getProjectStatistics(projectId: string): Promise<{
    totalPoints: number;
    totalBoundaries: number;
    totalMeasurements: number;
    totalPhotos: number;
    totalNotes: number;
    totalArea: number;
    averageAccuracy: number;
  }> {
    const project = await this.getProject(projectId);
    if (!project) {
      throw new Error('المشروع غير موجود');
    }

    const totalArea = project.boundaries.reduce((sum, boundary) => sum + boundary.area, 0);
    const accuracies = project.points
      .map(p => p.coordinates.accuracy)
      .filter(acc => acc !== undefined) as number[];
    const averageAccuracy = accuracies.length > 0 
      ? accuracies.reduce((sum, acc) => sum + acc, 0) / accuracies.length 
      : 0;

    return {
      totalPoints: project.points.length,
      totalBoundaries: project.boundaries.length,
      totalMeasurements: project.measurements.length,
      totalPhotos: project.photos.length,
      totalNotes: project.notes.length,
      totalArea,
      averageAccuracy,
    };
  }
}

export default new DataCollectionService();

