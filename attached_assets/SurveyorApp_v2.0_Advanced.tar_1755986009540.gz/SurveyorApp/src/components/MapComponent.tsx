/**
 * مكون الخريطة التفاعلية
 * Interactive Map Component
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  StyleSheet,
  Alert,
  TouchableOpacity,
  Text,
  Dimensions,
} from 'react-native';
import MapView, { 
  Marker, 
  Polygon, 
  Polyline, 
  PROVIDER_GOOGLE,
  Region,
  LatLng,
  MapPressEvent,
} from 'react-native-maps';
import LocationService, { LocationCoordinates, SurveyPoint } from '../services/LocationService';

interface MapComponentProps {
  initialRegion?: Region;
  points?: SurveyPoint[];
  boundaries?: LatLng[][];
  onMapPress?: (coordinate: LatLng) => void;
  onMarkerPress?: (point: SurveyPoint) => void;
  showCurrentLocation?: boolean;
  editable?: boolean;
  style?: any;
}

const { width, height } = Dimensions.get('window');

const MapComponent: React.FC<MapComponentProps> = ({
  initialRegion,
  points = [],
  boundaries = [],
  onMapPress,
  onMarkerPress,
  showCurrentLocation = true,
  editable = false,
  style,
}) => {
  const mapRef = useRef<MapView>(null);
  const [currentLocation, setCurrentLocation] = useState<LocationCoordinates | null>(null);
  const [region, setRegion] = useState<Region>(
    initialRegion || {
      latitude: 15.3694, // صنعاء
      longitude: 44.1910,
      latitudeDelta: 0.01,
      longitudeDelta: 0.01,
    }
  );
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (showCurrentLocation) {
      getCurrentLocation();
    }
  }, [showCurrentLocation]);

  const getCurrentLocation = async () => {
    try {
      setIsLoading(true);
      const location = await LocationService.getCurrentLocation();
      setCurrentLocation(location);
      
      // تحديث منطقة الخريطة للموقع الحالي
      const newRegion = {
        latitude: location.latitude,
        longitude: location.longitude,
        latitudeDelta: 0.01,
        longitudeDelta: 0.01,
      };
      setRegion(newRegion);
      
      if (mapRef.current) {
        mapRef.current.animateToRegion(newRegion, 1000);
      }
    } catch (error) {
      console.error('خطأ في الحصول على الموقع:', error);
      Alert.alert('خطأ', 'فشل في تحديد الموقع الحالي');
    } finally {
      setIsLoading(false);
    }
  };

  const handleMapPress = (event: MapPressEvent) => {
    if (editable && onMapPress) {
      onMapPress(event.nativeEvent.coordinate);
    }
  };

  const handleMarkerPress = (point: SurveyPoint) => {
    if (onMarkerPress) {
      onMarkerPress(point);
    }
  };

  const getMarkerColor = (type: SurveyPoint['type']): string => {
    switch (type) {
      case 'boundary':
        return '#2196F3';
      case 'corner':
        return '#FF9800';
      case 'reference':
        return '#4CAF50';
      case 'building':
        return '#F44336';
      default:
        return '#9C27B0';
    }
  };

  const zoomToFitPoints = () => {
    if (points.length === 0) return;

    const coordinates = points.map(point => ({
      latitude: point.coordinates.latitude,
      longitude: point.coordinates.longitude,
    }));

    if (currentLocation) {
      coordinates.push({
        latitude: currentLocation.latitude,
        longitude: currentLocation.longitude,
      });
    }

    if (mapRef.current) {
      mapRef.current.fitToCoordinates(coordinates, {
        edgePadding: { top: 50, right: 50, bottom: 50, left: 50 },
        animated: true,
      });
    }
  };

  const centerOnCurrentLocation = () => {
    if (currentLocation && mapRef.current) {
      const newRegion = {
        latitude: currentLocation.latitude,
        longitude: currentLocation.longitude,
        latitudeDelta: 0.005,
        longitudeDelta: 0.005,
      };
      mapRef.current.animateToRegion(newRegion, 1000);
    } else {
      getCurrentLocation();
    }
  };

  return (
    <View style={[styles.container, style]}>
      <MapView
        ref={mapRef}
        provider={PROVIDER_GOOGLE}
        style={styles.map}
        region={region}
        onRegionChangeComplete={setRegion}
        onPress={handleMapPress}
        showsUserLocation={showCurrentLocation}
        showsMyLocationButton={false}
        showsCompass={true}
        showsScale={true}
        mapType="hybrid"
        loadingEnabled={isLoading}
      >
        {/* الموقع الحالي */}
        {currentLocation && (
          <Marker
            coordinate={{
              latitude: currentLocation.latitude,
              longitude: currentLocation.longitude,
            }}
            title="موقعي الحالي"
            description={`الدقة: ±${currentLocation.accuracy.toFixed(1)} متر`}
            pinColor="#2196F3"
          />
        )}

        {/* نقاط المسح */}
        {points.map((point) => (
          <Marker
            key={point.id}
            coordinate={{
              latitude: point.coordinates.latitude,
              longitude: point.coordinates.longitude,
            }}
            title={point.name}
            description={point.notes || `${point.type} - ${point.coordinates.accuracy.toFixed(1)}م`}
            pinColor={getMarkerColor(point.type)}
            onPress={() => handleMarkerPress(point)}
          />
        ))}

        {/* الحدود */}
        {boundaries.map((boundary, index) => (
          <Polygon
            key={index}
            coordinates={boundary}
            strokeColor="#FF0000"
            fillColor="rgba(255,0,0,0.2)"
            strokeWidth={2}
          />
        ))}

        {/* خطوط الربط بين النقاط */}
        {points.length > 1 && (
          <Polyline
            coordinates={points.map(point => ({
              latitude: point.coordinates.latitude,
              longitude: point.coordinates.longitude,
            }))}
            strokeColor="#4CAF50"
            strokeWidth={2}
            lineDashPattern={[5, 5]}
          />
        )}
      </MapView>

      {/* أدوات التحكم */}
      <View style={styles.controls}>
        <TouchableOpacity
          style={styles.controlButton}
          onPress={centerOnCurrentLocation}
        >
          <Text style={styles.controlButtonText}>📍</Text>
        </TouchableOpacity>

        {points.length > 0 && (
          <TouchableOpacity
            style={styles.controlButton}
            onPress={zoomToFitPoints}
          >
            <Text style={styles.controlButtonText}>🔍</Text>
          </TouchableOpacity>
        )}

        <TouchableOpacity
          style={styles.controlButton}
          onPress={() => {
            if (mapRef.current) {
              mapRef.current.animateToRegion({
                ...region,
                latitudeDelta: region.latitudeDelta * 0.5,
                longitudeDelta: region.longitudeDelta * 0.5,
              }, 500);
            }
          }}
        >
          <Text style={styles.controlButtonText}>➕</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.controlButton}
          onPress={() => {
            if (mapRef.current) {
              mapRef.current.animateToRegion({
                ...region,
                latitudeDelta: region.latitudeDelta * 2,
                longitudeDelta: region.longitudeDelta * 2,
              }, 500);
            }
          }}
        >
          <Text style={styles.controlButtonText}>➖</Text>
        </TouchableOpacity>
      </View>

      {/* معلومات الخريطة */}
      <View style={styles.mapInfo}>
        <Text style={styles.mapInfoText}>
          المقياس: 1:{Math.round(region.latitudeDelta * 111000).toLocaleString()}
        </Text>
        {currentLocation && (
          <Text style={styles.mapInfoText}>
            الدقة: ±{currentLocation.accuracy.toFixed(1)}م
          </Text>
        )}
      </View>

      {/* مؤشر التحميل */}
      {isLoading && (
        <View style={styles.loadingOverlay}>
          <Text style={styles.loadingText}>جاري تحديد الموقع...</Text>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  map: {
    flex: 1,
  },
  controls: {
    position: 'absolute',
    top: 20,
    right: 20,
    flexDirection: 'column',
  },
  controlButton: {
    width: 44,
    height: 44,
    backgroundColor: 'white',
    borderRadius: 22,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  controlButtonText: {
    fontSize: 18,
  },
  mapInfo: {
    position: 'absolute',
    bottom: 20,
    left: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    padding: 8,
    borderRadius: 8,
  },
  mapInfoText: {
    fontSize: 12,
    color: '#333',
    textAlign: 'right',
  },
  loadingOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    color: 'white',
    fontSize: 16,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    padding: 12,
    borderRadius: 8,
  },
});

export default MapComponent;

