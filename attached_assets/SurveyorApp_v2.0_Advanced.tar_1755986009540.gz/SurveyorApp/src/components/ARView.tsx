import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Dimensions,
  TouchableOpacity,
  Alert,
  Animated,
} from 'react-native';
import { RNCamera } from 'react-native-camera';
import ARService, { ARPoint, DeviceOrientation } from '../services/ARService';

interface ARViewProps {
  surveyPoints?: ARPoint[];
  onPointTap?: (point: ARPoint) => void;
  onCalibrate?: () => void;
  showCalibrationButton?: boolean;
}

const ARView: React.FC<ARViewProps> = ({
  surveyPoints = [],
  onPointTap,
  onCalibrate,
  showCalibrationButton = true,
}) => {
  const [isARReady, setIsARReady] = useState(false);
  const [visiblePoints, setVisiblePoints] = useState<ARPoint[]>([]);
  const [deviceOrientation, setDeviceOrientation] = useState<DeviceOrientation>({
    azimuth: 0,
    pitch: 0,
    roll: 0,
  });
  const [screenDimensions, setScreenDimensions] = useState(Dimensions.get('window'));
  const animatedValues = useRef<Map<string, Animated.Value>>(new Map());

  useEffect(() => {
    initializeAR();
    
    const subscription = Dimensions.addEventListener('change', ({ window }) => {
      setScreenDimensions(window);
    });

    return () => {
      ARService.cleanup();
      subscription?.remove();
    };
  }, []);

  useEffect(() => {
    // تحديث نقاط AR عند تغيير نقاط المسح
    surveyPoints.forEach(point => {
      ARService.addARPoint(point);
    });
    
    updateVisiblePoints();
  }, [surveyPoints]);

  /**
   * تهيئة خدمة الواقع المعزز
   */
  const initializeAR = async () => {
    try {
      const success = await ARService.initialize();
      if (success) {
        setIsARReady(true);
        startARLoop();
      } else {
        Alert.alert('خطأ', 'فشل في تهيئة الواقع المعزز');
      }
    } catch (error) {
      Alert.alert('خطأ', 'حدث خطأ في تهيئة الواقع المعزز: ' + error.message);
    }
  };

  /**
   * بدء حلقة تحديث الواقع المعزز
   */
  const startARLoop = () => {
    const updateInterval = setInterval(() => {
      if (ARService.isReady()) {
        updateVisiblePoints();
        updateDeviceOrientation();
      }
    }, 100); // تحديث كل 100ms

    return () => clearInterval(updateInterval);
  };

  /**
   * تحديث النقاط المرئية
   */
  const updateVisiblePoints = () => {
    const visible = ARService.getVisiblePoints();
    setVisiblePoints(visible);
    
    // إنشاء قيم الحركة للنقاط الجديدة
    visible.forEach(point => {
      if (!animatedValues.current.has(point.id)) {
        animatedValues.current.set(point.id, new Animated.Value(0));
        
        // تحريك النقطة للظهور
        Animated.spring(animatedValues.current.get(point.id)!, {
          toValue: 1,
          useNativeDriver: true,
          tension: 100,
          friction: 8,
        }).start();
      }
    });
  };

  /**
   * تحديث اتجاه الجهاز
   */
  const updateDeviceOrientation = () => {
    const orientation = ARService.getDeviceOrientation();
    setDeviceOrientation(orientation);
  };

  /**
   * معالج النقر على نقطة AR
   */
  const handlePointTap = (point: ARPoint) => {
    // تأثير بصري للنقر
    const animValue = animatedValues.current.get(point.id);
    if (animValue) {
      Animated.sequence([
        Animated.timing(animValue, {
          toValue: 1.3,
          duration: 150,
          useNativeDriver: true,
        }),
        Animated.timing(animValue, {
          toValue: 1,
          duration: 150,
          useNativeDriver: true,
        }),
      ]).start();
    }

    if (onPointTap) {
      onPointTap(point);
    }
  };

  /**
   * معايرة البوصلة
   */
  const handleCalibration = () => {
    Alert.alert(
      'معايرة البوصلة',
      'قم بتحريك الجهاز في شكل رقم 8 لمدة 10 ثوانٍ لمعايرة البوصلة',
      [
        { text: 'إلغاء', style: 'cancel' },
        {
          text: 'بدء المعايرة',
          onPress: () => {
            ARService.calibrateCompass();
            if (onCalibrate) {
              onCalibrate();
            }
          },
        },
      ]
    );
  };

  /**
   * عرض نقطة AR على الشاشة
   */
  const renderARPoint = (point: ARPoint) => {
    const screenPosition = ARService.calculateScreenPosition(
      point,
      screenDimensions.width,
      screenDimensions.height
    );

    if (!screenPosition) return null;

    const animValue = animatedValues.current.get(point.id) || new Animated.Value(1);
    const distance = point.distance ? Math.round(point.distance) : 0;

    return (
      <Animated.View
        key={point.id}
        style={[
          styles.arPoint,
          {
            left: screenPosition.x - 25, // نصف عرض النقطة
            top: screenPosition.y - 25,  // نصف ارتفاع النقطة
            backgroundColor: point.color,
            transform: [
              {
                scale: Animated.multiply(animValue, screenPosition.scale),
              },
            ],
          },
        ]}
      >
        <TouchableOpacity
          style={styles.arPointTouchable}
          onPress={() => handlePointTap(point)}
          activeOpacity={0.7}
        >
          <View style={styles.arPointContent}>
            <Text style={styles.arPointLabel}>{point.label}</Text>
            <Text style={styles.arPointDistance}>{distance}م</Text>
          </View>
          
          {/* مؤشر نوع النقطة */}
          <View style={[styles.arPointIndicator, { backgroundColor: point.color }]}>
            <Text style={styles.arPointType}>
              {point.type === 'survey_point' ? '📍' :
               point.type === 'boundary' ? '🚧' :
               point.type === 'reference' ? '🎯' : '🏢'}
            </Text>
          </View>
        </TouchableOpacity>
      </Animated.View>
    );
  };

  /**
   * عرض معلومات الاتجاه
   */
  const renderOrientationInfo = () => (
    <View style={styles.orientationInfo}>
      <Text style={styles.orientationText}>
        الاتجاه: {Math.round(deviceOrientation.azimuth)}°
      </Text>
      <Text style={styles.orientationText}>
        الميل: {Math.round(deviceOrientation.pitch)}°
      </Text>
      <Text style={styles.orientationText}>
        الدوران: {Math.round(deviceOrientation.roll)}°
      </Text>
    </View>
  );

  /**
   * عرض البوصلة
   */
  const renderCompass = () => (
    <View style={styles.compass}>
      <View style={[styles.compassNeedle, {
        transform: [{ rotate: `${deviceOrientation.azimuth}deg` }]
      }]} />
      <Text style={styles.compassText}>ش</Text>
    </View>
  );

  if (!isARReady) {
    return (
      <View style={styles.loadingContainer}>
        <Text style={styles.loadingText}>جاري تهيئة الواقع المعزز...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* كاميرا الواقع المعزز */}
      <RNCamera
        style={styles.camera}
        type={RNCamera.Constants.Type.back}
        flashMode={RNCamera.Constants.FlashMode.off}
        androidCameraPermissionOptions={{
          title: 'إذن استخدام الكاميرا',
          message: 'نحتاج إذن استخدام الكاميرا لعرض الواقع المعزز',
          buttonPositive: 'موافق',
          buttonNegative: 'إلغاء',
        }}
      />

      {/* طبقة النقاط المعززة */}
      <View style={styles.arOverlay}>
        {visiblePoints.map(point => renderARPoint(point))}
      </View>

      {/* معلومات الاتجاه */}
      {renderOrientationInfo()}

      {/* البوصلة */}
      {renderCompass()}

      {/* أزرار التحكم */}
      <View style={styles.controls}>
        {showCalibrationButton && (
          <TouchableOpacity
            style={styles.calibrateButton}
            onPress={handleCalibration}
          >
            <Text style={styles.calibrateButtonText}>معايرة البوصلة</Text>
          </TouchableOpacity>
        )}
        
        <View style={styles.pointsCounter}>
          <Text style={styles.pointsCounterText}>
            النقاط المرئية: {visiblePoints.length}
          </Text>
        </View>
      </View>

      {/* شبكة الاستهداف */}
      <View style={styles.crosshair}>
        <View style={styles.crosshairHorizontal} />
        <View style={styles.crosshairVertical} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000000',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#000000',
  },
  loadingText: {
    color: '#FFFFFF',
    fontSize: 16,
    textAlign: 'center',
  },
  camera: {
    flex: 1,
  },
  arOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    pointerEvents: 'box-none',
  },
  arPoint: {
    position: 'absolute',
    width: 50,
    height: 50,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
  },
  arPointTouchable: {
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  arPointContent: {
    alignItems: 'center',
  },
  arPointLabel: {
    color: '#FFFFFF',
    fontSize: 8,
    fontWeight: 'bold',
    textAlign: 'center',
    textShadowColor: '#000000',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 2,
  },
  arPointDistance: {
    color: '#FFFFFF',
    fontSize: 6,
    textAlign: 'center',
    marginTop: 2,
    textShadowColor: '#000000',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 2,
  },
  arPointIndicator: {
    position: 'absolute',
    top: -5,
    right: -5,
    width: 20,
    height: 20,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#FFFFFF',
  },
  arPointType: {
    fontSize: 10,
  },
  orientationInfo: {
    position: 'absolute',
    top: 50,
    left: 16,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    padding: 8,
    borderRadius: 8,
  },
  orientationText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontFamily: 'monospace',
  },
  compass: {
    position: 'absolute',
    top: 50,
    right: 16,
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#FFFFFF',
  },
  compassNeedle: {
    position: 'absolute',
    width: 2,
    height: 20,
    backgroundColor: '#FF0000',
    top: 10,
  },
  compassText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: 'bold',
    position: 'absolute',
    top: 5,
  },
  controls: {
    position: 'absolute',
    bottom: 20,
    left: 16,
    right: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  calibrateButton: {
    backgroundColor: 'rgba(33, 150, 243, 0.8)',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
  },
  calibrateButtonText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: 'bold',
  },
  pointsCounter: {
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 15,
  },
  pointsCounterText: {
    color: '#FFFFFF',
    fontSize: 12,
  },
  crosshair: {
    position: 'absolute',
    top: '50%',
    left: '50%',
    width: 30,
    height: 30,
    marginTop: -15,
    marginLeft: -15,
    pointerEvents: 'none',
  },
  crosshairHorizontal: {
    position: 'absolute',
    top: 14,
    left: 0,
    right: 0,
    height: 2,
    backgroundColor: 'rgba(255, 255, 255, 0.8)',
  },
  crosshairVertical: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    left: 14,
    width: 2,
    backgroundColor: 'rgba(255, 255, 255, 0.8)',
  },
});

export default ARView;

