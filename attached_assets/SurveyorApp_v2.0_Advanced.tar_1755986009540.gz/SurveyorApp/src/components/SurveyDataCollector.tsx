/**
 * مكون جمع البيانات المساحية
 * Survey Data Collector Component
 */

import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  Alert,
  TextInput,
  Modal,
  Dimensions,
} from 'react-native';
import LocationService, { LocationCoordinates, SurveyPoint } from '../services/LocationService';
import DataCollectionService, { SurveyProject } from '../services/DataCollectionService';

interface SurveyDataCollectorProps {
  projectId: string;
  onDataUpdated?: () => void;
}

const { width } = Dimensions.get('window');

const SurveyDataCollector: React.FC<SurveyDataCollectorProps> = ({
  projectId,
  onDataUpdated,
}) => {
  const [project, setProject] = useState<SurveyProject | null>(null);
  const [currentLocation, setCurrentLocation] = useState<LocationCoordinates | null>(null);
  const [isTracking, setIsTracking] = useState(false);
  const [showAddPointModal, setShowAddPointModal] = useState(false);
  const [showAddNoteModal, setShowAddNoteModal] = useState(false);
  const [newPointData, setNewPointData] = useState({
    name: '',
    type: 'reference' as SurveyPoint['type'],
    notes: '',
  });
  const [newNote, setNewNote] = useState('');

  useEffect(() => {
    loadProject();
    getCurrentLocation();
  }, [projectId]);

  const loadProject = async () => {
    try {
      const projectData = await DataCollectionService.getProject(projectId);
      setProject(projectData);
    } catch (error) {
      console.error('خطأ في تحميل المشروع:', error);
      Alert.alert('خطأ', 'فشل في تحميل بيانات المشروع');
    }
  };

  const getCurrentLocation = async () => {
    try {
      const location = await LocationService.getCurrentLocation();
      setCurrentLocation(location);
    } catch (error) {
      console.error('خطأ في الحصول على الموقع:', error);
    }
  };

  const startLocationTracking = async () => {
    try {
      await LocationService.startLocationTracking((location) => {
        setCurrentLocation(location);
      });
      setIsTracking(true);
      Alert.alert('تم', 'بدأ تتبع الموقع بنجاح');
    } catch (error) {
      console.error('خطأ في بدء تتبع الموقع:', error);
      Alert.alert('خطأ', 'فشل في بدء تتبع الموقع');
    }
  };

  const stopLocationTracking = () => {
    LocationService.stopLocationTracking();
    setIsTracking(false);
    Alert.alert('تم', 'تم إيقاف تتبع الموقع');
  };

  const addSurveyPoint = async () => {
    if (!currentLocation) {
      Alert.alert('خطأ', 'لا يمكن تحديد الموقع الحالي');
      return;
    }

    if (!newPointData.name.trim()) {
      Alert.alert('خطأ', 'يرجى إدخال اسم النقطة');
      return;
    }

    try {
      await DataCollectionService.addSurveyPoint(
        projectId,
        newPointData.name,
        currentLocation,
        newPointData.type,
        newPointData.notes
      );

      setNewPointData({ name: '', type: 'reference', notes: '' });
      setShowAddPointModal(false);
      await loadProject();
      onDataUpdated?.();
      
      Alert.alert('تم', 'تم إضافة النقطة بنجاح');
    } catch (error) {
      console.error('خطأ في إضافة النقطة:', error);
      Alert.alert('خطأ', 'فشل في إضافة النقطة');
    }
  };

  const addNote = async () => {
    if (!newNote.trim()) {
      Alert.alert('خطأ', 'يرجى إدخال نص الملاحظة');
      return;
    }

    try {
      await DataCollectionService.addNote(
        projectId,
        newNote,
        'general',
        currentLocation || undefined
      );

      setNewNote('');
      setShowAddNoteModal(false);
      await loadProject();
      onDataUpdated?.();
      
      Alert.alert('تم', 'تم إضافة الملاحظة بنجاح');
    } catch (error) {
      console.error('خطأ في إضافة الملاحظة:', error);
      Alert.alert('خطأ', 'فشل في إضافة الملاحظة');
    }
  };

  const calculateDistance = (point1: SurveyPoint, point2: SurveyPoint): number => {
    return LocationService.calculateDistance(
      point1.coordinates,
      point2.coordinates
    );
  };

  const formatCoordinates = (location: LocationCoordinates) => {
    return LocationService.formatCoordinates(location);
  };

  const getPointTypeText = (type: SurveyPoint['type']): string => {
    switch (type) {
      case 'boundary':
        return 'حد';
      case 'corner':
        return 'زاوية';
      case 'reference':
        return 'مرجع';
      case 'building':
        return 'مبنى';
      default:
        return 'غير محدد';
    }
  };

  const getAccuracyColor = (accuracy: number): string => {
    if (accuracy <= 2) return '#4CAF50';
    if (accuracy <= 5) return '#FF9800';
    return '#F44336';
  };

  if (!project) {
    return (
      <View style={styles.loadingContainer}>
        <Text style={styles.loadingText}>جاري تحميل المشروع...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* معلومات الموقع الحالي */}
      <View style={styles.locationSection}>
        <Text style={styles.sectionTitle}>الموقع الحالي</Text>
        {currentLocation ? (
          <View style={styles.locationInfo}>
            <Text style={styles.coordinateText}>
              خط العرض: {formatCoordinates(currentLocation).latitude}
            </Text>
            <Text style={styles.coordinateText}>
              خط الطول: {formatCoordinates(currentLocation).longitude}
            </Text>
            <Text style={[styles.accuracyText, { color: getAccuracyColor(currentLocation.accuracy) }]}>
              الدقة: ±{currentLocation.accuracy.toFixed(1)} متر
            </Text>
            <Text style={styles.timestampText}>
              آخر تحديث: {new Date(currentLocation.timestamp).toLocaleTimeString('ar-SA')}
            </Text>
          </View>
        ) : (
          <Text style={styles.noLocationText}>جاري تحديد الموقع...</Text>
        )}

        <View style={styles.locationControls}>
          <TouchableOpacity
            style={styles.controlButton}
            onPress={getCurrentLocation}
          >
            <Text style={styles.controlButtonText}>تحديث الموقع</Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[styles.controlButton, isTracking && styles.activeButton]}
            onPress={isTracking ? stopLocationTracking : startLocationTracking}
          >
            <Text style={[styles.controlButtonText, isTracking && styles.activeButtonText]}>
              {isTracking ? 'إيقاف التتبع' : 'بدء التتبع'}
            </Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* أدوات جمع البيانات */}
      <View style={styles.toolsSection}>
        <Text style={styles.sectionTitle}>أدوات جمع البيانات</Text>
        <View style={styles.toolsGrid}>
          <TouchableOpacity
            style={styles.toolButton}
            onPress={() => setShowAddPointModal(true)}
            disabled={!currentLocation}
          >
            <Text style={styles.toolIcon}>📍</Text>
            <Text style={styles.toolText}>إضافة نقطة</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.toolButton}
            onPress={() => setShowAddNoteModal(true)}
          >
            <Text style={styles.toolIcon}>📝</Text>
            <Text style={styles.toolText}>إضافة ملاحظة</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.toolButton}
            onPress={() => Alert.alert('قريباً', 'ميزة التصوير ستكون متاحة قريباً')}
          >
            <Text style={styles.toolIcon}>📷</Text>
            <Text style={styles.toolText}>التقاط صورة</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.toolButton}
            onPress={() => Alert.alert('قريباً', 'ميزة القياس ستكون متاحة قريباً')}
          >
            <Text style={styles.toolIcon}>📏</Text>
            <Text style={styles.toolText}>قياس المسافة</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* النقاط المجمعة */}
      <ScrollView style={styles.pointsList} showsVerticalScrollIndicator={false}>
        <Text style={styles.sectionTitle}>النقاط المجمعة ({project.points.length})</Text>
        {project.points.map((point, index) => (
          <View key={point.id} style={styles.pointCard}>
            <View style={styles.pointHeader}>
              <Text style={styles.pointName}>{point.name}</Text>
              <Text style={styles.pointType}>{getPointTypeText(point.type)}</Text>
            </View>
            
            <Text style={styles.pointCoordinates}>
              {formatCoordinates(point.coordinates).latitude}, {formatCoordinates(point.coordinates).longitude}
            </Text>
            
            <View style={styles.pointDetails}>
              <Text style={[styles.pointAccuracy, { color: getAccuracyColor(point.coordinates.accuracy) }]}>
                الدقة: ±{point.coordinates.accuracy.toFixed(1)}م
              </Text>
              <Text style={styles.pointTime}>
                {point.createdAt.toLocaleString('ar-SA')}
              </Text>
            </View>

            {point.notes && (
              <Text style={styles.pointNotes}>{point.notes}</Text>
            )}

            {index > 0 && (
              <Text style={styles.distanceText}>
                المسافة من النقطة السابقة: {calculateDistance(project.points[index - 1], point).toFixed(2)} متر
              </Text>
            )}
          </View>
        ))}
      </ScrollView>

      {/* نافذة إضافة نقطة */}
      <Modal
        visible={showAddPointModal}
        animationType="slide"
        presentationStyle="pageSheet"
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <TouchableOpacity
              onPress={() => setShowAddPointModal(false)}
              style={styles.modalCloseButton}
            >
              <Text style={styles.modalCloseText}>إلغاء</Text>
            </TouchableOpacity>
            <Text style={styles.modalTitle}>إضافة نقطة جديدة</Text>
            <TouchableOpacity
              onPress={addSurveyPoint}
              style={styles.modalSaveButton}
            >
              <Text style={styles.modalSaveText}>حفظ</Text>
            </TouchableOpacity>
          </View>

          <ScrollView style={styles.modalContent}>
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>اسم النقطة *</Text>
              <TextInput
                style={styles.textInput}
                value={newPointData.name}
                onChangeText={(text) => setNewPointData({ ...newPointData, name: text })}
                placeholder="مثال: نقطة الزاوية الشمالية الشرقية"
                placeholderTextColor="#999"
                textAlign="right"
              />
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>نوع النقطة</Text>
              <View style={styles.typeButtons}>
                {(['reference', 'boundary', 'corner', 'building'] as const).map((type) => (
                  <TouchableOpacity
                    key={type}
                    style={[
                      styles.typeButton,
                      newPointData.type === type && styles.activeTypeButton
                    ]}
                    onPress={() => setNewPointData({ ...newPointData, type })}
                  >
                    <Text style={[
                      styles.typeButtonText,
                      newPointData.type === type && styles.activeTypeButtonText
                    ]}>
                      {getPointTypeText(type)}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>ملاحظات</Text>
              <TextInput
                style={[styles.textInput, styles.textArea]}
                value={newPointData.notes}
                onChangeText={(text) => setNewPointData({ ...newPointData, notes: text })}
                placeholder="ملاحظات إضافية حول النقطة..."
                placeholderTextColor="#999"
                multiline
                numberOfLines={3}
                textAlign="right"
                textAlignVertical="top"
              />
            </View>

            {currentLocation && (
              <View style={styles.locationPreview}>
                <Text style={styles.previewTitle}>الموقع الحالي:</Text>
                <Text style={styles.previewText}>
                  {formatCoordinates(currentLocation).latitude}, {formatCoordinates(currentLocation).longitude}
                </Text>
                <Text style={styles.previewAccuracy}>
                  الدقة: ±{currentLocation.accuracy.toFixed(1)} متر
                </Text>
              </View>
            )}
          </ScrollView>
        </View>
      </Modal>

      {/* نافذة إضافة ملاحظة */}
      <Modal
        visible={showAddNoteModal}
        animationType="slide"
        presentationStyle="pageSheet"
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <TouchableOpacity
              onPress={() => setShowAddNoteModal(false)}
              style={styles.modalCloseButton}
            >
              <Text style={styles.modalCloseText}>إلغاء</Text>
            </TouchableOpacity>
            <Text style={styles.modalTitle}>إضافة ملاحظة</Text>
            <TouchableOpacity
              onPress={addNote}
              style={styles.modalSaveButton}
            >
              <Text style={styles.modalSaveText}>حفظ</Text>
            </TouchableOpacity>
          </View>

          <View style={styles.modalContent}>
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>نص الملاحظة *</Text>
              <TextInput
                style={[styles.textInput, styles.textArea]}
                value={newNote}
                onChangeText={setNewNote}
                placeholder="اكتب ملاحظتك هنا..."
                placeholderTextColor="#999"
                multiline
                numberOfLines={5}
                textAlign="right"
                textAlignVertical="top"
              />
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F9FA',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    fontSize: 16,
    color: '#666',
  },
  locationSection: {
    backgroundColor: 'white',
    padding: 16,
    marginBottom: 8,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 12,
    textAlign: 'right',
  },
  locationInfo: {
    marginBottom: 12,
  },
  coordinateText: {
    fontSize: 14,
    color: '#333',
    textAlign: 'right',
    marginBottom: 4,
  },
  accuracyText: {
    fontSize: 14,
    fontWeight: 'bold',
    textAlign: 'right',
    marginBottom: 4,
  },
  timestampText: {
    fontSize: 12,
    color: '#666',
    textAlign: 'right',
  },
  noLocationText: {
    fontSize: 14,
    color: '#666',
    textAlign: 'center',
    fontStyle: 'italic',
    marginBottom: 12,
  },
  locationControls: {
    flexDirection: 'row',
    gap: 8,
  },
  controlButton: {
    flex: 1,
    backgroundColor: '#2E7D32',
    borderRadius: 8,
    padding: 12,
    alignItems: 'center',
  },
  activeButton: {
    backgroundColor: '#F44336',
  },
  controlButtonText: {
    color: 'white',
    fontSize: 14,
    fontWeight: 'bold',
  },
  activeButtonText: {
    color: 'white',
  },
  toolsSection: {
    backgroundColor: 'white',
    padding: 16,
    marginBottom: 8,
  },
  toolsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  toolButton: {
    width: (width - 56) / 2,
    backgroundColor: '#F8F9FA',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#E0E0E0',
  },
  toolIcon: {
    fontSize: 32,
    marginBottom: 8,
  },
  toolText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'center',
  },
  pointsList: {
    flex: 1,
    backgroundColor: 'white',
    padding: 16,
  },
  pointCard: {
    backgroundColor: '#F8F9FA',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#E0E0E0',
  },
  pointHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  pointName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    flex: 1,
    textAlign: 'right',
  },
  pointType: {
    fontSize: 12,
    color: '#666',
    backgroundColor: '#E0E0E0',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  pointCoordinates: {
    fontSize: 14,
    color: '#666',
    textAlign: 'right',
    marginBottom: 8,
    fontFamily: 'monospace',
  },
  pointDetails: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  pointAccuracy: {
    fontSize: 12,
    fontWeight: 'bold',
  },
  pointTime: {
    fontSize: 12,
    color: '#666',
  },
  pointNotes: {
    fontSize: 14,
    color: '#333',
    textAlign: 'right',
    marginBottom: 8,
    fontStyle: 'italic',
  },
  distanceText: {
    fontSize: 12,
    color: '#2E7D32',
    textAlign: 'right',
    fontWeight: 'bold',
  },
  modalContainer: {
    flex: 1,
    backgroundColor: 'white',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
  },
  modalCloseButton: {
    padding: 8,
  },
  modalCloseText: {
    color: '#666',
    fontSize: 16,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  modalSaveButton: {
    padding: 8,
  },
  modalSaveText: {
    color: '#2E7D32',
    fontSize: 16,
    fontWeight: 'bold',
  },
  modalContent: {
    flex: 1,
    padding: 20,
  },
  inputGroup: {
    marginBottom: 20,
  },
  inputLabel: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 8,
    textAlign: 'right',
  },
  textInput: {
    borderWidth: 1,
    borderColor: '#DDD',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    backgroundColor: '#F9F9F9',
    textAlign: 'right',
  },
  textArea: {
    height: 100,
  },
  typeButtons: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  typeButton: {
    backgroundColor: '#F0F0F0',
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderWidth: 1,
    borderColor: '#DDD',
  },
  activeTypeButton: {
    backgroundColor: '#2E7D32',
    borderColor: '#2E7D32',
  },
  typeButtonText: {
    fontSize: 14,
    color: '#666',
  },
  activeTypeButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
  locationPreview: {
    backgroundColor: '#E3F2FD',
    padding: 16,
    borderRadius: 8,
    marginTop: 20,
  },
  previewTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#1976D2',
    textAlign: 'right',
    marginBottom: 4,
  },
  previewText: {
    fontSize: 14,
    color: '#1976D2',
    textAlign: 'right',
    fontFamily: 'monospace',
    marginBottom: 4,
  },
  previewAccuracy: {
    fontSize: 12,
    color: '#1976D2',
    textAlign: 'right',
  },
});

export default SurveyDataCollector;

