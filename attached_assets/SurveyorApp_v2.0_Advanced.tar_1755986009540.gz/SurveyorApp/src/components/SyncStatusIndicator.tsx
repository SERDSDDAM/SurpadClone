/**
 * مكون مؤشر حالة المزامنة
 * Sync Status Indicator Component
 */

import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Alert,
  Modal,
  ScrollView,
  ActivityIndicator,
} from 'react-native';
import SyncService, { SyncStatus } from '../services/SyncService';

interface SyncStatusIndicatorProps {
  style?: any;
  showDetails?: boolean;
}

const SyncStatusIndicator: React.FC<SyncStatusIndicatorProps> = ({
  style,
  showDetails = false,
}) => {
  const [syncStatus, setSyncStatus] = useState<SyncStatus>(SyncService.getSyncStatus());
  const [showModal, setShowModal] = useState(false);

  useEffect(() => {
    const handleSyncStatusChange = (status: SyncStatus) => {
      setSyncStatus(status);
    };

    SyncService.addSyncStatusListener(handleSyncStatusChange);

    return () => {
      SyncService.removeSyncStatusListener(handleSyncStatusChange);
    };
  }, []);

  const getStatusColor = (): string => {
    if (syncStatus.isSyncing) return '#FF9800';
    if (!syncStatus.isOnline) return '#F44336';
    if (syncStatus.syncErrors.length > 0) return '#FF5722';
    if (syncStatus.pendingUploads > 0) return '#2196F3';
    return '#4CAF50';
  };

  const getStatusIcon = (): string => {
    if (syncStatus.isSyncing) return '🔄';
    if (!syncStatus.isOnline) return '📵';
    if (syncStatus.syncErrors.length > 0) return '⚠️';
    if (syncStatus.pendingUploads > 0) return '📤';
    return '✅';
  };

  const getStatusText = (): string => {
    if (syncStatus.isSyncing) return 'جاري المزامنة...';
    if (!syncStatus.isOnline) return 'غير متصل';
    if (syncStatus.syncErrors.length > 0) return 'خطأ في المزامنة';
    if (syncStatus.pendingUploads > 0) return `${syncStatus.pendingUploads} في الانتظار`;
    return 'متزامن';
  };

  const handlePress = () => {
    if (showDetails) {
      setShowModal(true);
    } else {
      handleSync();
    }
  };

  const handleSync = async () => {
    if (syncStatus.isSyncing) {
      Alert.alert('تنبيه', 'المزامنة جارية بالفعل');
      return;
    }

    if (!syncStatus.isOnline) {
      const isOnline = await SyncService.checkConnectionStatus();
      if (!isOnline) {
        Alert.alert('خطأ', 'لا يوجد اتصال بالإنترنت');
        return;
      }
    }

    const success = await SyncService.syncAll();
    if (success) {
      Alert.alert('تم', 'تمت المزامنة بنجاح');
    } else {
      Alert.alert('خطأ', 'فشلت المزامنة، يرجى المحاولة مرة أخرى');
    }
  };

  const formatLastSyncTime = (): string => {
    if (!syncStatus.lastSyncTime) return 'لم تتم المزامنة بعد';
    
    const now = new Date();
    const lastSync = new Date(syncStatus.lastSyncTime);
    const diffMs = now.getTime() - lastSync.getTime();
    const diffMinutes = Math.floor(diffMs / (1000 * 60));
    const diffHours = Math.floor(diffMinutes / 60);
    const diffDays = Math.floor(diffHours / 24);

    if (diffMinutes < 1) return 'الآن';
    if (diffMinutes < 60) return `منذ ${diffMinutes} دقيقة`;
    if (diffHours < 24) return `منذ ${diffHours} ساعة`;
    return `منذ ${diffDays} يوم`;
  };

  const clearErrors = () => {
    SyncService.clearSyncErrors();
    Alert.alert('تم', 'تم مسح أخطاء المزامنة');
  };

  const resetSync = async () => {
    Alert.alert(
      'تأكيد',
      'هل تريد إعادة تعيين المزامنة؟ سيتم حذف جميع البيانات المعلقة.',
      [
        { text: 'إلغاء', style: 'cancel' },
        {
          text: 'تأكيد',
          style: 'destructive',
          onPress: async () => {
            await SyncService.resetSync();
            Alert.alert('تم', 'تم إعادة تعيين المزامنة');
          },
        },
      ]
    );
  };

  return (
    <>
      <TouchableOpacity
        style={[styles.container, { backgroundColor: getStatusColor() }, style]}
        onPress={handlePress}
        activeOpacity={0.7}
      >
        <Text style={styles.icon}>{getStatusIcon()}</Text>
        {showDetails && (
          <View style={styles.textContainer}>
            <Text style={styles.statusText}>{getStatusText()}</Text>
            <Text style={styles.lastSyncText}>{formatLastSyncTime()}</Text>
          </View>
        )}
        {syncStatus.isSyncing && (
          <ActivityIndicator size="small" color="white" style={styles.spinner} />
        )}
      </TouchableOpacity>

      {/* نافذة تفاصيل المزامنة */}
      <Modal
        visible={showModal}
        animationType="slide"
        presentationStyle="pageSheet"
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <TouchableOpacity
              onPress={() => setShowModal(false)}
              style={styles.modalCloseButton}
            >
              <Text style={styles.modalCloseText}>إغلاق</Text>
            </TouchableOpacity>
            <Text style={styles.modalTitle}>حالة المزامنة</Text>
            <TouchableOpacity
              onPress={handleSync}
              style={styles.modalSyncButton}
              disabled={syncStatus.isSyncing}
            >
              <Text style={[
                styles.modalSyncText,
                syncStatus.isSyncing && styles.disabledText
              ]}>
                {syncStatus.isSyncing ? 'جاري...' : 'مزامنة'}
              </Text>
            </TouchableOpacity>
          </View>

          <ScrollView style={styles.modalContent}>
            {/* حالة الاتصال */}
            <View style={styles.statusSection}>
              <Text style={styles.sectionTitle}>حالة الاتصال</Text>
              <View style={styles.statusRow}>
                <Text style={styles.statusLabel}>الاتصال:</Text>
                <View style={[
                  styles.statusBadge,
                  { backgroundColor: syncStatus.isOnline ? '#4CAF50' : '#F44336' }
                ]}>
                  <Text style={styles.statusBadgeText}>
                    {syncStatus.isOnline ? 'متصل' : 'غير متصل'}
                  </Text>
                </View>
              </View>
              <View style={styles.statusRow}>
                <Text style={styles.statusLabel}>آخر مزامنة:</Text>
                <Text style={styles.statusValue}>{formatLastSyncTime()}</Text>
              </View>
            </View>

            {/* العمليات المعلقة */}
            <View style={styles.statusSection}>
              <Text style={styles.sectionTitle}>العمليات المعلقة</Text>
              <View style={styles.statusRow}>
                <Text style={styles.statusLabel}>رفع البيانات:</Text>
                <Text style={styles.statusValue}>{syncStatus.pendingUploads}</Text>
              </View>
              <View style={styles.statusRow}>
                <Text style={styles.statusLabel}>تنزيل البيانات:</Text>
                <Text style={styles.statusValue}>{syncStatus.pendingDownloads}</Text>
              </View>
            </View>

            {/* الأخطاء */}
            {syncStatus.syncErrors.length > 0 && (
              <View style={styles.statusSection}>
                <View style={styles.sectionHeader}>
                  <Text style={styles.sectionTitle}>الأخطاء ({syncStatus.syncErrors.length})</Text>
                  <TouchableOpacity onPress={clearErrors} style={styles.clearButton}>
                    <Text style={styles.clearButtonText}>مسح</Text>
                  </TouchableOpacity>
                </View>
                {syncStatus.syncErrors.map((error, index) => (
                  <View key={index} style={styles.errorItem}>
                    <Text style={styles.errorText}>{error}</Text>
                  </View>
                ))}
              </View>
            )}

            {/* إعدادات المزامنة */}
            <View style={styles.statusSection}>
              <Text style={styles.sectionTitle}>إعدادات المزامنة</Text>
              <TouchableOpacity
                style={styles.actionButton}
                onPress={handleSync}
                disabled={syncStatus.isSyncing}
              >
                <Text style={[
                  styles.actionButtonText,
                  syncStatus.isSyncing && styles.disabledText
                ]}>
                  {syncStatus.isSyncing ? 'جاري المزامنة...' : 'مزامنة الآن'}
                </Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={[styles.actionButton, styles.dangerButton]}
                onPress={resetSync}
              >
                <Text style={[styles.actionButtonText, styles.dangerButtonText]}>
                  إعادة تعيين المزامنة
                </Text>
              </TouchableOpacity>
            </View>

            {/* معلومات إضافية */}
            <View style={styles.statusSection}>
              <Text style={styles.sectionTitle}>معلومات إضافية</Text>
              <Text style={styles.infoText}>
                • المزامنة التلقائية تعمل كل 5 دقائق{'\n'}
                • البيانات المحفوظة محلياً آمنة حتى لو لم تكن متصلاً{'\n'}
                • سيتم رفع البيانات تلقائياً عند توفر الاتصال{'\n'}
                • يمكنك العمل بدون اتصال بالإنترنت
              </Text>
            </View>
          </ScrollView>
        </View>
      </Modal>
    </>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
    minWidth: 40,
  },
  icon: {
    fontSize: 16,
    color: 'white',
  },
  textContainer: {
    marginLeft: 8,
  },
  statusText: {
    color: 'white',
    fontSize: 12,
    fontWeight: 'bold',
  },
  lastSyncText: {
    color: 'rgba(255, 255, 255, 0.8)',
    fontSize: 10,
  },
  spinner: {
    marginLeft: 8,
  },
  modalContainer: {
    flex: 1,
    backgroundColor: 'white',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
  },
  modalCloseButton: {
    padding: 8,
  },
  modalCloseText: {
    color: '#666',
    fontSize: 16,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  modalSyncButton: {
    padding: 8,
  },
  modalSyncText: {
    color: '#2E7D32',
    fontSize: 16,
    fontWeight: 'bold',
  },
  disabledText: {
    color: '#999',
  },
  modalContent: {
    flex: 1,
    padding: 20,
  },
  statusSection: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 12,
    textAlign: 'right',
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  statusRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  statusLabel: {
    fontSize: 14,
    color: '#666',
    textAlign: 'right',
  },
  statusValue: {
    fontSize: 14,
    color: '#333',
    fontWeight: 'bold',
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  statusBadgeText: {
    color: 'white',
    fontSize: 12,
    fontWeight: 'bold',
  },
  errorItem: {
    backgroundColor: '#FFEBEE',
    padding: 12,
    borderRadius: 8,
    marginBottom: 8,
    borderLeftWidth: 4,
    borderLeftColor: '#F44336',
  },
  errorText: {
    color: '#C62828',
    fontSize: 14,
    textAlign: 'right',
  },
  clearButton: {
    backgroundColor: '#FF5722',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
  },
  clearButtonText: {
    color: 'white',
    fontSize: 12,
    fontWeight: 'bold',
  },
  actionButton: {
    backgroundColor: '#2E7D32',
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
    marginBottom: 12,
  },
  actionButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  dangerButton: {
    backgroundColor: '#F44336',
  },
  dangerButtonText: {
    color: 'white',
  },
  infoText: {
    fontSize: 14,
    color: '#666',
    lineHeight: 20,
    textAlign: 'right',
  },
});

export default SyncStatusIndicator;

