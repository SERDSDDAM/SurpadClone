import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  FlatList,
  Alert,
  StyleSheet,
  ActivityIndicator,
  Modal,
  RefreshControl,
} from 'react-native';
import BluetoothService, { BluetoothDevice, GNSSData, LaserMeasurement } from '../services/BluetoothService';

interface BluetoothDeviceManagerProps {
  onDeviceConnected?: (device: BluetoothDevice) => void;
  onDeviceDisconnected?: (device: BluetoothDevice) => void;
  onGNSSDataReceived?: (data: GNSSData) => void;
  onLaserDataReceived?: (data: LaserMeasurement) => void;
}

const BluetoothDeviceManager: React.FC<BluetoothDeviceManagerProps> = ({
  onDeviceConnected,
  onDeviceDisconnected,
  onGNSSDataReceived,
  onLaserDataReceived,
}) => {
  const [devices, setDevices] = useState<BluetoothDevice[]>([]);
  const [connectedDevices, setConnectedDevices] = useState<BluetoothDevice[]>([]);
  const [isScanning, setIsScanning] = useState(false);
  const [isVisible, setIsVisible] = useState(false);
  const [selectedDevice, setSelectedDevice] = useState<BluetoothDevice | null>(null);

  useEffect(() => {
    // تحديث قائمة الأجهزة المتصلة
    const updateConnectedDevices = () => {
      const connected = BluetoothService.getConnectedDevices();
      setConnectedDevices(connected);
    };

    updateConnectedDevices();
    const interval = setInterval(updateConnectedDevices, 2000);

    return () => {
      clearInterval(interval);
      BluetoothService.cleanup();
    };
  }, []);

  /**
   * البحث عن الأجهزة
   */
  const scanForDevices = async () => {
    setIsScanning(true);
    try {
      const foundDevices = await BluetoothService.scanForDevices();
      setDevices(foundDevices);
    } catch (error) {
      Alert.alert('خطأ', 'فشل في البحث عن الأجهزة: ' + error.message);
    } finally {
      setIsScanning(false);
    }
  };

  /**
   * الاتصال بجهاز
   */
  const connectToDevice = async (device: BluetoothDevice) => {
    try {
      const success = await BluetoothService.connectToDevice(device.id);
      
      if (success) {
        // تسجيل مستمعي البيانات
        BluetoothService.registerDataListener(device.id, (data) => {
          if (device.type === 'GNSS' && onGNSSDataReceived) {
            onGNSSDataReceived(data as GNSSData);
          } else if (device.type === 'LASER' && onLaserDataReceived) {
            onLaserDataReceived(data as LaserMeasurement);
          }
        });

        // تحديث حالة الجهاز
        const updatedDevices = devices.map(d => 
          d.id === device.id ? { ...d, connected: true } : d
        );
        setDevices(updatedDevices);

        if (onDeviceConnected) {
          onDeviceConnected({ ...device, connected: true });
        }

        Alert.alert('نجح الاتصال', `تم الاتصال بـ ${device.name} بنجاح`);
      } else {
        Alert.alert('فشل الاتصال', `فشل في الاتصال بـ ${device.name}`);
      }
    } catch (error) {
      Alert.alert('خطأ', 'فشل في الاتصال: ' + error.message);
    }
  };

  /**
   * قطع الاتصال مع جهاز
   */
  const disconnectFromDevice = async (device: BluetoothDevice) => {
    try {
      const success = await BluetoothService.disconnectFromDevice(device.id);
      
      if (success) {
        // إلغاء تسجيل مستمع البيانات
        BluetoothService.unregisterDataListener(device.id);

        // تحديث حالة الجهاز
        const updatedDevices = devices.map(d => 
          d.id === device.id ? { ...d, connected: false } : d
        );
        setDevices(updatedDevices);

        if (onDeviceDisconnected) {
          onDeviceDisconnected({ ...device, connected: false });
        }

        Alert.alert('تم قطع الاتصال', `تم قطع الاتصال مع ${device.name}`);
      }
    } catch (error) {
      Alert.alert('خطأ', 'فشل في قطع الاتصال: ' + error.message);
    }
  };

  /**
   * عرض تفاصيل الجهاز
   */
  const showDeviceDetails = (device: BluetoothDevice) => {
    setSelectedDevice(device);
  };

  /**
   * الحصول على أيقونة نوع الجهاز
   */
  const getDeviceTypeIcon = (type: string) => {
    switch (type) {
      case 'GNSS':
        return '🛰️';
      case 'LASER':
        return '📏';
      default:
        return '📱';
    }
  };

  /**
   * الحصول على لون حالة الاتصال
   */
  const getConnectionStatusColor = (connected: boolean) => {
    return connected ? '#4CAF50' : '#757575';
  };

  /**
   * عرض عنصر الجهاز
   */
  const renderDeviceItem = ({ item }: { item: BluetoothDevice }) => (
    <View style={styles.deviceItem}>
      <View style={styles.deviceInfo}>
        <Text style={styles.deviceIcon}>{getDeviceTypeIcon(item.type)}</Text>
        <View style={styles.deviceDetails}>
          <Text style={styles.deviceName}>{item.name}</Text>
          <Text style={styles.deviceAddress}>{item.address}</Text>
          <Text style={styles.deviceType}>{item.type}</Text>
          {item.rssi && (
            <Text style={styles.deviceRssi}>قوة الإشارة: {item.rssi} dBm</Text>
          )}
        </View>
      </View>
      
      <View style={styles.deviceActions}>
        <View 
          style={[
            styles.connectionStatus, 
            { backgroundColor: getConnectionStatusColor(item.connected) }
          ]} 
        />
        
        <TouchableOpacity
          style={[
            styles.actionButton,
            item.connected ? styles.disconnectButton : styles.connectButton
          ]}
          onPress={() => item.connected ? disconnectFromDevice(item) : connectToDevice(item)}
        >
          <Text style={styles.actionButtonText}>
            {item.connected ? 'قطع الاتصال' : 'اتصال'}
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={styles.detailsButton}
          onPress={() => showDeviceDetails(item)}
        >
          <Text style={styles.detailsButtonText}>تفاصيل</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      {/* شريط الأدوات */}
      <View style={styles.toolbar}>
        <TouchableOpacity
          style={styles.scanButton}
          onPress={scanForDevices}
          disabled={isScanning}
        >
          {isScanning ? (
            <ActivityIndicator size="small" color="#FFFFFF" />
          ) : (
            <Text style={styles.scanButtonText}>البحث عن الأجهزة</Text>
          )}
        </TouchableOpacity>
        
        <TouchableOpacity
          style={styles.toggleButton}
          onPress={() => setIsVisible(!isVisible)}
        >
          <Text style={styles.toggleButtonText}>
            {isVisible ? 'إخفاء' : 'عرض'} الأجهزة
          </Text>
        </TouchableOpacity>
      </View>

      {/* عرض الأجهزة المتصلة */}
      {connectedDevices.length > 0 && (
        <View style={styles.connectedSection}>
          <Text style={styles.sectionTitle}>الأجهزة المتصلة ({connectedDevices.length})</Text>
          {connectedDevices.map(device => (
            <View key={device.id} style={styles.connectedDevice}>
              <Text style={styles.connectedDeviceIcon}>{getDeviceTypeIcon(device.type)}</Text>
              <Text style={styles.connectedDeviceName}>{device.name}</Text>
              <TouchableOpacity
                style={styles.disconnectSmallButton}
                onPress={() => disconnectFromDevice(device)}
              >
                <Text style={styles.disconnectSmallButtonText}>✕</Text>
              </TouchableOpacity>
            </View>
          ))}
        </View>
      )}

      {/* نافذة منبثقة لعرض قائمة الأجهزة */}
      <Modal
        visible={isVisible}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setIsVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>أجهزة البلوتوث</Text>
              <TouchableOpacity
                style={styles.closeButton}
                onPress={() => setIsVisible(false)}
              >
                <Text style={styles.closeButtonText}>✕</Text>
              </TouchableOpacity>
            </View>
            
            <FlatList
              data={devices}
              renderItem={renderDeviceItem}
              keyExtractor={(item) => item.id}
              refreshControl={
                <RefreshControl
                  refreshing={isScanning}
                  onRefresh={scanForDevices}
                />
              }
              ListEmptyComponent={
                <View style={styles.emptyList}>
                  <Text style={styles.emptyListText}>
                    لا توجد أجهزة متاحة. اسحب للأسفل للبحث.
                  </Text>
                </View>
              }
            />
          </View>
        </View>
      </Modal>

      {/* نافذة تفاصيل الجهاز */}
      <Modal
        visible={selectedDevice !== null}
        animationType="fade"
        transparent={true}
        onRequestClose={() => setSelectedDevice(null)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.detailsModal}>
            {selectedDevice && (
              <>
                <Text style={styles.detailsTitle}>تفاصيل الجهاز</Text>
                <View style={styles.detailsContent}>
                  <Text style={styles.detailsLabel}>الاسم:</Text>
                  <Text style={styles.detailsValue}>{selectedDevice.name}</Text>
                  
                  <Text style={styles.detailsLabel}>العنوان:</Text>
                  <Text style={styles.detailsValue}>{selectedDevice.address}</Text>
                  
                  <Text style={styles.detailsLabel}>النوع:</Text>
                  <Text style={styles.detailsValue}>{selectedDevice.type}</Text>
                  
                  <Text style={styles.detailsLabel}>الحالة:</Text>
                  <Text style={[
                    styles.detailsValue,
                    { color: selectedDevice.connected ? '#4CAF50' : '#F44336' }
                  ]}>
                    {selectedDevice.connected ? 'متصل' : 'غير متصل'}
                  </Text>
                  
                  {selectedDevice.rssi && (
                    <>
                      <Text style={styles.detailsLabel}>قوة الإشارة:</Text>
                      <Text style={styles.detailsValue}>{selectedDevice.rssi} dBm</Text>
                    </>
                  )}
                </View>
                
                <TouchableOpacity
                  style={styles.closeDetailsButton}
                  onPress={() => setSelectedDevice(null)}
                >
                  <Text style={styles.closeDetailsButtonText}>إغلاق</Text>
                </TouchableOpacity>
              </>
            )}
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  toolbar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 16,
    backgroundColor: '#f5f5f5',
  },
  scanButton: {
    backgroundColor: '#2196F3',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
    minWidth: 120,
    alignItems: 'center',
  },
  scanButtonText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
  },
  toggleButton: {
    backgroundColor: '#757575',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
  },
  toggleButtonText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
  },
  connectedSection: {
    padding: 16,
    backgroundColor: '#E8F5E8',
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 8,
    color: '#2E7D32',
  },
  connectedDevice: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    padding: 8,
    marginVertical: 2,
    borderRadius: 8,
    elevation: 1,
  },
  connectedDeviceIcon: {
    fontSize: 20,
    marginRight: 8,
  },
  connectedDeviceName: {
    flex: 1,
    fontSize: 14,
    fontWeight: '500',
  },
  disconnectSmallButton: {
    backgroundColor: '#F44336',
    width: 24,
    height: 24,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  disconnectSmallButtonText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: 'bold',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: '#FFFFFF',
    width: '90%',
    maxHeight: '80%',
    borderRadius: 12,
    overflow: 'hidden',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#2196F3',
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },
  closeButton: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  closeButtonText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
  deviceItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
  },
  deviceInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  deviceIcon: {
    fontSize: 24,
    marginRight: 12,
  },
  deviceDetails: {
    flex: 1,
  },
  deviceName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#212121',
  },
  deviceAddress: {
    fontSize: 12,
    color: '#757575',
    marginTop: 2,
  },
  deviceType: {
    fontSize: 12,
    color: '#2196F3',
    marginTop: 2,
  },
  deviceRssi: {
    fontSize: 10,
    color: '#9E9E9E',
    marginTop: 2,
  },
  deviceActions: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  connectionStatus: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginRight: 8,
  },
  actionButton: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 6,
    marginRight: 8,
  },
  connectButton: {
    backgroundColor: '#4CAF50',
  },
  disconnectButton: {
    backgroundColor: '#F44336',
  },
  actionButtonText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: 'bold',
  },
  detailsButton: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 6,
    backgroundColor: '#FF9800',
  },
  detailsButtonText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: 'bold',
  },
  emptyList: {
    padding: 32,
    alignItems: 'center',
  },
  emptyListText: {
    fontSize: 16,
    color: '#757575',
    textAlign: 'center',
  },
  detailsModal: {
    backgroundColor: '#FFFFFF',
    width: '80%',
    borderRadius: 12,
    padding: 24,
  },
  detailsTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 16,
    color: '#212121',
  },
  detailsContent: {
    marginBottom: 16,
  },
  detailsLabel: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#424242',
    marginTop: 8,
  },
  detailsValue: {
    fontSize: 14,
    color: '#212121',
    marginTop: 2,
  },
  closeDetailsButton: {
    backgroundColor: '#2196F3',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  closeDetailsButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default BluetoothDeviceManager;

