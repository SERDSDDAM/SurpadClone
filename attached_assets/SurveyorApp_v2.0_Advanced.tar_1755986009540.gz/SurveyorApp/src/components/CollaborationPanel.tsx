import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  TextInput,
  Alert,
  Modal,
  ScrollView,
  Animated,
} from 'react-native';
import CollaborationService, {
  CollaborationUser,
  ChatMessage,
  RealTimeUpdate,
} from '../services/CollaborationService';

interface CollaborationPanelProps {
  projectId?: string;
  onUserLocationTap?: (user: CollaborationUser) => void;
  onUpdateReceived?: (update: RealTimeUpdate) => void;
}

const CollaborationPanel: React.FC<CollaborationPanelProps> = ({
  projectId,
  onUserLocationTap,
  onUpdateReceived,
}) => {
  const [isVisible, setIsVisible] = useState(false);
  const [activeTab, setActiveTab] = useState<'users' | 'chat' | 'updates'>('users');
  const [connectedUsers, setConnectedUsers] = useState<CollaborationUser[]>([]);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [recentUpdates, setRecentUpdates] = useState<RealTimeUpdate[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [isConnected, setIsConnected] = useState(false);
  const [currentUser, setCurrentUser] = useState<CollaborationUser | null>(null);
  const [unreadCount, setUnreadCount] = useState(0);
  
  const chatScrollRef = useRef<FlatList>(null);
  const slideAnimation = useRef(new Animated.Value(-300)).current;
  const pulseAnimation = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    initializeCollaboration();
    
    return () => {
      cleanup();
    };
  }, []);

  useEffect(() => {
    if (projectId && isConnected) {
      joinProject();
    }
  }, [projectId, isConnected]);

  useEffect(() => {
    // تحريك اللوحة عند الظهور/الاختفاء
    Animated.timing(slideAnimation, {
      toValue: isVisible ? 0 : -300,
      duration: 300,
      useNativeDriver: true,
    }).start();
  }, [isVisible]);

  useEffect(() => {
    // تأثير النبض عند وجود رسائل غير مقروءة
    if (unreadCount > 0) {
      Animated.loop(
        Animated.sequence([
          Animated.timing(pulseAnimation, {
            toValue: 1.2,
            duration: 1000,
            useNativeDriver: true,
          }),
          Animated.timing(pulseAnimation, {
            toValue: 1,
            duration: 1000,
            useNativeDriver: true,
          }),
        ])
      ).start();
    } else {
      pulseAnimation.setValue(1);
    }
  }, [unreadCount]);

  /**
   * تهيئة خدمة التعاون
   */
  const initializeCollaboration = async () => {
    try {
      const serverUrl = 'ws://localhost:3001'; // يجب تغييرها لعنوان الخادم الفعلي
      const success = await CollaborationService.initialize(serverUrl);
      
      if (success) {
        setIsConnected(true);
        setCurrentUser(CollaborationService.getCurrentUser());
        
        // تسجيل المستمعين
        CollaborationService.registerUpdateListener('panel', handleUpdateReceived);
        CollaborationService.registerMessageListener('panel', handleMessageReceived);
        CollaborationService.registerUserListener('panel', handleUsersUpdate);
      } else {
        Alert.alert('خطأ في الاتصال', 'فشل في الاتصال بخادم التعاون');
      }
    } catch (error) {
      console.error('خطأ في تهيئة التعاون:', error);
    }
  };

  /**
   * الانضمام إلى المشروع
   */
  const joinProject = async () => {
    if (!projectId) return;
    
    try {
      const success = await CollaborationService.joinProject(projectId);
      if (!success) {
        Alert.alert('خطأ', 'فشل في الانضمام إلى المشروع');
      }
    } catch (error) {
      console.error('خطأ في الانضمام إلى المشروع:', error);
    }
  };

  /**
   * معالجة استقبال التحديثات
   */
  const handleUpdateReceived = (update: RealTimeUpdate) => {
    setRecentUpdates(prev => [update, ...prev.slice(0, 49)]); // الاحتفاظ بآخر 50 تحديث
    
    if (onUpdateReceived) {
      onUpdateReceived(update);
    }
  };

  /**
   * معالجة استقبال الرسائل
   */
  const handleMessageReceived = (message: ChatMessage) => {
    setChatMessages(prev => [...prev, message]);
    
    // زيادة عداد الرسائل غير المقروءة إذا كانت اللوحة مخفية أو التبويب غير نشط
    if (!isVisible || activeTab !== 'chat') {
      setUnreadCount(prev => prev + 1);
    }
    
    // التمرير إلى آخر رسالة
    setTimeout(() => {
      chatScrollRef.current?.scrollToEnd({ animated: true });
    }, 100);
  };

  /**
   * معالجة تحديث المستخدمين
   */
  const handleUsersUpdate = (users: CollaborationUser[]) => {
    setConnectedUsers(users);
  };

  /**
   * إرسال رسالة دردشة
   */
  const sendMessage = () => {
    if (!newMessage.trim()) return;
    
    CollaborationService.sendChatMessage(newMessage.trim());
    setNewMessage('');
  };

  /**
   * إرسال الموقع الحالي
   */
  const sendCurrentLocation = () => {
    const currentUser = CollaborationService.getCurrentUser();
    if (currentUser?.currentLocation) {
      const locationMessage = `الموقع: ${currentUser.currentLocation.latitude.toFixed(6)}, ${currentUser.currentLocation.longitude.toFixed(6)}`;
      CollaborationService.sendChatMessage(locationMessage, 'location', currentUser.currentLocation);
    } else {
      Alert.alert('خطأ', 'لا يمكن الحصول على الموقع الحالي');
    }
  };

  /**
   * تنظيف الموارد
   */
  const cleanup = () => {
    CollaborationService.unregisterUpdateListener('panel');
    CollaborationService.unregisterMessageListener('panel');
    CollaborationService.unregisterUserListener('panel');
  };

  /**
   * تبديل رؤية اللوحة
   */
  const togglePanel = () => {
    setIsVisible(!isVisible);
    
    if (!isVisible && activeTab === 'chat') {
      setUnreadCount(0); // مسح عداد الرسائل غير المقروءة عند فتح الدردشة
    }
  };

  /**
   * تغيير التبويب النشط
   */
  const switchTab = (tab: 'users' | 'chat' | 'updates') => {
    setActiveTab(tab);
    
    if (tab === 'chat') {
      setUnreadCount(0); // مسح عداد الرسائل غير المقروءة
    }
  };

  /**
   * تنسيق الوقت
   */
  const formatTime = (date: Date) => {
    return new Date(date).toLocaleTimeString('ar-SA', {
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  /**
   * الحصول على لون حالة المستخدم
   */
  const getUserStatusColor = (user: CollaborationUser) => {
    return user.isOnline ? '#4CAF50' : '#757575';
  };

  /**
   * عرض قائمة المستخدمين
   */
  const renderUsersTab = () => (
    <View style={styles.tabContent}>
      <Text style={styles.tabTitle}>المستخدمون المتصلون ({connectedUsers.length})</Text>
      
      <FlatList
        data={connectedUsers}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.userItem}
            onPress={() => onUserLocationTap && onUserLocationTap(item)}
          >
            <View style={styles.userInfo}>
              <View style={[styles.userStatus, { backgroundColor: getUserStatusColor(item) }]} />
              <View style={styles.userDetails}>
                <Text style={styles.userName}>{item.name}</Text>
                <Text style={styles.userRole}>
                  {item.role === 'surveyor' ? 'مساح' :
                   item.role === 'supervisor' ? 'مشرف' : 'مدير'}
                </Text>
                {item.currentLocation && (
                  <Text style={styles.userLocation}>
                    📍 {item.currentLocation.latitude.toFixed(4)}, {item.currentLocation.longitude.toFixed(4)}
                  </Text>
                )}
              </View>
            </View>
            
            {item.currentLocation && (
              <TouchableOpacity
                style={styles.locationButton}
                onPress={() => onUserLocationTap && onUserLocationTap(item)}
              >
                <Text style={styles.locationButtonText}>عرض الموقع</Text>
              </TouchableOpacity>
            )}
          </TouchableOpacity>
        )}
        ListEmptyComponent={
          <Text style={styles.emptyText}>لا يوجد مستخدمون متصلون</Text>
        }
      />
    </View>
  );

  /**
   * عرض تبويب الدردشة
   */
  const renderChatTab = () => (
    <View style={styles.tabContent}>
      <Text style={styles.tabTitle}>الدردشة</Text>
      
      <FlatList
        ref={chatScrollRef}
        data={chatMessages}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={[
            styles.messageItem,
            item.userId === currentUser?.id ? styles.ownMessage : styles.otherMessage
          ]}>
            {item.userId !== currentUser?.id && (
              <Text style={styles.messageSender}>{item.userName}</Text>
            )}
            
            <Text style={styles.messageText}>{item.message}</Text>
            
            {item.type === 'location' && item.metadata && (
              <TouchableOpacity
                style={styles.locationMessage}
                onPress={() => {
                  // يمكن إضافة وظيفة لفتح الموقع على الخريطة
                  Alert.alert('الموقع', `خط العرض: ${item.metadata.latitude}\nخط الطول: ${item.metadata.longitude}`);
                }}
              >
                <Text style={styles.locationMessageText}>📍 عرض الموقع</Text>
              </TouchableOpacity>
            )}
            
            <Text style={styles.messageTime}>{formatTime(item.timestamp)}</Text>
          </View>
        )}
        ListEmptyComponent={
          <Text style={styles.emptyText}>لا توجد رسائل</Text>
        }
      />
      
      <View style={styles.messageInput}>
        <TextInput
          style={styles.textInput}
          value={newMessage}
          onChangeText={setNewMessage}
          placeholder="اكتب رسالة..."
          multiline
          maxLength={500}
        />
        
        <TouchableOpacity
          style={styles.locationSendButton}
          onPress={sendCurrentLocation}
        >
          <Text style={styles.sendButtonText}>📍</Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={styles.sendButton}
          onPress={sendMessage}
          disabled={!newMessage.trim()}
        >
          <Text style={styles.sendButtonText}>إرسال</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  /**
   * عرض تبويب التحديثات
   */
  const renderUpdatesTab = () => (
    <View style={styles.tabContent}>
      <Text style={styles.tabTitle}>التحديثات الأخيرة</Text>
      
      <FlatList
        data={recentUpdates}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.updateItem}>
            <Text style={styles.updateType}>
              {item.type === 'point_added' ? '➕ تم إضافة نقطة' :
               item.type === 'point_updated' ? '✏️ تم تحديث نقطة' :
               item.type === 'point_deleted' ? '🗑️ تم حذف نقطة' :
               item.type === 'user_joined' ? '👋 انضم مستخدم' :
               item.type === 'user_left' ? '👋 غادر مستخدم' :
               item.type === 'location_updated' ? '📍 تحديث موقع' : '📝 تحديث'}
            </Text>
            
            <Text style={styles.updateTime}>{formatTime(item.timestamp)}</Text>
            
            {item.data && (
              <Text style={styles.updateData} numberOfLines={2}>
                {JSON.stringify(item.data, null, 2)}
              </Text>
            )}
          </View>
        )}
        ListEmptyComponent={
          <Text style={styles.emptyText}>لا توجد تحديثات</Text>
        }
      />
    </View>
  );

  return (
    <>
      {/* زر فتح اللوحة */}
      <Animated.View style={[styles.toggleButton, { transform: [{ scale: pulseAnimation }] }]}>
        <TouchableOpacity
          style={[styles.toggleButtonInner, { backgroundColor: isConnected ? '#4CAF50' : '#757575' }]}
          onPress={togglePanel}
        >
          <Text style={styles.toggleButtonText}>👥</Text>
          {unreadCount > 0 && (
            <View style={styles.badge}>
              <Text style={styles.badgeText}>{unreadCount > 99 ? '99+' : unreadCount}</Text>
            </View>
          )}
        </TouchableOpacity>
      </Animated.View>

      {/* لوحة التعاون */}
      <Animated.View style={[
        styles.panel,
        { transform: [{ translateX: slideAnimation }] }
      ]}>
        {/* شريط التنقل */}
        <View style={styles.tabBar}>
          <TouchableOpacity
            style={[styles.tab, activeTab === 'users' && styles.activeTab]}
            onPress={() => switchTab('users')}
          >
            <Text style={[styles.tabText, activeTab === 'users' && styles.activeTabText]}>
              المستخدمون
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[styles.tab, activeTab === 'chat' && styles.activeTab]}
            onPress={() => switchTab('chat')}
          >
            <Text style={[styles.tabText, activeTab === 'chat' && styles.activeTabText]}>
              الدردشة
            </Text>
            {unreadCount > 0 && activeTab !== 'chat' && (
              <View style={styles.smallBadge}>
                <Text style={styles.smallBadgeText}>{unreadCount}</Text>
              </View>
            )}
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[styles.tab, activeTab === 'updates' && styles.activeTab]}
            onPress={() => switchTab('updates')}
          >
            <Text style={[styles.tabText, activeTab === 'updates' && styles.activeTabText]}>
              التحديثات
            </Text>
          </TouchableOpacity>
        </View>

        {/* محتوى التبويب */}
        {activeTab === 'users' && renderUsersTab()}
        {activeTab === 'chat' && renderChatTab()}
        {activeTab === 'updates' && renderUpdatesTab()}

        {/* شريط الحالة */}
        <View style={styles.statusBar}>
          <View style={[styles.connectionStatus, { backgroundColor: isConnected ? '#4CAF50' : '#F44336' }]} />
          <Text style={styles.statusText}>
            {isConnected ? 'متصل' : 'غير متصل'}
          </Text>
          
          {currentUser && (
            <Text style={styles.currentUserText}>
              {currentUser.name} ({currentUser.role === 'surveyor' ? 'مساح' : 
                                 currentUser.role === 'supervisor' ? 'مشرف' : 'مدير'})
            </Text>
          )}
        </View>
      </Animated.View>
    </>
  );
};

const styles = StyleSheet.create({
  toggleButton: {
    position: 'absolute',
    top: 100,
    left: 16,
    zIndex: 1000,
  },
  toggleButtonInner: {
    width: 56,
    height: 56,
    borderRadius: 28,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.3,
    shadowRadius: 6,
  },
  toggleButtonText: {
    fontSize: 24,
    color: '#FFFFFF',
  },
  badge: {
    position: 'absolute',
    top: -5,
    right: -5,
    backgroundColor: '#F44336',
    borderRadius: 12,
    minWidth: 24,
    height: 24,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#FFFFFF',
  },
  badgeText: {
    color: '#FFFFFF',
    fontSize: 10,
    fontWeight: 'bold',
  },
  panel: {
    position: 'absolute',
    top: 0,
    left: 0,
    bottom: 0,
    width: 300,
    backgroundColor: '#FFFFFF',
    elevation: 10,
    shadowColor: '#000',
    shadowOffset: { width: 2, height: 0 },
    shadowOpacity: 0.3,
    shadowRadius: 10,
    zIndex: 999,
  },
  tabBar: {
    flexDirection: 'row',
    backgroundColor: '#f5f5f5',
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
  },
  tab: {
    flex: 1,
    paddingVertical: 12,
    alignItems: 'center',
    position: 'relative',
  },
  activeTab: {
    backgroundColor: '#2196F3',
  },
  tabText: {
    fontSize: 12,
    color: '#757575',
    fontWeight: '500',
  },
  activeTabText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
  },
  smallBadge: {
    position: 'absolute',
    top: 4,
    right: 8,
    backgroundColor: '#F44336',
    borderRadius: 8,
    minWidth: 16,
    height: 16,
    justifyContent: 'center',
    alignItems: 'center',
  },
  smallBadgeText: {
    color: '#FFFFFF',
    fontSize: 8,
    fontWeight: 'bold',
  },
  tabContent: {
    flex: 1,
    padding: 16,
  },
  tabTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#212121',
    marginBottom: 12,
  },
  userItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },
  userInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  userStatus: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginRight: 8,
  },
  userDetails: {
    flex: 1,
  },
  userName: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#212121',
  },
  userRole: {
    fontSize: 12,
    color: '#757575',
    marginTop: 2,
  },
  userLocation: {
    fontSize: 10,
    color: '#2196F3',
    marginTop: 2,
    fontFamily: 'monospace',
  },
  locationButton: {
    backgroundColor: '#2196F3',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 4,
  },
  locationButtonText: {
    color: '#FFFFFF',
    fontSize: 10,
    fontWeight: 'bold',
  },
  messageItem: {
    marginVertical: 4,
    padding: 8,
    borderRadius: 8,
    maxWidth: '80%',
  },
  ownMessage: {
    alignSelf: 'flex-end',
    backgroundColor: '#2196F3',
  },
  otherMessage: {
    alignSelf: 'flex-start',
    backgroundColor: '#F5F5F5',
  },
  messageSender: {
    fontSize: 10,
    color: '#757575',
    marginBottom: 2,
    fontWeight: 'bold',
  },
  messageText: {
    fontSize: 14,
    color: '#212121',
  },
  messageTime: {
    fontSize: 10,
    color: '#757575',
    marginTop: 4,
    textAlign: 'right',
  },
  locationMessage: {
    backgroundColor: 'rgba(33, 150, 243, 0.1)',
    padding: 4,
    borderRadius: 4,
    marginTop: 4,
  },
  locationMessageText: {
    fontSize: 12,
    color: '#2196F3',
    fontWeight: 'bold',
  },
  messageInput: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    paddingTop: 8,
    borderTopWidth: 1,
    borderTopColor: '#E0E0E0',
  },
  textInput: {
    flex: 1,
    borderWidth: 1,
    borderColor: '#E0E0E0',
    borderRadius: 20,
    paddingHorizontal: 12,
    paddingVertical: 8,
    maxHeight: 80,
    marginRight: 8,
  },
  locationSendButton: {
    backgroundColor: '#FF9800',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
    marginRight: 4,
  },
  sendButton: {
    backgroundColor: '#4CAF50',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
  },
  sendButtonText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: 'bold',
  },
  updateItem: {
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },
  updateType: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#212121',
  },
  updateTime: {
    fontSize: 10,
    color: '#757575',
    marginTop: 2,
  },
  updateData: {
    fontSize: 10,
    color: '#424242',
    marginTop: 4,
    fontFamily: 'monospace',
    backgroundColor: '#F8F8F8',
    padding: 4,
    borderRadius: 4,
  },
  statusBar: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    backgroundColor: '#F5F5F5',
    borderTopWidth: 1,
    borderTopColor: '#E0E0E0',
  },
  connectionStatus: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginRight: 8,
  },
  statusText: {
    fontSize: 12,
    color: '#424242',
    fontWeight: 'bold',
  },
  currentUserText: {
    fontSize: 10,
    color: '#757575',
    marginLeft: 8,
    flex: 1,
    textAlign: 'right',
  },
  emptyText: {
    textAlign: 'center',
    color: '#757575',
    fontSize: 14,
    marginTop: 20,
  },
});

export default CollaborationPanel;

