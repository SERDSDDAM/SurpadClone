/**
 * تطبيق المساح - منصة بناء اليمن الرقمية
 * Surveyor App - Binaa Yemen Digital Platform
 * 
 * @format
 */

import React, { useState, useEffect } from 'react';
import {
  SafeAreaView,
  StatusBar,
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  Alert,
  I18nManager,
  useColorScheme,
} from 'react-native';

import {
  Colors,
} from 'react-native/Libraries/NewAppScreen';

// تفعيل دعم RTL للعربية
I18nManager.allowRTL(true);
I18nManager.forceRTL(true);

// مكونات التطبيق الرئيسية
import LoginScreen from './src/screens/LoginScreen';
import DashboardScreen from './src/screens/DashboardScreen';
import SurveyRequestsScreen from './src/screens/SurveyRequestsScreen';
import MapScreen from './src/screens/MapScreen';
import BluetoothScreen from './src/screens/BluetoothScreen';
import ARScreen from './src/screens/ARScreen';
import CollaborationScreen from './src/screens/CollaborationScreen';
import CADGISScreen from './src/screens/CADGISScreen';
import OfflineMapScreen from './src/screens/OfflineMapScreen';
import PerformanceMonitorScreen from './src/screens/PerformanceMonitorScreen';
import SettingsScreen from './src/screens/SettingsScreen';

// أنواع الشاشات
type ScreenType = 'login' | 'dashboard' | 'surveys' | 'map' | 'bluetooth' | 'ar' | 'collaboration' | 'cadgis' | 'offline' | 'performance' | 'settings';

function App(): JSX.Element {
  const isDarkMode = useColorScheme() === 'dark';
  const [currentScreen, setCurrentScreen] = useState<ScreenType>('login');
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const backgroundStyle = {
    backgroundColor: isDarkMode ? Colors.darker : Colors.lighter,
  };

  // دالة تسجيل الدخول
  const handleLogin = (username: string, password: string) => {
    // محاكاة عملية تسجيل الدخول
    if (username && password) {
      setIsLoggedIn(true);
      setCurrentScreen('dashboard');
      Alert.alert('نجح تسجيل الدخول', 'مرحباً بك في تطبيق المساح');
    } else {
      Alert.alert('خطأ', 'يرجى إدخال اسم المستخدم وكلمة المرور');
    }
  };

  // دالة تسجيل الخروج
  const handleLogout = () => {
    setIsLoggedIn(false);
    setCurrentScreen('login');
    Alert.alert('تم تسجيل الخروج', 'شكراً لاستخدام التطبيق');
  };

  // عرض الشاشة المناسبة
  const renderScreen = () => {
    if (!isLoggedIn) {
      return <LoginScreen onLogin={handleLogin} />;
    }

    switch (currentScreen) {
      case 'dashboard':
        return <DashboardScreen onNavigate={setCurrentScreen} />;
      case 'surveys':
        return <SurveyRequestsScreen onNavigate={setCurrentScreen} />;
      case 'map':
        return <MapScreen onNavigate={setCurrentScreen} />;
      case 'bluetooth':
        return <BluetoothScreen onNavigate={setCurrentScreen} />;
      case 'ar':
        return <ARScreen onNavigate={setCurrentScreen} />;
      case 'collaboration':
        return <CollaborationScreen onNavigate={setCurrentScreen} />;
      case 'cadgis':
        return <CADGISScreen onNavigate={setCurrentScreen} />;
      case 'offline':
        return <OfflineMapScreen onNavigate={setCurrentScreen} />;
      case 'performance':
        return <PerformanceMonitorScreen onNavigate={setCurrentScreen} />;
      case 'settings':
        return <SettingsScreen onNavigate={setCurrentScreen} onLogout={handleLogout} />;
      default:
        return <DashboardScreen onNavigate={setCurrentScreen} />;
    }
  };

  return (
    <SafeAreaView style={[backgroundStyle, styles.container]}>
      <StatusBar
        barStyle={isDarkMode ? 'light-content' : 'dark-content'}
        backgroundColor={backgroundStyle.backgroundColor}
      />
      
      {/* شريط العنوان */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>تطبيق المساح</Text>
        <Text style={styles.headerSubtitle}>منصة بناء اليمن الرقمية</Text>
      </View>

      {/* محتوى التطبيق */}
      <View style={styles.content}>
        {renderScreen()}
      </View>

      {/* شريط التنقل السفلي */}
      {isLoggedIn && (
        <View style={styles.bottomNavigation}>
          <TouchableOpacity
            style={[styles.navButton, currentScreen === 'dashboard' && styles.activeNavButton]}
            onPress={() => setCurrentScreen('dashboard')}
          >
            <Text style={[styles.navButtonText, currentScreen === 'dashboard' && styles.activeNavButtonText]}>
              الرئيسية
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[styles.navButton, currentScreen === 'surveys' && styles.activeNavButton]}
            onPress={() => setCurrentScreen('surveys')}
          >
            <Text style={[styles.navButtonText, currentScreen === 'surveys' && styles.activeNavButtonText]}>
              الطلبات
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[styles.navButton, currentScreen === 'map' && styles.activeNavButton]}
            onPress={() => setCurrentScreen('map')}
          >
            <Text style={[styles.navButtonText, currentScreen === 'map' && styles.activeNavButtonText]}>
              الخريطة
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[styles.navButton, currentScreen === 'bluetooth' && styles.activeNavButton]}
            onPress={() => setCurrentScreen('bluetooth')}
          >
            <Text style={[styles.navButtonText, currentScreen === 'bluetooth' && styles.activeNavButtonText]}>
              البلوتوث
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[styles.navButton, currentScreen === 'ar' && styles.activeNavButton]}
            onPress={() => setCurrentScreen('ar')}
          >
            <Text style={[styles.navButtonText, currentScreen === 'ar' && styles.activeNavButtonText]}>
              AR
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[styles.navButton, currentScreen === 'collaboration' && styles.activeNavButton]}
            onPress={() => setCurrentScreen('collaboration')}
          >
            <Text style={[styles.navButtonText, currentScreen === 'collaboration' && styles.activeNavButtonText]}>
              التعاون
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[styles.navButton, currentScreen === 'performance' && styles.activeNavButton]}
            onPress={() => setCurrentScreen('performance')}
          >
            <Text style={[styles.navButtonText, currentScreen === 'performance' && styles.activeNavButtonText]}>
              الأداء
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[styles.navButton, currentScreen === 'settings' && styles.activeNavButton]}
            onPress={() => setCurrentScreen('settings')}
          >
            <Text style={[styles.navButtonText, currentScreen === 'settings' && styles.activeNavButtonText]}>
              الإعدادات
            </Text>
          </TouchableOpacity>
        </View>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    backgroundColor: '#2E7D32',
    padding: 16,
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: 'white',
    textAlign: 'center',
  },
  headerSubtitle: {
    fontSize: 14,
    color: '#E8F5E8',
    textAlign: 'center',
    marginTop: 4,
  },
  content: {
    flex: 1,
  },
  bottomNavigation: {
    flexDirection: 'row',
    backgroundColor: '#F5F5F5',
    borderTopWidth: 1,
    borderTopColor: '#E0E0E0',
  },
  navButton: {
    flex: 1,
    paddingVertical: 12,
    alignItems: 'center',
  },
  activeNavButton: {
    backgroundColor: '#2E7D32',
  },
  navButtonText: {
    fontSize: 12,
    color: '#666',
    textAlign: 'center',
  },
  activeNavButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
});

export default App;

